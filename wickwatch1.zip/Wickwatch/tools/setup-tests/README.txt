Tests for Setups.kt (the setup finder engine). They are NOT part of the Android build.
They need only a Kotlin compiler and compile Models.kt, Ind.kt and Setups.kt with Test.kt and Calib.kt:

  kotlinc app/src/main/java/online/wickwatch/app/{Models,Ind,Setups}.kt tools/setup-tests/*.kt -d out
  java -cp out:kotlin-stdlib.jar online.wickwatch.app.TestKt     (11 checks on planted charts)
  java -cp out:kotlin-stdlib.jar online.wickwatch.app.CalibKt    (how often it fires on random data, and its win rate there)

On random data the win rate should be about 1 / (1 + average R), around 5 to 10 percent with R near 0 over many trades.
If it were ever far above that, the engine would be looking at the future.
