package online.wickwatch.app
import java.util.Random

fun noise(seed: Long, n: Int, trendy: Boolean): List<Candle> {
    val rnd = Random(seed); val cs = ArrayList<Candle>(); var px = 100.0; var drift = 0.0
    for (i in 0 until n) {
        if (trendy && i % 150 == 0) drift = rnd.nextGaussian() * 0.12     // regimes that trend for a while
        val o = px; val c = px + drift + rnd.nextGaussian() * 0.8
        cs.add(Candle(1_700_000_000L + i * 60L, o, maxOf(o, c) + Math.abs(rnd.nextGaussian()) * 0.3, minOf(o, c) - Math.abs(rnd.nextGaussian()) * 0.3, c, 0.0)); px = c
    }
    return cs
}

fun main() {
    val sets = listOf(
        "imp5 eff.55 s60" to SetupParams(minImpulseAtr = 5.0, minEfficiency = 0.55),
        "imp5 eff.55 s70" to SetupParams(minImpulseAtr = 5.0, minEfficiency = 0.55, minScore = 70),
        "imp5 eff.55 s75" to SetupParams(minImpulseAtr = 5.0, minEfficiency = 0.55, minScore = 75),
        "imp6 eff.6 s70" to SetupParams(minImpulseAtr = 6.0, minEfficiency = 0.6, minScore = 70),
        "imp5 mode1 s70" to SetupParams(minImpulseAtr = 5.0, minEfficiency = 0.55, minScore = 70, entryMode = 1),
    )
    for ((name, p) in sets) {
        for (trendy in listOf(false, true)) {
            var valid = 0; var trades = 0; var w = 0; var l = 0; var sumR = 0.0; var candles = 0
            for (seed in 1L..30L) {
                val cs = noise(seed, 3000, trendy); candles += cs.size
                val sc = SetupEngine.scan(cs, p)
                valid += sc.setups.size
                for (s in sc.setups) { if (s.fillIdx >= 0) trades++; if (s.state == ST_WIN) { w++; sumR += s.result }; if (s.state == ST_LOSS) { l++; sumR -= 1 } }
            }
            println("%-18s %-7s valid=%4d (1 per %5d candles) trades=%4d  W=%3d L=%3d  winrate=%.0f%%  avgR=%.2f".format(name, if (trendy) "trendy" else "random", valid, if (valid > 0) candles / valid else 0, trades, w, l, if (w + l > 0) 100.0 * w / (w + l) else 0.0, if (w + l > 0) sumR / (w + l) else 0.0))
        }
    }
}
