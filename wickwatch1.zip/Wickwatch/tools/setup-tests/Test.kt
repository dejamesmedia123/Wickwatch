package online.wickwatch.app

import java.util.Random

fun bar(t: Int, o: Double, c: Double, up: Double = 0.1, dn: Double = 0.1) =
    Candle(1_700_000_000L + t * 60L, o, maxOf(o, c) + up, minOf(o, c) - dn, c, 0.0)

/** A planted supply setup. variant: 0 wins, 1 gets stopped, 2 spikes into the zone, 3 rejection candle at the zone. */
fun scenario(variant: Int): List<Candle> {
    val cs = ArrayList<Candle>()
    var t = 0
    var p = 100.0
    // 0..39 ranging
    for (i in 0 until 40) { val o = p; val c = if (i % 2 == 0) 100.7 else 99.4; cs.add(bar(t++, o, c, 0.25, 0.25)); p = c }
    // 40..46 decline to the swing low
    for (i in 0 until 7) { val o = p; val c = p - 0.45; cs.add(bar(t++, o, c, 0.15, 0.15)); p = c }   // ~96.85
    // 47..54 rally
    for (i in 0 until 8) { val o = p; val c = p + 0.6; cs.add(bar(t++, o, c, 0.15, 0.1)); p = c }     // ~101.65
    // 55: the origin candle (wick up to 102.3, body top 101.2)
    cs.add(Candle(1_700_000_000L + (t++) * 60L, 101.0, 102.3, 100.9, 101.15, 0.0))
    // 56..59: displacement down
    p = 101.15
    for (i in 0 until 4) { val o = p; val c = p - 1.6; cs.add(bar(t++, o, c, 0.1, 0.15)); p = c }     // ~94.75
    if (variant == 2) {
        // one huge candle straight back to the zone
        cs.add(Candle(1_700_000_000L + (t++) * 60L, p, 102.0, p - 0.1, 101.9, 0.0))
        for (i in 0 until 5) cs.add(bar(t++, 101.0, 100.0, 0.2, 0.2))
        return cs
    }
    // 60..: slow corrective climb back into the zone
    for (i in 0 until 12) { val o = p; val c = p + 0.55; cs.add(bar(t++, o, c, 0.15, 0.2)); p = c }  // ~101.35
    if (variant == 3) {
        cs.add(Candle(1_700_000_000L + (t++) * 60L, 101.4, 102.0, 100.0, 100.5, 0.0))              // rejection at the zone
    }
    when (variant) {
        1 -> { for (i in 0 until 6) { val o = p; val c = p + 0.7; cs.add(bar(t++, o, c, 0.15, 0.1)); p = c } }   // pushes through the zone
        else -> { p = 101.0; for (i in 0 until 14) { val o = p; val c = p - 0.8; cs.add(bar(t++, o, c, 0.1, 0.15)); p = c } }
    }
    return cs
}

fun mirror(cs: List<Candle>): List<Candle> = cs.map { Candle(it.t, 200 - it.o, 200 - it.l, 200 - it.h, 200 - it.c, 0.0) }

fun show(name: String, sc: SetupScan) {
    println("== " + name + ": " + sc.setups.size + " valid setup(s)")
    for (s in sc.setups) println("   " + s.side + " origin#" + s.originIdx + " state=" + s.state + " score=" + s.score +
        " entry=" + "%.2f".format(s.entry) + " stop=" + "%.2f".format(s.stop) + " target=" + "%.2f".format(s.target) +
        " rr=" + "%.1f".format(s.rr) + " result=" + "%.1f".format(s.result) + " why=" + s.why + " lock#" + s.lockIdx + " fill#" + s.fillIdx + " end#" + s.endIdx)
}

fun check(ok: Boolean, msg: String) { println((if (ok) "PASS  " else "FAIL  ") + msg); if (!ok) failures++ }
var failures = 0

fun main() {
    SetupEngine.trace = { println("      trace: " + it) }
    val p0 = SetupParams()
    val a = SetupEngine.scan(scenario(0), p0); show("short, wins", a)
    check(a.setups.any { it.originIdx == 55 && it.dir == 1 && it.state == ST_WIN }, "planted short setup is found and wins")
    check(a.setups.first { it.originIdx == 55 }.let { it.lockIdx >= 0 && it.fillIdx > it.lockIdx }, "it is known BEFORE the entry (no repaint)")
    val b = SetupEngine.scan(scenario(1), p0); show("short, stopped", b)
    check(b.setups.any { it.originIdx == 55 && it.state == ST_LOSS && it.result == -1.0 }, "price pushing through the zone is a loss")
    val c = SetupEngine.scan(mirror(scenario(0)), p0); show("long, wins (mirror)", c)
    check(c.setups.any { it.originIdx == 55 && it.dir == -1 && it.state == ST_WIN }, "mirrored chart gives a long that wins")
    check(Math.abs(c.setups.first { it.originIdx == 55 }.entry - (200 - a.setups.first { it.originIdx == 55 }.entry)) < 1e-6, "long levels are the mirror of the short levels")
    val d = SetupEngine.scan(scenario(2), p0); show("one-candle spike into the zone", d)
    check(d.setups.none { it.fillIdx >= 0 }, "a one-candle spike back into the zone is NOT taken")
    val e = SetupEngine.scan(scenario(3), SetupParams(entryMode = 1)); show("candle confirmation mode", e)
    check(e.setups.any { it.originIdx == 55 && it.state == ST_WIN }, "confirmation mode enters on the rejection candle")
    val f = SetupEngine.scan(scenario(0), SetupParams(entryMode = 2)); show("structure break mode", f)
    check(f.setups.any { it.originIdx == 55 }, "structure mode still recognises the setup")
    // fewer false setups with a stricter score
    val g = SetupEngine.scan(scenario(0), SetupParams(minScore = 95)); show("minScore 95", g)
    check(g.setups.none { it.fillIdx >= 0 }, "a very high score threshold rejects it")
    // the first 70 candles of the scenario: nothing yet, before the leg exists
    val h = SetupEngine.scan(scenario(0).take(70), p0)
    check(h.setups.all { it.lockIdx < 70 }, "cutting history short never invents setups")

    // truncation test: a setup found on the full history must also be found, identically, on a shorter history that includes its fill
    val full = SetupEngine.scan(scenario(0), p0).setups.first { it.originIdx == 55 }
    val cut = SetupEngine.scan(scenario(0).take(full.fillIdx + 1), p0)
    check(cut.setups.first { it.originIdx == 55 }.let { it.fillIdx == full.fillIdx && Math.abs(it.entry - full.entry) < 1e-9 }, "same setup and same entry when the future is hidden")

    // random noise: invariants only
    val rnd = Random(7)
    var total = 0; var resolved = 0
    for (run in 0 until 40) {
        val cs = ArrayList<Candle>(); var px = 100.0
        for (i in 0 until 3000) {
            val o = px; val c = px + rnd.nextGaussian() * 0.8
            cs.add(Candle(1_700_000_000L + i * 60L, o, maxOf(o, c) + Math.abs(rnd.nextGaussian()) * 0.3, minOf(o, c) - Math.abs(rnd.nextGaussian()) * 0.3, c, 0.0)); px = c
        }
        val sc = SetupEngine.scan(cs, p0)
        total += sc.setups.size
        for (s in sc.setups) {
            if (s.resolved) resolved += 1
            if (s.rr < p0.minRR - 1e-9 && s.state != ST_DEAD) { check(false, "rr below minimum on a live setup " + s.rr) }
            if (s.state == ST_WIN && s.result < p0.minRR - 1e-9) check(false, "win with R below min")
            if (s.isLong && !(s.stop < s.entry && s.target > s.entry)) check(false, "long levels in the wrong order")
            if (!s.isLong && !(s.stop > s.entry && s.target < s.entry)) check(false, "short levels in the wrong order")
        }
    }
    println("random noise: " + total + " valid setups in 40 x 3000 candles (" + resolved + " resolved)")
    println(if (failures == 0) "ALL CHECKS PASSED" else failures.toString() + " CHECK(S) FAILED")
}
