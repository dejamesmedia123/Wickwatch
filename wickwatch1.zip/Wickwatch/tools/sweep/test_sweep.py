import random
from sweep import scan, stats, P

fails = 0
def check(ok, msg):
    global fails
    print(("PASS  " if ok else "FAIL  ") + msg)
    fails += 0 if ok else 1

class B:
    def __init__(s, start=100.0): s.o=[]; s.h=[]; s.l=[]; s.c=[]; s.p=start
    def bar(s, c, up=0.15, dn=0.15, o=None):
        o = s.p if o is None else o
        s.o.append(o); s.c.append(c); s.h.append(max(o, c) + up); s.l.append(min(o, c) - dn); s.p = c
    def to(s, target, steps, up=0.15, dn=0.15):
        d = (target - s.p) / steps
        for _ in range(steps): s.bar(s.p + d, up, dn)
    def rng(s, n, lo, hi):
        for i in range(n): s.bar(hi if i % 2 else lo, 0.2, 0.2)
    def arr(s): return list(range(len(s.c))), s.o, s.h, s.l, s.c

def sell_sweep():
    b = B(100); b.rng(40, 99.4, 100.6)
    b.to(104, 8)                                    # rally into the high
    b.bar(103.2, 0.6, 0.1, o=103.8)                 # swing high: body top 103.8, wick to 104.4
    b.to(95, 5)                                     # leaves hard
    b.to(102.6, 10, 0.05, 0.15)                     # corrective return
    b.bar(103.2, 0.2, 0.1, o=102.8)                 # approach
    b.bar(103.5, 0.15, 0.1, o=103.2)                # still below body top 103.8
    b.bar(103.2, 0.5, 0.15, o=103.7)                # wick pokes above 103.8 and closes back under it
    b.to(80, 14, 0.1, 0.2)
    return b

def mirror(b):
    m = B(); m.o=[200-x for x in b.o]; m.h=[200-x for x in b.l]; m.l=[200-x for x in b.h]; m.c=[200-x for x in b.c]; return m

def flip_btc_like():
    # range, swing low, rally, price closes THROUGH the low, drops, comes back and pokes the old low from below
    b = B(60); b.rng(30, 59.9, 60.4)
    b.to(58.0, 5, 0.1, 0.1); b.bar(59.0, 0.1, 0.5, o=58.2)   # swing low, body bottom 58.2
    b.to(60.8, 8)                                   # rally (a naive engine buys the return to the low)
    b.to(58.6, 6); b.to(55.5, 6)                    # falls straight through the low, closes below it
    b.to(57.9, 8, 0.12, 0.12)                       # corrective climb back
    b.bar(58.1, 0.1, 0.1, o=57.95)
    b.bar(58.15, 0.35, 0.1, o=58.1)                 # wick pokes above 58.2 ...
    b.bar(57.9, 0.05, 0.1, o=58.1)                  # ... and closes back below
    b.to(50.0, 14, 0.1, 0.15)
    return b

def main():
    p = P(min_rr=3.0)
    b = sell_sweep(); r = scan(*b.arr(), p)
    for s in r: print("   ", s.side, s.kind, round(s.entry,2), round(s.stop,2), round(s.target,2), round(s.rr,1), s.outcome)
    check(any(s.side == "SELL" and s.outcome == "WIN" for s in r), "wick above a swing high gives a SELL that wins")
    check(not any(s.side == "BUY" for s in r), "no BUY appears on the sell chart")

    r2 = scan(*mirror(b).arr(), p)
    check(any(s.side == "BUY" and s.outcome == "WIN" for s in r2), "mirrored chart gives a BUY that wins")
    check(not any(s.side == "SELL" for s in r2), "no SELL appears on the mirrored chart")

    f = flip_btc_like(); r3 = scan(*f.arr(), p)
    for s in r3: print("   ", s.side, s.kind, round(s.entry,2), round(s.stop,2), round(s.target,2), round(s.rr,1), s.outcome)
    check(any(s.side == "SELL" and s.kind == "flip" and s.outcome == "WIN" for s in r3), "BTC-like: retest of a broken low gives a SELL that wins")
    check(not any(s.side == "BUY" for s in r3), "BTC-like: no BUY on the way down through the level")

    # a real break (deep poke, no close back) is not a sweep
    b4 = B(100); b4.rng(40, 99.4, 100.6); b4.to(104, 8); b4.bar(103.2, 0.6, 0.1, o=103.8); b4.to(95, 5); b4.to(102.6, 10, 0.05, 0.15)
    b4.to(112, 6); b4.to(120, 10)
    check(not any(s.side == "SELL" for s in scan(*b4.arr(), p)), "a clean break upward gives no sell")

    # no look-ahead: cutting the history right after the signal gives the same setup
    full = [s for s in r if s.side == "SELL"][0]
    cut = b.arr(); k = full.t_sig + 1
    c2 = scan(*[x[:k] for x in cut], p)
    check(any(s.side == "SELL" and abs(s.entry - full.entry) < 1e-9 and abs(s.stop - full.stop) < 1e-9 for s in c2), "same setup is found on history cut at the signal (no look-ahead)")

    # entry-at-level mode counts a setup that never returns as NOTFILLED
    r5 = scan(*b.arr(), P(entry_mode=1))
    check(all(s.outcome in ("NOTFILLED", "WIN", "LOSS", "OPEN") for s in r5), "level-entry mode runs")

    # random data: should not print money
    random.seed(7); tot = []
    for seed in range(20):
        random.seed(seed); x = B(100)
        for _ in range(1500): x.bar(x.p + random.gauss(0, 0.5), abs(random.gauss(0, .25)), abs(random.gauss(0, .25)))
        tot += scan(*x.arr(), p)
    st = stats(tot)
    print("   random data:", {k: round(v, 2) for k, v in st.items()})
    check(st["expectancy"] < 0.5, "random data does not give a big positive expectancy")
    print("FAILURES:", fails)

main()
