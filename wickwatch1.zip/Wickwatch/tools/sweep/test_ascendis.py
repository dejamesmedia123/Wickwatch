import random
from ascendis import scan, AP
from sweep import stats

fails = 0
def check(ok, msg):
    global fails
    print(("PASS  " if ok else "FAIL  ") + msg)
    fails += 0 if ok else 1

TF = 300      # 5 minute bars, bias timeframe = 6 bars (30 minutes)

class B:
    def __init__(s): s.o=[]; s.h=[]; s.l=[]; s.c=[]; s.p=None
    def seg(s, a, b, wick=0.0):
        s.o.append(a); s.c.append(b); s.h.append(max(a, b) + wick); s.l.append(min(a, b) - wick); s.p = b
    def htf(s, o, h, l, c):
        """one bias candle = 6 chart bars with exactly this open/high/low/close"""
        if c >= o: pts = [o, l, (l+h)/2, h, h-(h-c)*0.4, h-(h-c)*0.8, c]
        else:      pts = [o, h, (l+h)/2, l, l+(c-l)*0.4, l+(c-l)*0.8, c]
        for a, b in zip(pts, pts[1:]): s.seg(a, b)
    def run(s, to, steps, wick=0.05):
        a = s.p
        for k in range(steps): s.seg(a + (to-a)*k/steps, a + (to-a)*(k+1)/steps, wick)
    def arr(s): return [i*TF for i in range(len(s.c))], s.o, s.h, s.l, s.c

def chart(liquidity=True, rally_through=False):
    b = B()
    b.htf(100, 101.5, 99.8, 101); b.htf(101, 103, 100.8, 102.8); b.htf(102.8, 103.5, 102.5, 103.2)
    b.htf(103.2, 103.4, 101.5, 102); b.htf(102, 102.8, 100.9, 101.2); b.htf(101.2, 102.9, 101, 102.7)
    b.htf(102.7, 104.5 if liquidity else 103.4, 102.6, 104.2 if liquidity else 103.3)   # the POI candle
    b.htf(104.2 if liquidity else 103.3, 104.3 if liquidity else 103.4, 100.5, 100.8)   # break of structure
    b.htf(100.8, 101.5, 99.5, 99.8); b.htf(99.8, 100.4, 96, 96.5); b.htf(96.5, 98, 95.5, 97.5); b.htf(97.5, 99.5, 97.3, 99.2)
    if rally_through:
        b.run(106, 12); b.run(103, 12); return b
    b.run(101.6, 6); b.run(100.9, 4); b.run(103.0, 6)            # climb, dip (the swing low), climb into the zone
    b.seg(103.0, 103.3, 0.1)                                       # small order block, high 103.4 made inside the zone
    b.seg(103.3, 102.4); b.seg(102.4, 101.5); b.seg(101.5, 100.6)  # closes below the dip: structure shift
    b.run(103.05, 6, 0.0)                                          # back up to the order block edge: limit fills
    b.run(93, 22, 0.05)                                            # away to the target
    return b

def mirror(b):
    m = B(); m.o=[200-x for x in b.o]; m.h=[200-x for x in b.l]; m.l=[200-x for x in b.h]; m.c=[200-x for x in b.c]; return m

def show(r):
    for s in r: print("   ", s.side, s.kind, "entry", round(s.entry,2), "stop", round(s.stop,2), "target", round(s.target,2), "RR", round(s.rr,1), s.outcome)

b = chart(); r = scan(*b.arr(), TF, AP(mult=6)); show(r)
check(any(s.side == "SELL" and s.outcome == "WIN" and abs(s.entry-103.0) < 0.2 for s in r), "downtrend + POI + liquidity + shift gives a SELL at the order block edge that wins")
check(not any(s.side == "BUY" for s in r), "no BUY appears in the downtrend")
r2 = scan(*mirror(b).arr(), TF, AP(mult=6))
check(any(s.side == "BUY" and s.outcome == "WIN" for s in r2) and not any(s.side == "SELL" for s in r2), "mirrored chart gives a winning BUY and no SELL")
nl = chart(liquidity=False)
check(not scan(*nl.arr(), TF, AP(mult=6)), "no liquidity sweep above the zone gives no setup")
check(any(s.side == "SELL" for s in scan(*nl.arr(), TF, AP(mult=6, need_liq=False))), "...but it is found when the liquidity rule is off")
check(not scan(*chart(rally_through=True).arr(), TF, AP(mult=6)), "price closing above the zone kills it (no sell)")
full = [s for s in r if s.side == "SELL"][0]
k = full.t_sig + 1; c = b.arr()
c2 = scan(*[x[:k] for x in c], TF, AP(mult=6))
check(any(abs(s.entry-full.entry) < 1e-9 and abs(s.stop-full.stop) < 1e-9 for s in c2), "same setup is found on history cut at the signal (no look-ahead)")
tot = []
for seed in range(20):
    random.seed(seed); x = B(); price = 100.0
    for _ in range(1500):
        n = price + random.gauss(0, 0.5); x.seg(price, n, abs(random.gauss(0, .25))); price = n
    tot += scan(*x.arr(), TF, AP(mult=6))
st = stats(tot); print("   random data:", {k: round(v, 2) for k, v in st.items()})
check(st["expectancy"] < 0.5, "random data does not give a big positive expectancy")
print("FAILURES:", fails)
