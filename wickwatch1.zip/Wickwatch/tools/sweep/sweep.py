"""Wickwatch sweep engine (reference version).

Rule (from the example charts):
  A marked level (swing high/low body edge, or a broken swing that is now a flipped level).
  Price comes at the level from one side, a wick pokes THROUGH it, then a candle closes back on the
  side it came from. The side is decided by the poke: wick above -> SELL, wick below -> BUY.
  Stop = just beyond the wick tip. Target = a major swing on the other side. Closed candles only.
Buys are the same code on mirrored prices.
"""
import csv, sys
from dataclasses import dataclass


@dataclass
class P:
    span: int = 3             # swing point = this many bars each side
    tgt_span: int = 8         # bigger swings are used as targets
    lookback: int = 300       # a level lives this long
    min_leg_atr: float = 2.0  # price must have left the swing by this many ATR
    max_poke_atr: float = 2.0 # deeper than this is a real break, not a sweep
    max_poke_bars: int = 3    # bars allowed above the level before the close back
    stop_buf_atr: float = 0.15
    min_rr: float = 3.0
    entry_mode: int = 0       # 0 = enter at the close back through the level, 1 = limit at the level (needs a return)
    wait_bars: int = 20       # mode 1: bars to wait for the return to the level
    max_active: int = 400
    min_pull_bars: int = 2    # at least this many bars on the way back
    pull_ratio: float = 0.8   # way back must be this much calmer than the move away
    poke_min_atr: float = 0.02


@dataclass
class Setup:
    side: str
    level: float
    t_sig: int
    entry: float = 0.0
    stop: float = 0.0
    target: float = 0.0
    rr: float = 0.0
    kind: str = ""
    outcome: str = ""         # WIN LOSS NOTFILLED FLAT OPEN
    r: float = 0.0
    t_end: int = 0


def atr14(h, l, c, n=14):
    out, prev = [], None
    for i in range(len(c)):
        tr = h[i] - l[i] if i == 0 else max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
        prev = tr if prev is None else (prev * (n - 1) + tr) / n
        out.append(prev)
    return out


def scan_dir(T, O, H, L, C, A, p, short):
    """Sell logic. For buys the caller passes mirrored arrays."""
    n = len(C)
    levels, out, tgt_lo, pend = [], [], [], []
    body = [abs(C[q] - O[q]) for q in range(n)]

    def calm_return(lv, i):
        """The way back to the level must be a slower, corrective move than the move that left it."""
        d0 = lv["dep"]
        if i - 1 <= d0:
            return False
        ext = min(range(d0, i), key=lambda q: L[q])           # lowest point of the leg away from the level
        if ext <= d0 or ext >= i - p["min_pull_bars"]:
            return False
        if lv["L"] - L[ext] < p["min_leg_atr"] * A[ext]:
            return False
        dep = sum(body[d0:ext + 1]) / (ext - d0 + 1)
        app = sum(body[ext + 1:i]) / max(1, i - ext - 1)
        return app <= p["pull_ratio"] * dep

    for i in range(n):
        for lv in levels:
            if lv["state"] == "dead":
                continue
            if i - lv["born"] > p["lookback"]:
                lv["state"] = "dead"; continue
            if lv["state"] == "armed":
                if H[i] > lv["L"] + p["poke_min_atr"] * A[i]:
                    if C[i - 1] >= lv["L"] or not calm_return(lv, i):
                        lv["state"] = "dead"; continue
                    lv["state"], lv["ps"], lv["ph"] = "poke", i, H[i]
                elif H[i] > lv["L"]:
                    continue
                else:
                    continue
            if lv["state"] == "poke":
                lv["ph"] = max(lv["ph"], H[i])
                if (lv["ph"] - lv["L"]) > p["max_poke_atr"] * A[i] or i - lv["ps"] + 1 > p["max_poke_bars"]:
                    lv["state"] = "dead"; continue
                if C[i] < lv["L"]:
                    lv["state"] = "dead"
                    s = make(T, O, H, L, C, A, p, lv, i, short, tgt_lo)
                    if s: out.append(s)
        j = i - p["span"]
        if j - p["span"] >= 0:
            sp = p["span"]
            hi_ok = all(H[q] < H[j] for q in range(j - sp, j)) and all(H[q] <= H[j] for q in range(j + 1, j + sp + 1))
            lo_ok = all(L[q] > L[j] for q in range(j - sp, j)) and all(L[q] >= L[j] for q in range(j + 1, j + sp + 1))
            if hi_ok:
                levels.append(dict(L=max(O[j], C[j]), kind="swing", born=i, state="armed", dep=j + 1))
            if lo_ok:
                pend.append((j, min(O[j], C[j])))
        jt = i - p["tgt_span"]
        if jt - p["tgt_span"] >= 0 and all(L[q] > L[jt] for q in range(jt - p["tgt_span"], jt)) and all(L[q] >= L[jt] for q in range(jt + 1, jt + p["tgt_span"] + 1)):
            tgt_lo.append((jt, L[jt]))
        for (jj, lvl) in list(pend):
            if i - jj > p["lookback"]:
                pend.remove((jj, lvl)); continue
            if i > jj + p["span"] and C[i] < lvl - 0.2 * A[i]:
                pend.remove((jj, lvl))
                levels.append(dict(L=lvl, kind="flip", born=i, state="armed", dep=i))
    return out


def make(T, O, H, L, C, A, p, lv, i, short, tgt_lo):
    a = A[i]
    stop = lv["ph"] + p["stop_buf_atr"] * a
    entry = C[i] if p["entry_mode"] == 0 else lv["L"]
    risk = stop - entry
    if risk <= 0:
        return None
    best = None
    for (jt, v) in tgt_lo:
        if jt + p["tgt_span"] > i or i - jt > 400 or v >= entry:
            continue
        if (entry - v) / risk >= p["min_rr"] and (best is None or v > best):
            best = v
    if best is None:
        return None
    s = Setup("SELL" if short else "BUY", lv["L"], i, entry, stop, best, (entry - best) / risk, lv["kind"])
    return s


def resolve(s, H, L, C, p, n):
    i = s.t_sig
    k0 = i + 1
    if p["entry_mode"] == 1:
        fill = None
        for k in range(i + 1, min(n, i + 1 + p["wait_bars"])):
            if L[k] <= s.target or False:
                break
            if H[k] >= s.stop and H[k] < s.entry:
                break
            if H[k] >= s.entry:
                fill = k; break
        if fill is None:
            s.outcome = "NOTFILLED" if i + p["wait_bars"] < n else "OPEN"
            return
        k0 = fill if H[fill] < s.stop else fill + 1
        if H[fill] >= s.stop:
            s.outcome, s.r, s.t_end = "LOSS", -1.0, fill; return
        k0 = fill + 1
    for k in range(k0, n):
        if H[k] >= s.stop:
            s.outcome, s.r, s.t_end = "LOSS", -1.0, k; return
        if L[k] <= s.target:
            s.outcome, s.r, s.t_end = "WIN", s.rr, k; return
        if k - k0 > p["max_active"]:
            s.outcome, s.r, s.t_end = "FLAT", (s.entry - C[k]) / (s.stop - s.entry), k; return
    s.outcome = "OPEN"


def scan(T, O, H, L, C, params=None):
    p = vars(params or P())
    n = len(C)
    if n < 60:
        return []
    A = atr14(H, L, C)
    res = []
    for s in scan_dir(T, O, H, L, C, A, p, True):
        resolve(s, H, L, C, p, n); res.append(s)
    mo, mh, ml, mc = [-x for x in O], [-x for x in L], [-x for x in H], [-x for x in C]   # mirrored: highs become -lows
    for s in scan_dir(T, mo, mh, ml, mc, A, p, True):
        s.side, s.level, s.entry, s.stop, s.target = "BUY", -s.level, -s.entry, -s.stop, -s.target
        resolve_m(s, mh, ml, mc, p, n); res.append(s)
    res.sort(key=lambda s: s.t_sig)
    return res


def resolve_m(s, mh, ml, mc, p, n):
    """Resolve a buy on mirrored arrays (prices of the setup are real, so mirror them back)."""
    m = Setup("SELL", -s.level, s.t_sig, -s.entry, -s.stop, -s.target, s.rr, s.kind)
    resolve(m, mh, ml, mc, p, n)
    s.outcome, s.r, s.t_end = m.outcome, m.r, m.t_end


def stats(res):
    w = [s for s in res if s.outcome == "WIN"]
    l = [s for s in res if s.outcome == "LOSS"]
    nf = [s for s in res if s.outcome == "NOTFILLED"]
    done = len(w) + len(l)
    avg_win = sum(s.rr for s in w) / len(w) if w else 0.0
    tot = sum(s.r for s in w + l)
    return dict(setups=len(res), wins=len(w), losses=len(l), notfilled=len(nf), open=sum(s.outcome == "OPEN" for s in res),
                winrate=100.0 * len(w) / done if done else 0.0, avg_win_R=avg_win, loss_R=-1.0,
                total_R=tot, expectancy=tot / done if done else 0.0)


def load_csv(path):
    rows = list(csv.DictReader(open(path)))
    k = {c.lower().strip(): c for c in rows[0].keys()}
    g = lambda r, *names: float(r[next(k[x] for x in names if x in k)])
    T = [r[k.get("time", list(rows[0].keys())[0])] for r in rows]
    return T, [g(r, "open") for r in rows], [g(r, "high") for r in rows], [g(r, "low") for r in rows], [g(r, "close") for r in rows]


def report(path, params=None):
    T, O, H, L, C = load_csv(path)
    res = scan(list(range(len(C))), O, H, L, C, params)
    for s in res:
        print(f"{T[s.t_sig]}  {s.side:4} {s.kind:5} entry {s.entry:.2f} stop {s.stop:.2f} target {s.target:.2f} RR {s.rr:.1f}  {s.outcome} {s.r:+.1f}R")
    st = stats(res)
    print(st)
    if st["wins"] + st["losses"] < 10:
        print(f"ONLY {st['wins'] + st['losses']} finished setups in {len(C)} candles. Need more history for 10.")
    return res


if __name__ == "__main__":
    report(sys.argv[1])
