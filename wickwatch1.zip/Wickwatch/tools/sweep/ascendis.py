"""Ascendis strategy (order block + liquidity, with the bias timeframe).

 1. Bias timeframe (chart timeframe x mult): a candle CLOSES through the last swing low = break of structure (BOS), trend is down.
 2. POI: the supply order block that started that leg: last bullish bias candle at/before the leg's highest high.
    It must have swept liquidity (its high took out an earlier swing high) -> "POI + liquidity".
 3. Price retraces up into the POI (tap). It is invalid if the chart closes above the zone, or a BOS in the other direction happens.
 4. On the chart timeframe, after the tap: a close below the last swing low = market structure shift (MSS).
 5. Entry: limit at the low edge of the small order block (last bullish candle at/before the high that was made inside the POI).
    Stop: just above that high. Target: the nearest earlier swing low giving at least min_rr.
 Sells only in a downtrend; buys are the same code on mirrored prices (uptrend). Closed candles only.
"""
from dataclasses import dataclass
from sweep import atr14, resolve, resolve_m, Setup, stats


@dataclass
class AP:
    mult: int = 9
    hspan: int = 2
    span: int = 3
    tgt_span: int = 8
    lookback: int = 400
    min_rr: float = 5.0
    max_risk_atr: float = 2.0
    stop_buf_atr: float = 0.15
    need_liq: bool = True
    wait_bars: int = 40
    max_active: int = 400
    entry_mode: int = 0       # 0 = limit at the OB edge, 1 = at the close of the MSS candle
    poi_ob_back: int = 3
    ob_back: int = 5
    mss_window: int = 40


def scan_dir(T, O, H, L, C, A, p, tfsec):
    n = len(C)
    blen = tfsec * p["mult"]
    bid = [t // blen for t in T]
    hO, hH, hL, hC, hid = [], [], [], [], []
    for i in range(n):
        if not hid or hid[-1] != bid[i]:
            hid.append(bid[i]); hO.append(O[i]); hH.append(H[i]); hL.append(L[i]); hC.append(C[i])
        else:
            hH[-1] = max(hH[-1], H[i]); hL[-1] = min(hL[-1], L[i]); hC[-1] = C[i]
    hs, sp = p["hspan"], p["span"]
    hp_hi, hp_lo, pois, ltf_lo, tgt, out = [], [], [], [], [], []
    ptr, down = 0, False

    def htf(k, i):
        nonlocal down
        j = k - hs
        if j - hs >= 0:
            if all(hH[q] < hH[j] for q in range(j - hs, j)) and all(hH[q] <= hH[j] for q in range(j + 1, j + hs + 1)):
                hp_hi.append([j, hH[j], False])
            if all(hL[q] > hL[j] for q in range(j - hs, j)) and all(hL[q] >= hL[j] for q in range(j + 1, j + hs + 1)):
                hp_lo.append([j, hL[j], False])
        ups = [x for x in hp_hi if not x[2]]
        if ups and hC[k] > ups[-1][1]:                        # break of structure the other way
            ups[-1][2] = True; down = False
            for q in pois: q["st"] = 2
            return
        lows = [x for x in hp_lo if not x[2]]
        if lows and hC[k] < lows[-1][1]:
            pl = lows[-1]; pl[2] = True; down = True
            jh = max(range(pl[0], k), key=lambda q: hH[q]) if k > pl[0] else None
            if jh is None:
                return
            ob = jh
            for q in range(jh, max(jh - p["poi_ob_back"], -1), -1):
                if hC[q] > hO[q]:
                    ob = q; break
            lo, hi = min(hO[ob], hC[ob]), max(hH[jh], hH[ob])
            liq = any(x[0] < jh and x[0] >= jh - 30 and hH[jh] > x[1] for x in hp_hi)
            if (p["need_liq"] and not liq) or C[i] >= lo:
                return
            pois.append(dict(lo=lo, hi=hi, born=i, st=0, tap=0, peak=0.0, pk=0))

    for i in range(n):
        while ptr < len(hid) and hid[ptr] < bid[i]:
            htf(ptr, i); ptr += 1
        j = i - sp
        if j - sp >= 0:
            if all(L[q] > L[j] for q in range(j - sp, j)) and all(L[q] >= L[j] for q in range(j + 1, j + sp + 1)):
                ltf_lo.append(j)
        jt = i - p["tgt_span"]
        if jt - p["tgt_span"] >= 0 and all(L[q] > L[jt] for q in range(jt - p["tgt_span"], jt)) and all(L[q] >= L[jt] for q in range(jt + 1, jt + p["tgt_span"] + 1)):
            tgt.append(L[jt])
        for q in pois:
            if q["st"] == 2:
                continue
            if i - q["born"] > p["lookback"] or C[i] > q["hi"] or not down:
                q["st"] = 2; continue
            if q["st"] == 0:
                if H[i] >= q["lo"]:
                    q["st"], q["tap"], q["peak"], q["pk"] = 1, i, H[i], i
                else:
                    continue
            if H[i] > q["peak"]:
                q["peak"], q["pk"] = H[i], i
            if i - q["pk"] > p["mss_window"]:
                q["st"] = 2; continue
            if i <= q["pk"]:
                continue
            jl = next((x for x in reversed(ltf_lo) if x < q["pk"]), None)
            if jl is None or jl < q["tap"] - 40 or not C[i] < L[jl]:
                continue
            q["st"] = 2
            ob = None
            for b in range(q["pk"], max(q["pk"] - p["ob_back"], -1), -1):
                if C[b] > O[b]:
                    ob = b; break
            if ob is None:
                continue
            stop = max(q["peak"], H[ob]) + p["stop_buf_atr"] * A[i]
            entry = max(O[ob], C[i]) if p["entry_mode"] == 0 else C[i]
            risk = stop - entry
            if risk <= 0 or risk > p["max_risk_atr"] * A[i]:
                continue
            cands = [v for v in tgt + [x[1] for x in hp_lo] if v < entry and (entry - v) / risk >= p["min_rr"]]
            if not cands:
                continue
            best = max(cands)
            out.append(Setup("SELL", entry, i, entry, stop, best, (entry - best) / risk, "ascendis"))
    return out


def scan(T, O, H, L, C, tfsec, params=None):
    p = vars(params or AP())
    rp = dict(entry_mode=1 if p["entry_mode"] == 0 else 0, wait_bars=p["wait_bars"], max_active=p["max_active"])
    n = len(C)
    if n < 80:
        return []
    A = atr14(H, L, C)
    res = []
    for s in scan_dir(T, O, H, L, C, A, p, tfsec):
        resolve(s, H, L, C, rp, n); res.append(s)
    mo, mh, ml, mc = [-x for x in O], [-x for x in L], [-x for x in H], [-x for x in C]
    for s in scan_dir(T, mo, mh, ml, mc, A, p, tfsec):
        s.side, s.level, s.entry, s.stop, s.target = "BUY", -s.level, -s.entry, -s.stop, -s.target
        resolve_m(s, mh, ml, mc, rp, n); res.append(s)
    res.sort(key=lambda s: s.t_sig)
    return res
