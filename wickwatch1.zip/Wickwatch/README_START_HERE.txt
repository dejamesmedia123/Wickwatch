WICKWATCH (version 1.0)

A phone app with a chart (drawing tools, indicators, chart alerts) and a background watcher for Deriv and Binance markets.

HOW TO BUILD (no Android Studio needed)
 1. Make a NEW, separate GitHub repository for this app.
 2. Upload the project files (or Wickwatch.zip, not unzipped) and keep build-apk.yml at .github/workflows/build-apk.yml.
 3. Open the Actions tab. "Build APK" starts by itself (or press Run workflow). About 5 to 8 minutes.
 4. A green tick: download Wickwatch-debug-apk from Artifacts, unzip it, install app-debug.apk.
    A red cross: open the run, tap Summary, and send the lines that start with "e:".

THE APP
 * First start: a short setup for theme, candle colours, chart defaults, markets, favourite drawing tools and alert style.
 * Tabs: Chart, Watchlist, Alerts, More.
 * Alerts: your chart alerts, plus Trend Target Ribbon (signal, targets, stop, near a target, near the trend line),
   Isotropic Trend Lines (breakout, retest, failed breakout, direction, near the edge) and key levels (near, broken).
 * Each alert type can be Off, Normal or Urgent (alarm sound, full screen on the lock screen, overrides Do Not Disturb).

PERMISSIONS (More > Permissions shows the status of each)
 Notifications, battery "unrestricted", Do Not Disturb override, full-screen alerts. On Tecno / Infinix / Itel phones also
 turn on Autostart for the app and lock it in the recent apps list.

LICENCES AND HONESTY NOTES
 * Ribbon.kt is a Kotlin port of "Trend Target Ribbon [BOSWaves]" (c) BOSWaves, Mozilla Public License 2.0. That file stays
   under the MPL 2.0 (https://mozilla.org/MPL/2.0/); if you distribute the app, make the source of that file available.
 * Iso.kt is an APPROXIMATION written from the description in the header of the "Smart Trader, Episode 06" script. The
   original functions were not available, so its channels and signals can differ from TradingView. Check the license of the
   original before distributing it.
 * Alerts are information only, not trading advice. The app does not place trades.
 * This code has not been compiled by its author; expect to fix a few build errors on the first run.
