WICKWATCH - ALL PLANNED PIECES WRITTEN (source only, NOT compiled yet)

No code in this project has been compiled by its author. The first GitHub build will probably show a few errors
("e:" lines on the run's Summary page). Send them and they get fixed.

FILES
  Models.kt        markets, timeframes, alert types, chart alerts model
  Feed.kt          Deriv + Binance history and live prices (with volume)
  Ind.kt           ATR, ALMA, stdev, SMA, EMA, RSI, Stochastic, Supertrend, VWAP
  Indicators.kt    indicator catalogue and settings (10 indicators)
  Ribbon.kt        Trend Target Ribbon port (MPL 2.0)
  Iso.kt           Isotropic Trend Lines approximation
  Levels.kt        key-levels engine, written for Wickwatch
  Store.kt         settings, theme, candle colours, drawings, chart alerts, indicators
  Alerts.kt        notification channels, normal and urgent alerts
  Ui.kt            theme system (black and white / white / navy and teal), candle presets, shared components
  ChartGeo.kt      auto / free / log / percent price scale, time and price mapping, panes
  Drawings.kt      about 55 drawing tools in 7 categories
  ToolsUi.kt       tool picker with search and favourites
  ChartCanvas.kt   candles, hollow, bars, line, area, Heikin Ashi, indicator panes
  ChartScreen.kt   chart screen, gestures, favourites bar, chart alerts, indicators
  Watcher.kt       NEW: Ribbon, Isotropic, key levels (near and broken), your chart alerts (price and line crossings)
  WatchService.kt  foreground service; runs while there is a watch-list market or an active chart alert
  Pickers.kt       NEW: theme, candles, chart defaults, market chooser, favourite tools, alert types, permissions
  Screens.kt       NEW: Alerts tab, Watchlist tab, More tab (appearance, chart defaults, tools, alerts, distances, permissions, about)
  Onboarding.kt    NEW: theme, candle colours, chart defaults, markets, favourite tools, alert style and permissions
  MainActivity.kt  onboarding first, theme applied, bottom navigation (Chart, Watchlist, Alerts, More)
  AlertActivity.kt urgent full-screen alert, in the chosen theme

HOW CHART ALERTS WORK
  A chart alert is checked on every price update by the watcher. Setting one from the chart starts the watcher by itself.
  A "once" alert turns itself off after it fires. A line alert follows the drawn line; if the line is deleted the alert turns off.
  If the watcher was off while a level was crossed, that crossing is not reported afterwards.
  The watcher stops by itself when the watchlist is empty and no chart alert is active.

NOT IN THIS PHASE
  WickScript, strategy tester, journal, economic calendar, multi-chart layouts, market-structure tools beyond key levels,
  and the drawing tools marked "soon" in the picker (Gann, Fibonacci fan and spiral, and others).

TWO-WEEK EXPIRY (Expiry.kt)
  Each build works for 14 days after it was installed (or updated over an older one). After that the app is view-only:
  charts, drawings, the watch list, past alerts and About can be looked at, but nothing can be drawn, set, added, removed or changed,
  and the background watcher stops. A red bar tells the person to download the new version.
  Installing a new version starts a new 14 days. Moving the phone clock back does not give extra time.
  UPDATE_URL in Expiry.kt is https://wickwatch.cfd. Change it, and DAYS, if you want a different period.

UI REWORK AND OFFLINE CANDLES (this version)
  WIcons.kt     Wickwatch's own line icons (no emoji). Also the bottom sheet, icon buttons and the Analysis hub tiles.
  Layout        Follows the TradingView pattern (symbol header, top bar with timeframe / chart type / indicators / alert, draggable
                floating tools bar, bottom-sheet drawings list with search and tabs, Analysis hub, candle countdown on the price tag,
                bottom tabs: Watchlist, Chart, Alerts, More). Look and feel (icons, amber "wick" tab mark, colours) is Wickwatch's own.
  CandleCache.kt Candles are saved on the phone (last 2000 per market and timeframe). The chart opens from them at once, also offline.
                When the phone is online again only the missing candles are fetched (up to ~6000 for a long gap) and the live feed continues.
  Onboarding    Now 3 steps: Welcome, Theme, Candle colours. Chart defaults, markets, favourite tools and alert style are in More.

SETUP FINDER (this version)   Setups.kt, SetupUi.kt
  Looks for the "return to the origin" setup from the example charts, in both directions:
    1. a swing high (supply) or swing low (demand) is the origin
    2. price leaves it with a strong, fast move (default at least 5 ATR within 12 candles, efficiency 0.55) and breaks the previous swing
    3. the zone at the origin (its wick) is thin (at most 1.5 ATR) and has not been touched since
    4. price comes back in a corrective way (at least 2 candles, not one spike candle)
    5. entry at the zone edge, stop just beyond the zone, target at the end of the move; reward to risk at least 3R
    6. a 0-100 match score (strength of the move, how clean the break was, zone thickness, reward to risk, equal highs/lows at the
       zone, quality of the pullback) must reach the minimum (default 65)
  Candles do not need to look the same, the structure has to. Entry styles (More > Setup finder): limit at the zone, candle
  confirmation (rejection candle at the zone), structure break (close below the last few lows after the touch).
  Decided on closed candles only, so nothing appears or changes in the past; the same code makes the alerts and the history.
  If one candle touches both stop and target the stop counts first. No spread or fees. Not advice.
  Alerts (More > Alert types > Setup finder): setup found (with entry, stop, target), price back near the entry, entry triggered,
  target hit, stop hit. Works for every market and timeframe on the Watchlist.
  Chart: Analysis hub > Setup finder draws zones, entry, stop, target and results. The small card on the chart shows the last 10 finished
  setups and the win rate; tap it (or Analysis hub > Setup dashboard) for the full dashboard: win rate, average R, open setups, history.
  The history comes from the candles saved on the phone (up to 2000 per market and timeframe), so on 1h it covers about 3 months and
  on 5m about a week.
  tools/setup-tests: 11 checks on planted charts plus a random-data check (see its README.txt). The engine file compiles and passes them.
  NOT compiled as part of the Android app: SetupUi.kt and the hooks in ChartScreen, ChartCanvas, Screens, Watcher, Store, Models.
  Expect to fix a few build errors on the first run, as with the rest of this project.

SWEEP ENGINE (replaces the first setup finder)   Sweeps.kt, tools/sweep/
  Rule: a wick pokes THROUGH a marked level (swing high/low body edge, or a broken swing that flipped) and a candle closes back on the side
  price came from. Wick above = SELL, wick below = BUY. The way back to the level must be calmer than the move that left it.
  Stop just beyond the wick tip; target = major swing on the other side, at least 3R. Closed candles only.
  Entry styles: close back through the level (default, counts every setup) or limit at the level (not taken if price never returns).
  Setups.kt: SetupEngine.scan now calls SweepEngine; the old engine is kept as scanOld (unused).
  Dashboard (Analysis hub > Setup dashboard): Copy candles CSV, Copy setups, Load older candles (pages back up to ~6000 candles).
  Chart keeps up to 8000 candles. tools/sweep/sweep.py is the tested reference; tools/setup-tests belongs to the OLD engine.
  NOT COMPILED: Sweeps.kt, the Backfill object in Feed.kt and the SetupUi/ChartScreen changes. Send the "e:" lines if the build fails.

STRATEGIES (Trend.kt, Sweeps.kt)   switch in the setup dashboard or More > Setup finder
  Sweep           wick through a level, traded back the other way (against the move)
  Sweep + trend   same, sells only in a downtrend, buys only in an uptrend (EMA 50 slope)
  Trend break     with the trend: lower high in a downtrend, sell on the close below the last swing low; stop above the lower high
                  (max 3 ATR away), target = Minimum reward to risk (default 5R) times the risk. Uptrend = buys.
  The dashboard card "Which pays most" runs all three on the same saved candles and shows W/L, win rate, total R and average R.
  Default minimum reward to risk is now 5R. NOT COMPILED, same as the rest of the setup finder.

ASCENDIS STRATEGY (strategy 3)   Ascendis.kt, tools/sweep/ascendis.py + test_ascendis.py (8 checks pass on planted charts)
  Bias timeframe (chart x biasMult, default 9) closes through its last swing low = break of structure -> downtrend.
  POI = supply order block that started the leg; it must have swept an earlier high (liquidity). Price retraces into it (tap).
  On the chart timeframe a close below the last swing low = shift. Entry = LIMIT at the low edge of the small order block,
  stop just above the high made inside the POI, target = nearest earlier swing low giving minRR. Buys = mirrored.
  Toggle: Setup settings / dashboard chips (Sweep, Sweep + trend, Trend break, Ascendis). The dashboard compares all four.
  NOT COMPILED. Bias candles are bucketed by epoch time (TradingView aligns to session start, so edges can differ a little).
