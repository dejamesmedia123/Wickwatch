WICKWATCH - ALL PLANNED PIECES WRITTEN (source only, NOT compiled yet)

No code in this project has been compiled by its author. The first GitHub build will probably show a few errors
("e:" lines on the run's Summary page). Send them and they get fixed.

FILES
  Models.kt        markets, timeframes, alert types, chart alerts model
  Feed.kt          Deriv + Binance history and live prices (with volume)
  Ind.kt           ATR, ALMA, stdev, SMA, EMA, RSI, Stochastic, Supertrend, VWAP
  Indicators.kt    indicator catalogue and settings (10 indicators)
  Ribbon.kt        Trend Target Ribbon port (MPL 2.0)
  Iso.kt           Isotropic Trend Lines approximation
  Levels.kt        key-levels engine, written for Wickwatch
  Store.kt         settings, theme, candle colours, drawings, chart alerts, indicators
  Alerts.kt        notification channels, normal and urgent alerts
  Ui.kt            theme system (black and white / white / navy and teal), candle presets, shared components
  ChartGeo.kt      auto / free / log / percent price scale, time and price mapping, panes
  Drawings.kt      about 55 drawing tools in 7 categories
  ToolsUi.kt       tool picker with search and favourites
  ChartCanvas.kt   candles, hollow, bars, line, area, Heikin Ashi, indicator panes
  ChartScreen.kt   chart screen, gestures, favourites bar, chart alerts, indicators
  Watcher.kt       NEW: Ribbon, Isotropic, key levels (near and broken), your chart alerts (price and line crossings)
  WatchService.kt  foreground service; runs while there is a watch-list market or an active chart alert
  Pickers.kt       NEW: theme, candles, chart defaults, market chooser, favourite tools, alert types, permissions
  Screens.kt       NEW: Alerts tab, Watchlist tab, More tab (appearance, chart defaults, tools, alerts, distances, permissions, about)
  Onboarding.kt    NEW: theme, candle colours, chart defaults, markets, favourite tools, alert style and permissions
  MainActivity.kt  onboarding first, theme applied, bottom navigation (Chart, Watchlist, Alerts, More)
  AlertActivity.kt urgent full-screen alert, in the chosen theme

HOW CHART ALERTS WORK
  A chart alert is checked on every price update by the watcher. Setting one from the chart starts the watcher by itself.
  A "once" alert turns itself off after it fires. A line alert follows the drawn line; if the line is deleted the alert turns off.
  If the watcher was off while a level was crossed, that crossing is not reported afterwards.
  The watcher stops by itself when the watchlist is empty and no chart alert is active.

NOT IN THIS PHASE
  WickScript, strategy tester, journal, economic calendar, multi-chart layouts, market-structure tools beyond key levels,
  and the drawing tools marked "soon" in the picker (Gann, Fibonacci fan and spiral, and others).

TWO-WEEK EXPIRY (Expiry.kt)
  Each build works for 14 days after it was installed (or updated over an older one). After that the app is view-only:
  charts, drawings, the watch list, past alerts and About can be looked at, but nothing can be drawn, set, added, removed or changed,
  and the background watcher stops. A red bar tells the person to download the new version.
  Installing a new version starts a new 14 days. Moving the phone clock back does not give extra time.
  UPDATE_URL in Expiry.kt is https://wickwatch.cfd. Change it, and DAYS, if you want a different period.

UI REWORK AND OFFLINE CANDLES (this version)
  WIcons.kt     Wickwatch's own line icons (no emoji). Also the bottom sheet, icon buttons and the Analysis hub tiles.
  Layout        Follows the TradingView pattern (symbol header, top bar with timeframe / chart type / indicators / alert, draggable
                floating tools bar, bottom-sheet drawings list with search and tabs, Analysis hub, candle countdown on the price tag,
                bottom tabs: Watchlist, Chart, Alerts, More). Look and feel (icons, amber "wick" tab mark, colours) is Wickwatch's own.
  CandleCache.kt Candles are saved on the phone (last 2000 per market and timeframe). The chart opens from them at once, also offline.
                When the phone is online again only the missing candles are fetched (up to ~6000 for a long gap) and the live feed continues.
  Onboarding    Now 3 steps: Welcome, Theme, Candle colours. Chart defaults, markets, favourite tools and alert style are in More.

TRADINGVIEW-STYLE LAYOUT (second pass)
  Chart: title and price line over the chart, indicator legend chip, bottom toolbar (symbol, timeframe, pen, indicators, menu, undo),
  pen switches the draggable tools bar, plain bottom tabs. Watchlist rows show symbol, name, last price and 1-day change
  (live while the watcher runs, otherwise from the saved candles). Quotes.kt holds the prices.
  Not copied on purpose: the TradingView logo, name and artwork.

ROUND 1 (not compiled yet)
- Watchlist: several lists, sort, reorder, sparklines, swipe to remove (WatchUi.kt)
- Alerts: expiry, indicator alerts (RSI/EMA/SMA), history tap opens chart, sound/vibration per type (AlertsUi.kt)
- Trading: position size calculator, trade journal, risk/reward amounts on Long/Short boxes (TradeUi.kt)
- Chart: scroll into the future, older history loads as you scroll back

SETUP FINDER MERGED (from the other zip; this version is the base). NOT COMPILED.
- Copied: Setups.kt, Sweeps.kt, Trend.kt, Ascendis.kt, SetupUi.kt, tools/. Hooks added in Store, Models (5 alert types), Watcher, Screens (More > Setup finder), ChartCanvas, ChartScreen, Feed.
- Arrow head at the entry (up = buy, down = sell). Listed like an indicator: legend row on the chart (tap = dashboard, mark = show/hide), switch in the Indicators dialog.
- History: scrolling back loads older candles (loadOlder) and the finder re-runs on them. Dashboard "Load older candles" calls the same paging. The old Backfill object was not used.
- Chart now keeps up to 8000 candles.
SETUPS ARE SEPARATE INDICATORS: Sweep, Trend break, Sweep + trend, Ascendis each have their own switch (Indicators dialog > Setups), their own legend row
  on the chart (tap = dashboard for that one, cross = off), their own drawing label and their own alerts (the watcher scans each one that is on).
  Default: only Trend break is on. Store.setupOn is a bit mask. The dashboard chips now choose which setup the dashboard shows.
NEW SETUPS 4-6 (Setups2.kt, NOT COMPILED, untested on real candles): Ribbon MSNR, Order block (trend from Ribbon or 200 EMA, see More > Setup finder), CRT.
  Same switches / legend rows / alerts as the other setups. Names in SETUP_SHORT, ids 0..6.
SETUP 7 Alchemist MSNR (Setups2.kt): A/V levels on closes + RBS/SBR flips, engulfing entry, stop beyond touch high, DYNAMIC target = nearest fresh opposite level that pays >= min R. NOT COMPILED.
REVERSE button (chart legend + dashboard): Store.setupReverse flips every setup (SetupEngine.reversed). Alchemist confirm = engulfing / strong close / rejection wick (from the cheat sheet). NOT COMPILED.
