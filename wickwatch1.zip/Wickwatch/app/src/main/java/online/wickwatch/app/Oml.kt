package online.wickwatch.app

/*
 * OML (open and close level), strategy 8. Written for sells; buys run the same code on mirrored prices.
 *
 *  candle 1  the liquidity candle (for a sell: an up candle).
 *  candle 2  a strong down candle that opens where candle 1 closed. That price is the OML level (the "open and close level").
 *  candle 3  must stay away from the level. Its high is the "$" liquidity line: price has to take it on the way back up to the level.
 *  candles 4 to N (N = 6, 7 or 8, a setting): the first one that comes back up to the level fills the limit sell there.
 *            Reaching it on candle 3, or not before candle N is over, means no trade.
 *  stop      above the high of candle 1 (the liquidity).
 *  target    the NEXT LEVEL: the nearest swing low from before candle 1 that price has not broken yet (the "DL" line) and that
 *            pays at least the minimum R. No such level = no trade.
 * Everything is decided on CLOSED candles. If one candle touches both the stop and the target, the stop counts first.
 */
object OmlEngine {
    fun scan(cs: List<Candle>, p: SetupParams): SetupScan {
        val n = cs.size
        val atr = SweepEngine.atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 40) return SetupScan(emptyList(), n, last)
        val all = ArrayList<Setup>()
        if (p.dirMask and 1 != 0) all.addAll(dir(cs, atr, p, true))
        if (p.dirMask and 2 != 0) all.addAll(dir(cs, atr, p, false))
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    private fun dir(cs: List<Candle>, a: DoubleArray, p: SetupParams, short: Boolean): List<Setup> {
        val n = cs.size
        val o = DoubleArray(n) { if (short) cs[it].o else -cs[it].o }
        val h = DoubleArray(n) { if (short) cs[it].h else -cs[it].l }
        val l = DoubleArray(n) { if (short) cs[it].l else -cs[it].h }
        val c = DoubleArray(n) { if (short) cs[it].c else -cs[it].c }
        fun px(x: Double): Double = if (short) x else -x
        // swing lows (strength 3), known 3 candles after they form
        val pv = ArrayList<Int>()
        for (q in 3 until n - 3) {
            var ok = true
            for (d in 1..3) if (l[q - d] <= l[q] || l[q + d] <= l[q]) { ok = false; break }
            if (ok) pv.add(q)
        }
        /** The next level below [entry] as of candle [upTo]: the highest unbroken swing low (formed before candle [c1]) that is at least [need] away. NaN = none. */
        fun nextLevel(c1: Int, upTo: Int, entry: Double, need: Double): Double {
            var best = Double.NaN
            val from = Math.max(0, c1 - 600)
            // lowest low after each position up to upTo, built from the right
            val len = upTo - from + 1
            if (len <= 0) return best
            val suf = DoubleArray(len + 1)
            suf[len] = Double.MAX_VALUE
            for (q in len - 1 downTo 0) suf[q] = Math.min(l[from + q], suf[q + 1])
            for (idx in pv.indices.reversed()) {
                val q = pv[idx]
                if (q + 3 > c1 || q < from) { if (q < from) break; continue }
                val lv = l[q]
                if (entry - lv < need) continue
                // unbroken: no later low (up to upTo) went below it
                if (q + 1 - from <= len - 1 && suf[q + 1 - from] <= lv) continue
                if (best.isNaN() || lv > best) best = lv
            }
            return best
        }
        val minFill = 4
        val maxFill = p.omlMaxFill.coerceIn(minFill, 12)
        val out = ArrayList<Setup>()
        var lastI = -10
        for (i in 14 until n - 1) {
            val at = a[i + 1]
            if (at.isNaN() || at <= 0.0) continue
            if (i - lastI < 3) continue
            val j = i + 1
            if (c[i] <= o[i]) continue                                   // candle 1 is an up candle (liquidity)
            if (c[j] >= o[j]) continue                                   // candle 2 is a down candle
            if (Math.abs(o[j] - c[i]) > 0.15 * at) continue              // it opens where candle 1 closed
            if (o[j] - c[j] < 0.8 * at) continue                         // and it is strong
            val level = (c[i] + o[j]) / 2.0
            val stopRaw = Math.max(h[i], level) + p.stopBufAtr * at
            val stop = Math.max(stopRaw, level + 0.25 * at)
            val risk = stop - level
            if (risk <= 0.0) continue
            // candle 3 has to stay below the level
            if (j + 1 < n && h[j + 1] >= level) continue
            val s = Setup(if (short) 1 else -1, i, cs[i].t)
            s.kind = "OML"
            s.valid = true
            s.proximal = px(level)
            s.distal = px(h[i])
            s.entry = px(level)
            s.stop = px(stop)
            s.risk = risk
            s.lockIdx = j
            s.lockT = cs[j].t
            s.touchIdx = i
            s.state = ST_WAITING
            if (j + 1 < n) { s.liq = px(h[j + 1]); s.liqIdx = j + 1 }
            // candles 4 to maxFill (candle 1 is number 1)
            var filled = -1
            var k = i + 3
            while (k <= i + maxFill - 1 && k < n) {
                if (h[k] >= level) { filled = k; break }
                k += 1
            }
            val lvNow = nextLevel(i, n - 1, level, p.minRR * risk)
            s.target = px(if (lvNow.isNaN()) level - p.minRR * risk else lvNow)
            s.rr = (level - (if (lvNow.isNaN()) level - p.minRR * risk else lvNow)) / risk
            if (filled < 0) {
                if (i + maxFill - 1 < n) {
                    s.state = ST_DEAD
                    s.why = "price did not come back to the level on candles 4 to " + maxFill
                    s.endIdx = Math.min(n - 1, i + maxFill - 1)
                    s.endT = cs[s.endIdx].t
                }
                out.add(s)
                lastI = i
                continue
            }
            s.fillIdx = filled
            s.fillT = cs[filled].t
            lastI = i
            out.add(s)
            // the next level as it was known when the entry filled (nothing from the future)
            val lv = nextLevel(i, filled - 1, level, p.minRR * risk)
            if (lv.isNaN()) { s.state = ST_DEAD; s.why = "no swing low below that pays " + p.minRR + "R"; s.fillIdx = -1; s.endIdx = filled; s.endT = cs[filled].t; continue }
            s.target = px(lv)
            s.rr = (level - lv) / risk
            if (h[filled] >= stop) { s.state = ST_LOSS; s.endIdx = filled; s.endT = cs[filled].t; s.result = -1.0; continue }
            s.state = ST_ACTIVE
            var q = filled + 1
            val tgt = lv
            while (q < n) {
                if (h[q] >= stop) { s.state = ST_LOSS; s.endIdx = q; s.endT = cs[q].t; s.result = -1.0; break }
                if (l[q] <= tgt) { s.state = ST_WIN; s.endIdx = q; s.endT = cs[q].t; s.result = s.rr; break }
                if (q - filled > p.maxActiveBars) { s.state = ST_FLAT; s.endIdx = q; s.endT = cs[q].t; s.result = (level - c[q]) / risk; break }
                q += 1
            }
        }
        return out
    }
}
