package online.wickwatch.app

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** A point in time and price, so a drawing stays where it was put on every timeframe. */
data class DPoint(val t: Long, val p: Double)

class Drawing(
    val id: String,
    val type: String,
    var pts: List<DPoint>,
    var color: Long,
    var text: String = "",
    var locked: Boolean = false,
    var width: Int = 2,
    var dashed: Boolean = false,
)

/**
 * One drawing tool. [kind] says how it is drawn, [n] how many taps it needs (0 = drag freehand, -1 = tap points then Done).
 * [labels] are the names of the points for pattern tools. [ready] false = shown in the list as "soon".
 */
class ToolSpec(val id: String, val name: String, val cat: String, val kind: String, val n: Int, val ready: Boolean = true, val labels: String = "")

object Tools {
    val CATS: List<String> = listOf("Trend tools", "Gann and Fibonacci", "Patterns", "Forecasting and measurement", "Geometric shapes", "Annotation", "Visuals")

    private fun t(id: String, name: String, cat: String, kind: String, n: Int, labels: String = "") = ToolSpec(id, name, cat, kind, n, true, labels)
    private fun soon(id: String, name: String, cat: String) = ToolSpec(id, name, cat, "", 0, false)

    val ALL: List<ToolSpec> = listOf(
        t("trend", "Trendline", "Trend tools", "seg", 2),
        t("ray", "Ray", "Trend tools", "ray", 2),
        t("info", "Info line", "Trend tools", "info", 2),
        t("ext", "Extended line", "Trend tools", "ext", 2),
        soon("angle", "Trend angle", "Trend tools"),
        t("hline", "Horizontal line", "Trend tools", "hline", 1),
        t("hray", "Horizontal ray", "Trend tools", "hray", 1),
        t("vline", "Vertical line", "Trend tools", "vline", 1),
        t("cross", "Crossline", "Trend tools", "cross", 1),
        t("pchan", "Parallel channel", "Trend tools", "pchan", 3),
        soon("regr", "Regression trend", "Trend tools"),
        t("flat", "Flat top/bottom", "Trend tools", "flat", 3),
        t("disjoint", "Disjoint channel", "Trend tools", "disjoint", 4),
        t("pitchfork", "Pitchfork", "Trend tools", "pitchfork", 3),
        soon("schiff", "Schiff pitchfork", "Trend tools"),
        soon("mschiff", "Modified Schiff", "Trend tools"),
        soon("inside", "Inside pitchfork", "Trend tools"),

        t("fib", "Fib retracement", "Gann and Fibonacci", "fib", 2),
        t("fibext", "Trend-based Fib extension", "Gann and Fibonacci", "fibext", 3),
        t("fibchan", "Fib channel", "Gann and Fibonacci", "fibchan", 3),
        t("fibtime", "Fib time zone", "Gann and Fibonacci", "fibtime", 2),
        soon("fibspeed", "Fib speed resistance fan", "Gann and Fibonacci"),
        soon("fibcircles", "Fib circles", "Gann and Fibonacci"),
        soon("fibspiral", "Fib spiral", "Gann and Fibonacci"),
        soon("fibwedge", "Fib wedge", "Gann and Fibonacci"),
        soon("pitchfan", "Pitchfan", "Gann and Fibonacci"),
        soon("gannbox", "Gann box", "Gann and Fibonacci"),
        soon("gannsq", "Gann square", "Gann and Fibonacci"),
        soon("gannfan", "Gann fan", "Gann and Fibonacci"),

        t("xabcd", "XABCD pattern", "Patterns", "poly", 5, "X,A,B,C,D"),
        t("cypher", "Cypher pattern", "Patterns", "poly", 5, "X,A,B,C,D"),
        t("abcd", "ABCD pattern", "Patterns", "poly", 4, "A,B,C,D"),
        t("hs", "Head and shoulders", "Patterns", "poly", 7, "-,LS,-,Head,-,RS,-"),
        t("tripat", "Triangle pattern", "Patterns", "poly", 4, "A,B,C,D"),
        t("drives", "Three drives pattern", "Patterns", "poly", 7, "0,1,2,3,4,5,6"),
        t("elimp", "Elliott impulse wave", "Patterns", "poly", 6, "0,1,2,3,4,5"),
        t("elcor", "Elliott correction wave", "Patterns", "poly", 4, "0,A,B,C"),
        t("eltri", "Elliott triangle wave", "Patterns", "poly", 6, "0,A,B,C,D,E"),
        t("eldbl", "Elliott double combo", "Patterns", "poly", 4, "0,W,X,Y"),
        t("eltrp", "Elliott triple combo", "Patterns", "poly", 6, "0,W,X,Y,X,Z"),
        t("cyclic", "Cyclic lines", "Patterns", "cyclic", 2),
        soon("timecycles", "Time cycles", "Patterns"),
        soon("sine", "Sine line", "Patterns"),

        t("long", "Long position", "Forecasting and measurement", "long", 2),
        t("short", "Short position", "Forecasting and measurement", "short", 2),
        t("prange", "Price range", "Forecasting and measurement", "prange", 2),
        t("drange", "Date range", "Forecasting and measurement", "drange", 2),
        t("pdrange", "Date and price range", "Forecasting and measurement", "pdrange", 2),
        soon("posfore", "Position forecast", "Forecasting and measurement"),
        soon("barpat", "Bar pattern", "Forecasting and measurement"),
        soon("ghost", "Ghost feed", "Forecasting and measurement"),
        soon("avwap", "Anchored VWAP", "Forecasting and measurement"),
        soon("frvp", "Fixed range volume profile", "Forecasting and measurement"),

        t("brush", "Brush", "Geometric shapes", "brush", 0),
        t("highlighter", "Highlighter", "Geometric shapes", "highlighter", 0),
        t("arrowm", "Arrow marker", "Geometric shapes", "arrowm", 2),
        t("arrow", "Arrow", "Geometric shapes", "arrow", 2),
        t("arrowup", "Arrow mark up", "Geometric shapes", "marker", 1, "up"),
        t("arrowdn", "Arrow mark down", "Geometric shapes", "marker", 1, "down"),
        t("rect", "Rectangle", "Geometric shapes", "rect", 2),
        t("path", "Path", "Geometric shapes", "path", -1),
        t("circle", "Circle", "Geometric shapes", "circle", 2),
        t("ellipse", "Ellipse", "Geometric shapes", "ellipse", 2),
        t("polyline", "Polyline", "Geometric shapes", "polyline", -1),
        t("tri", "Triangle", "Geometric shapes", "tri", 3),
        soon("rrect", "Rotated rectangle", "Geometric shapes"),
        soon("arc", "Arc", "Geometric shapes"),
        soon("curve", "Curve", "Geometric shapes"),
        soon("dcurve", "Double curve", "Geometric shapes"),

        t("text", "Text", "Annotation", "text", 1),
        t("note", "Note", "Annotation", "note", 1),
        t("pricenote", "Price note", "Annotation", "pnote", 1),
        t("pin", "Pin", "Annotation", "marker", 1, "pin"),
        t("callout", "Callout", "Annotation", "callout", 1),
        t("comment", "Comment", "Annotation", "comment", 1),
        t("plabel", "Price label", "Annotation", "plabel", 1),
        t("flag", "Flag mark", "Annotation", "marker", 1, "flag"),
        soon("anchored", "Anchored text", "Annotation"),
        soon("table", "Table", "Annotation"),
        soon("image", "Image", "Annotation"),

        t("emoji", "Emoji", "Visuals", "emoji", 1),
        soon("stickers", "Stickers", "Visuals"),
        soon("icons", "Icons", "Visuals"),
    )

    fun spec(id: String): ToolSpec? = ALL.firstOrNull { it.id == id }

    /** Tools that need text typed (or an emoji picked) after the point is placed. */
    fun needsText(kind: String): Boolean = kind == "text" || kind == "note" || kind == "pnote" || kind == "callout" || kind == "comment" || kind == "emoji"
}

private val FIB = doubleArrayOf(0.0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0)
private val FIBEXT = doubleArrayOf(0.0, 0.618, 1.0, 1.272, 1.618, 2.0, 2.618)
private val FIBTIME = intArrayOf(0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89)

fun DrawScope.chartText(text: String, x: Float, y: Float, color: Int, sizeSp: Float, right: Boolean = false, bold: Boolean = false) {
    drawIntoCanvas { c ->
        val p = android.graphics.Paint()
        p.isAntiAlias = true
        p.color = color
        p.textSize = sizeSp.sp.toPx()
        p.textAlign = if (right) android.graphics.Paint.Align.RIGHT else android.graphics.Paint.Align.LEFT
        if (bold) p.isFakeBoldText = true
        c.nativeCanvas.drawText(text, x, y, p)
    }
}

private fun DrawScope.textWidth(text: String, sizeSp: Float): Float {
    val p = android.graphics.Paint()
    p.textSize = sizeSp.sp.toPx()
    return p.measureText(text)
}

private fun spanText(sec: Long): String {
    val s = abs(sec)
    val d = s / 86400L
    val h = (s % 86400L) / 3600L
    val m = (s % 3600L) / 60L
    return if (d > 0) d.toString() + "d " + h + "h" else if (h > 0) h.toString() + "h " + m + "m" else m.toString() + "m"
}

private fun extend(a: Offset, b: Offset, forward: Boolean, backward: Boolean): Pair<Offset, Offset> {
    val dx = b.x - a.x
    val dy = b.y - a.y
    val len = sqrt(dx * dx + dy * dy)
    if (len < 0.001f) return Pair(a, b)
    val k = 20000f / len
    val s = if (backward) Offset(a.x - dx * k, a.y - dy * k) else a
    val e = if (forward) Offset(a.x + dx * k, a.y + dy * k) else b
    return Pair(s, e)
}

/** How far (vertically) the line through [c] parallel to a-b is from a-b. */
private fun shiftY(a: Offset, b: Offset, c: Offset): Float {
    val dx = b.x - a.x
    if (abs(dx) < 0.001f) return 0f
    val slope = (b.y - a.y) / dx
    return c.y - (a.y + slope * (c.x - a.x))
}

object Draw {
    fun scr(g: Geo, p: DPoint): Offset = Offset(g.xAt(g.idxOfTime(p.t)), g.yAt(p.p))

    /** A tap or drag position as a time and price. With [snap], it sticks to a nearby open, high, low or close. */
    fun fromScreen(g: Geo, cs: List<Candle>, o: Offset, snap: Boolean, centre: Boolean = false): DPoint {
        val idx = g.idxAtX(o.x)
        var price = g.priceAtY(o.y)
        var t = g.timeOfIdx(idx)
        if (snap && cs.isNotEmpty()) {
            val i = Math.round(idx).toInt()
            if (i >= 0 && i < cs.size) {
                val c = cs[i]
                var best = price
                var bd = 30f
                for (v in doubleArrayOf(c.o, c.h, c.l, c.c)) {
                    val d = abs(g.yAt(v) - o.y)
                    if (d < bd) {
                        bd = d
                        best = v
                    }
                }
                if (bd < 30f) {
                    price = best
                    t = c.t
                }
            }
        }
        // a vertical line sits exactly in the middle of the candle it is put on
        if (centre) t = g.timeOfIdx(Math.rint(idx))
        return DPoint(t, price)
    }

    /** Builds a finished drawing from the tapped points. */
    fun make(spec: ToolSpec, pts: List<DPoint>, text: String): Drawing {
        var p = pts
        if (spec.kind == "long" || spec.kind == "short") {
            val entry = pts[0]
            val risk = max(abs(entry.p - pts[1].p), entry.p * 0.0005)
            val sign = if (spec.kind == "long") 1.0 else -1.0
            val stop = entry.p - sign * risk
            val target = entry.p + sign * risk * 2.0
            p = listOf(entry, DPoint(pts[1].t, stop), DPoint(pts[1].t, target))
        }
        val c = colorLong(Brand.Primary)
        val color = if (spec.kind == "highlighter") 0xFFFACC15 else c
        return Drawing(UUID.randomUUID().toString(), spec.id, p, color, text, false, if (spec.kind == "highlighter") 12 else 2, false)
    }

    fun handles(d: Drawing, g: Geo): List<Offset> {
        val k = Tools.spec(d.type)?.kind ?: return emptyList()
        if (k == "brush" || k == "highlighter") return emptyList()
        return d.pts.map { scr(g, it) }
    }

    private fun distSeg(px: Float, py: Float, a: Offset, b: Offset): Float {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val l2 = dx * dx + dy * dy
        if (l2 < 0.0001f) return sqrt((px - a.x) * (px - a.x) + (py - a.y) * (py - a.y))
        val t = (((px - a.x) * dx + (py - a.y) * dy) / l2).coerceIn(0f, 1f)
        val cx = a.x + t * dx
        val cy = a.y + t * dy
        return sqrt((px - cx) * (px - cx) + (py - cy) * (py - cy))
    }

    /** Distance in pixels from (x, y) to the drawing; 0 when inside a filled shape. */
    fun hitDist(d: Drawing, g: Geo, x: Float, y: Float): Float {
        val spec = Tools.spec(d.type) ?: return 1e9f
        val P = d.pts.map { scr(g, it) }
        if (P.isEmpty()) return 1e9f
        fun poly(): Float {
            var best = 1e9f
            for (i in 0 until P.size - 1) best = min(best, distSeg(x, y, P[i], P[i + 1]))
            return best
        }
        fun box(extendRight: Boolean): Float {
            val x0 = P.minOf { it.x }
            val x1 = if (extendRight) g.pw else P.maxOf { it.x }
            val y0 = P.minOf { it.y }
            val y1 = P.maxOf { it.y }
            val inside = x in x0..x1 && y in y0..y1
            if (inside) return 0f
            val dx = max(max(x0 - x, 0f), x - x1)
            val dy = max(max(y0 - y, 0f), y - y1)
            return sqrt(dx * dx + dy * dy)
        }
        return when (spec.kind) {
            "hline" -> abs(y - P[0].y)
            "vline" -> abs(x - P[0].x)
            "hray" -> if (x >= P[0].x) abs(y - P[0].y) else sqrt((x - P[0].x) * (x - P[0].x) + (y - P[0].y) * (y - P[0].y))
            "cross" -> min(abs(y - P[0].y), abs(x - P[0].x))
            "seg", "info", "arrow", "arrowm" -> if (P.size >= 2) distSeg(x, y, P[0], P[1]) else 1e9f
            "ray" -> if (P.size >= 2) { val e = extend(P[0], P[1], true, false); distSeg(x, y, e.first, e.second) } else 1e9f
            "ext" -> if (P.size >= 2) { val e = extend(P[0], P[1], true, true); distSeg(x, y, e.first, e.second) } else 1e9f
            "poly", "path", "brush", "highlighter", "polyline", "tri", "flat", "disjoint", "pitchfork" -> poly()
            "fib", "fibext", "fibchan", "fibtime", "pchan", "cyclic" -> box(spec.kind == "fib" || spec.kind == "fibext")
            "long", "short", "rect", "pdrange", "prange", "drange", "circle", "ellipse" -> box(false)
            else -> sqrt((x - P[0].x) * (x - P[0].x) + (y - P[0].y) * (y - P[0].y))
        }
    }

    /** Moves one handle. Position tools keep their stop and target on the same right edge. */
    fun movePoint(d: Drawing, g: Geo, cs: List<Candle>, i: Int, o: Offset, snap: Boolean) {
        val k = Tools.spec(d.type)?.kind
        val np = fromScreen(g, cs, o, snap, k == "vline")
        val list = d.pts.toMutableList()
        if ((k == "long" || k == "short") && list.size >= 3) {
            when (i) {
                0 -> list[0] = np
                1 -> { list[1] = np; list[2] = DPoint(np.t, list[2].p) }
                else -> { list[2] = np; list[1] = DPoint(np.t, list[1].p) }
            }
        } else if (i >= 0 && i < list.size) {
            list[i] = np
        }
        d.pts = list
    }

    /** Moves the whole drawing by a number of candles and an amount in scale space. */
    fun translate(g: Geo, orig: List<DPoint>, dIdx: Double, dTr: Double): List<DPoint> =
        orig.map { DPoint(g.timeOfIdx(g.idxOfTime(it.t) + dIdx), g.inv(g.tr(it.p) + dTr)) }
}

private fun DrawScope.arrowHead(from: Offset, to: Offset, size: Float, color: Color) {
    val dx = to.x - from.x
    val dy = to.y - from.y
    val len = sqrt(dx * dx + dy * dy)
    if (len < 1f) return
    val ux = dx / len
    val uy = dy / len
    val path = Path()
    path.moveTo(to.x, to.y)
    path.lineTo(to.x - ux * size - uy * size * 0.5f, to.y - uy * size + ux * size * 0.5f)
    path.lineTo(to.x - ux * size + uy * size * 0.5f, to.y - uy * size - ux * size * 0.5f)
    path.close()
    drawPath(path, color)
}

private fun DrawScope.tag(text: String, x: Float, y: Float, bg: Color, fg: Int, sizeSp: Float) {
    val w = textWidth(text, sizeSp) + 12.dp.toPx()
    val h = sizeSp.sp.toPx() + 8.dp.toPx()
    drawRoundRect(bg, Offset(x, y - h), Size(w, h), androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()))
    chartText(text, x + 6.dp.toPx(), y - 5.dp.toPx(), fg, sizeSp)
}

/** Draws one drawing. [dec] is the number of price decimals of the market. Call inside the price pane's clip. */
fun DrawScope.drawDrawing(d: Drawing, g: Geo, sel: Boolean, dec: Int) {
    val spec = Tools.spec(d.type) ?: return
    val P = d.pts.map { Draw.scr(g, it) }
    if (P.isEmpty()) return
    val col = Color(d.color)
    val ci = col.toArgb()
    val sw = d.width.coerceIn(1, 14).toFloat() * 1.dp.toPx()
    val eff = if (d.dashed) PathEffect.dashPathEffect(floatArrayOf(14f, 10f)) else null
    val fill = col.copy(alpha = 0.14f)
    val line = col.copy(alpha = if (spec.kind == "highlighter") 0.35f else 1f)

    fun seg(a: Offset, b: Offset) = drawLine(line, a, b, sw, pathEffect = eff)
    fun polyPath(closed: Boolean): Path {
        val p = Path()
        p.moveTo(P[0].x, P[0].y)
        for (i in 1 until P.size) p.lineTo(P[i].x, P[i].y)
        if (closed) p.close()
        return p
    }

    when (spec.kind) {
        "seg" -> if (P.size >= 2) seg(P[0], P[1])
        "arrow", "arrowm" -> if (P.size >= 2) {
            seg(P[0], P[1])
            arrowHead(P[0], P[1], sw * (if (spec.kind == "arrowm") 5f else 3.5f) + 6f, col)
        }
        "ray" -> if (P.size >= 2) { val e = extend(P[0], P[1], true, false); seg(e.first, e.second) }
        "ext" -> if (P.size >= 2) { val e = extend(P[0], P[1], true, true); seg(e.first, e.second) }
        "info" -> if (P.size >= 2) {
            seg(P[0], P[1])
            val dp = d.pts[1].p - d.pts[0].p
            val bars = abs(g.idxOfTime(d.pts[1].t) - g.idxOfTime(d.pts[0].t)).roundToInt()
            val pct = if (d.pts[0].p != 0.0) dp / d.pts[0].p * 100.0 else 0.0
            tag(fp(dp, dec) + " (" + fp(pct, 2) + "%)  " + bars + " bars", (P[0].x + P[1].x) / 2f, (P[0].y + P[1].y) / 2f - 6.dp.toPx(), Brand.Elevated, Brand.Text.toArgb(), 11f)
        }
        "hline" -> {
            seg(Offset(0f, P[0].y), Offset(g.pw, P[0].y))
            chartText(fp(d.pts[0].p, dec), g.pw - 6.dp.toPx(), P[0].y - 4.dp.toPx(), ci, 11f, right = true)
        }
        "hray" -> seg(P[0], Offset(g.pw, P[0].y))
        "vline" -> seg(Offset(P[0].x, g.top), Offset(P[0].x, g.bottom))
        "cross" -> {
            seg(Offset(0f, P[0].y), Offset(g.pw, P[0].y))
            seg(Offset(P[0].x, g.top), Offset(P[0].x, g.bottom))
        }
        "pchan" -> if (P.size >= 3) {
            val s = shiftY(P[0], P[1], P[2])
            val a2 = Offset(P[0].x, P[0].y + s)
            val b2 = Offset(P[1].x, P[1].y + s)
            val path = Path()
            path.moveTo(P[0].x, P[0].y); path.lineTo(P[1].x, P[1].y); path.lineTo(b2.x, b2.y); path.lineTo(a2.x, a2.y); path.close()
            drawPath(path, fill)
            seg(P[0], P[1]); seg(a2, b2)
            drawLine(col.copy(alpha = 0.5f), Offset(P[0].x, P[0].y + s / 2f), Offset(P[1].x, P[1].y + s / 2f), sw * 0.6f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
        } else if (P.size == 2) seg(P[0], P[1])
        "flat" -> if (P.size >= 3) {
            val y2 = P[2].y
            val path = Path()
            path.moveTo(P[0].x, P[0].y); path.lineTo(P[1].x, P[1].y); path.lineTo(P[1].x, y2); path.lineTo(P[0].x, y2); path.close()
            drawPath(path, fill)
            seg(P[0], P[1]); seg(Offset(P[0].x, y2), Offset(P[1].x, y2))
        } else if (P.size == 2) seg(P[0], P[1])
        "disjoint" -> if (P.size >= 4) {
            val path = Path()
            path.moveTo(P[0].x, P[0].y); path.lineTo(P[1].x, P[1].y); path.lineTo(P[3].x, P[3].y); path.lineTo(P[2].x, P[2].y); path.close()
            drawPath(path, fill)
            seg(P[0], P[1]); seg(P[2], P[3])
        } else if (P.size >= 2) seg(P[0], P[1])
        "pitchfork" -> if (P.size >= 3) {
            val m = Offset((P[1].x + P[2].x) / 2f, (P[1].y + P[2].y) / 2f)
            val v = Offset(m.x - P[0].x, m.y - P[0].y)
            val e0 = extend(P[0], m, true, false)
            seg(e0.first, e0.second)
            val e1 = extend(P[1], Offset(P[1].x + v.x, P[1].y + v.y), true, false)
            seg(e1.first, e1.second)
            val e2 = extend(P[2], Offset(P[2].x + v.x, P[2].y + v.y), true, false)
            seg(e2.first, e2.second)
            drawLine(col.copy(alpha = 0.5f), P[1], P[2], sw * 0.6f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
        } else if (P.size >= 2) seg(P[0], P[1])
        "fib" -> if (P.size >= 2) {
            val x0 = min(P[0].x, P[1].x)
            val x1 = g.pw
            drawLine(col.copy(alpha = 0.5f), P[0], P[1], sw * 0.7f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
            var prevY = Float.NaN
            for ((k, r) in FIB.withIndex()) {
                val price = d.pts[1].p + (d.pts[0].p - d.pts[1].p) * r
                val y = g.yAt(price)
                if (!prevY.isNaN() && k % 2 == 1) drawRect(fill.copy(alpha = 0.08f), Offset(x0, min(y, prevY)), Size(x1 - x0, abs(y - prevY)))
                drawLine(line, Offset(x0, y), Offset(x1, y), sw * 0.7f)
                chartText(fp(r, 3) + "  " + fp(price, dec), x0 + 4.dp.toPx(), y - 3.dp.toPx(), ci, 10f)
                prevY = y
            }
        }
        "fibext" -> if (P.size >= 3) {
            val x0 = P[2].x
            val x1 = g.pw
            drawLine(col.copy(alpha = 0.5f), P[0], P[1], sw * 0.7f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
            drawLine(col.copy(alpha = 0.5f), P[1], P[2], sw * 0.7f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
            for (r in FIBEXT) {
                val price = d.pts[2].p + (d.pts[1].p - d.pts[0].p) * r
                val y = g.yAt(price)
                drawLine(line, Offset(x0, y), Offset(x1, y), sw * 0.7f)
                chartText(fp(r, 3) + "  " + fp(price, dec), x0 + 4.dp.toPx(), y - 3.dp.toPx(), ci, 10f)
            }
        } else if (P.size >= 2) seg(P[0], P[1])
        "fibchan" -> if (P.size >= 3) {
            val s = shiftY(P[0], P[1], P[2])
            for (r in FIB) {
                val e = extend(Offset(P[0].x, P[0].y + s * r.toFloat()), Offset(P[1].x, P[1].y + s * r.toFloat()), true, false)
                drawLine(line, e.first, e.second, sw * 0.7f)
                chartText(fp(r, 3), P[1].x + 4.dp.toPx(), P[1].y + s * r.toFloat() - 3.dp.toPx(), ci, 10f)
            }
        } else if (P.size >= 2) seg(P[0], P[1])
        "fibtime" -> if (P.size >= 2) {
            val i0 = g.idxOfTime(d.pts[0].t)
            val unit = g.idxOfTime(d.pts[1].t) - i0
            for (f in FIBTIME) {
                val x = g.xAt(i0 + unit * f)
                if (x < -10f || x > g.pw + 10f) continue
                drawLine(line, Offset(x, g.top), Offset(x, g.bottom), sw * 0.7f)
                chartText(f.toString(), x + 3.dp.toPx(), g.top + 12.dp.toPx(), ci, 10f)
            }
        }
        "cyclic" -> if (P.size >= 2) {
            val i0 = g.idxOfTime(d.pts[0].t)
            val unit = g.idxOfTime(d.pts[1].t) - i0
            if (abs(unit) > 0.5) {
                for (k in -60..120) {
                    val x = g.xAt(i0 + unit * k)
                    if (x < 0f || x > g.pw) continue
                    drawLine(line, Offset(x, g.top), Offset(x, g.bottom), sw * 0.6f)
                }
            }
        }
        "poly", "path", "polyline" -> {
            if (P.size >= 2) {
                if (spec.kind == "polyline" && P.size >= 3) drawPath(polyPath(true), fill)
                drawPath(polyPath(spec.kind == "polyline"), line, style = Stroke(width = sw, pathEffect = eff))
            }
            val ls = spec.labels.split(',')
            for (i in P.indices) {
                val lb = ls.getOrNull(i)
                if (lb != null && lb != "-" && lb.isNotEmpty()) chartText(lb, P[i].x + 5.dp.toPx(), P[i].y - 5.dp.toPx(), ci, 11f, bold = true)
            }
        }
        "brush", "highlighter" -> if (P.size >= 2) drawPath(polyPath(false), line, style = Stroke(width = sw, cap = androidx.compose.ui.graphics.StrokeCap.Round))
        "long", "short" -> if (P.size >= 3) {
            val entry = d.pts[0].p
            val stop = d.pts[1].p
            val target = d.pts[2].p
            val x0 = P[0].x
            val x1 = max(P[1].x, x0 + 24.dp.toPx())
            val reward = Color(0xFF22C55E)
            val risk = Color(0xFFF2495C)
            drawRect(reward.copy(alpha = 0.2f), Offset(x0, min(P[0].y, P[2].y)), Size(x1 - x0, abs(P[2].y - P[0].y)))
            drawRect(risk.copy(alpha = 0.2f), Offset(x0, min(P[0].y, P[1].y)), Size(x1 - x0, abs(P[1].y - P[0].y)))
            drawLine(col, Offset(x0, P[0].y), Offset(x1, P[0].y), sw)
            drawLine(risk, Offset(x0, P[1].y), Offset(x1, P[1].y), sw)
            drawLine(reward, Offset(x0, P[2].y), Offset(x1, P[2].y), sw)
            val rr = if (abs(entry - stop) > 0) abs(target - entry) / abs(entry - stop) else 0.0
            val tp = if (entry != 0.0) (target / entry - 1.0) * 100.0 else 0.0
            val sp = if (entry != 0.0) (stop / entry - 1.0) * 100.0 else 0.0
            val tUp = P[2].y < P[0].y
            val sDown = P[1].y > P[0].y
            val riskMoney = Store.account * Store.riskPct / 100.0
            chartText("Target " + fp(target, dec) + " (" + fp(tp, 2) + "%)  +" + fp(riskMoney * rr, 2), x0 + 4.dp.toPx(), P[2].y + (if (tUp) -4.dp.toPx() else 14.dp.toPx()), ci, 11f)
            chartText("Stop " + fp(stop, dec) + " (" + fp(sp, 2) + "%)  -" + fp(riskMoney, 2), x0 + 4.dp.toPx(), P[1].y + (if (sDown) 14.dp.toPx() else -4.dp.toPx()), ci, 11f)
            // entry label goes inside the reward box, on the side away from the stop
            chartText("Entry " + fp(entry, dec) + "   RR " + fp(rr, 2), x0 + 4.dp.toPx(), P[0].y + (if (tUp) -4.dp.toPx() else 14.dp.toPx()), ci, 11f, bold = true)
        }
        "prange" -> if (P.size >= 2) {
            val x = P[1].x
            seg(Offset(x, P[0].y), Offset(x, P[1].y))
            arrowHead(Offset(x, P[0].y), Offset(x, P[1].y), 12.dp.toPx(), col)
            val dp = d.pts[1].p - d.pts[0].p
            val pct = if (d.pts[0].p != 0.0) dp / d.pts[0].p * 100.0 else 0.0
            tag(fp(dp, dec) + " (" + fp(pct, 2) + "%)", x + 6.dp.toPx(), (P[0].y + P[1].y) / 2f, Brand.Elevated, Brand.Text.toArgb(), 11f)
        }
        "drange" -> if (P.size >= 2) {
            val y = P[1].y
            seg(Offset(P[0].x, y), Offset(P[1].x, y))
            arrowHead(Offset(P[0].x, y), Offset(P[1].x, y), 12.dp.toPx(), col)
            val bars = abs(g.idxOfTime(d.pts[1].t) - g.idxOfTime(d.pts[0].t)).roundToInt()
            tag(bars.toString() + " bars, " + spanText(d.pts[1].t - d.pts[0].t), (P[0].x + P[1].x) / 2f, y - 8.dp.toPx(), Brand.Elevated, Brand.Text.toArgb(), 11f)
        }
        "pdrange", "rect" -> if (P.size >= 2) {
            val x0 = min(P[0].x, P[1].x)
            val y0 = min(P[0].y, P[1].y)
            drawRect(fill, Offset(x0, y0), Size(abs(P[1].x - P[0].x), abs(P[1].y - P[0].y)))
            drawRect(line, Offset(x0, y0), Size(abs(P[1].x - P[0].x), abs(P[1].y - P[0].y)), style = Stroke(width = sw, pathEffect = eff))
            if (spec.kind == "pdrange") {
                val dp = d.pts[1].p - d.pts[0].p
                val bars = abs(g.idxOfTime(d.pts[1].t) - g.idxOfTime(d.pts[0].t)).roundToInt()
                tag(fp(dp, dec) + "  " + bars + " bars", x0, y0 - 4.dp.toPx(), Brand.Elevated, Brand.Text.toArgb(), 11f)
            }
        }
        "circle" -> if (P.size >= 2) {
            val r = sqrt((P[1].x - P[0].x) * (P[1].x - P[0].x) + (P[1].y - P[0].y) * (P[1].y - P[0].y))
            drawCircle(fill, r, P[0])
            drawCircle(line, r, P[0], style = Stroke(width = sw, pathEffect = eff))
        }
        "ellipse" -> if (P.size >= 2) {
            val x0 = min(P[0].x, P[1].x)
            val y0 = min(P[0].y, P[1].y)
            drawOval(fill, Offset(x0, y0), Size(abs(P[1].x - P[0].x), abs(P[1].y - P[0].y)))
            drawOval(line, Offset(x0, y0), Size(abs(P[1].x - P[0].x), abs(P[1].y - P[0].y)), style = Stroke(width = sw, pathEffect = eff))
        }
        "tri" -> if (P.size >= 3) {
            drawPath(polyPath(true), fill)
            drawPath(polyPath(true), line, style = Stroke(width = sw, pathEffect = eff))
        } else if (P.size == 2) seg(P[0], P[1])
        "text" -> chartText(d.text.ifBlank { "Text" }, P[0].x, P[0].y, ci, 15f, bold = true)
        "note", "comment" -> {
            val txt = d.text.ifBlank { "Note" }
            val w = textWidth(txt, 13f) + 16.dp.toPx()
            val h = 13.sp.toPx() + 14.dp.toPx()
            drawRoundRect(Brand.Elevated, Offset(P[0].x, P[0].y - h), Size(w, h), androidx.compose.ui.geometry.CornerRadius(if (spec.kind == "comment") h / 2f else 6.dp.toPx()))
            drawRoundRect(col, Offset(P[0].x, P[0].y - h), Size(w, h), androidx.compose.ui.geometry.CornerRadius(if (spec.kind == "comment") h / 2f else 6.dp.toPx()), style = Stroke(width = 1.dp.toPx()))
            chartText(txt, P[0].x + 8.dp.toPx(), P[0].y - 8.dp.toPx(), Brand.Text.toArgb(), 13f)
        }
        "pnote" -> {
            val txt = d.text.ifBlank { "Note" } + "  " + fp(d.pts[0].p, dec)
            val w = textWidth(txt, 13f) + 16.dp.toPx()
            val h = 13.sp.toPx() + 14.dp.toPx()
            drawLine(col, P[0], Offset(P[0].x, P[0].y - h), 1.dp.toPx())
            drawRoundRect(Brand.Elevated, Offset(P[0].x, P[0].y - 2 * h), Size(w, h), androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()))
            chartText(txt, P[0].x + 8.dp.toPx(), P[0].y - h - 8.dp.toPx(), Brand.Text.toArgb(), 13f)
            drawCircle(col, 3.dp.toPx(), P[0])
        }
        "callout" -> {
            val txt = d.text.ifBlank { "Callout" }
            val w = textWidth(txt, 13f) + 16.dp.toPx()
            val h = 13.sp.toPx() + 14.dp.toPx()
            val bx = P[0].x + 30.dp.toPx()
            val by = P[0].y - 30.dp.toPx()
            drawLine(col, P[0], Offset(bx, by), 1.dp.toPx())
            drawRoundRect(Brand.Elevated, Offset(bx, by - h), Size(w, h), androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()))
            drawRoundRect(col, Offset(bx, by - h), Size(w, h), androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()), style = Stroke(width = 1.dp.toPx()))
            chartText(txt, bx + 8.dp.toPx(), by - 8.dp.toPx(), Brand.Text.toArgb(), 13f)
            drawCircle(col, 3.dp.toPx(), P[0])
        }
        "plabel" -> tag(fp(d.pts[0].p, dec), P[0].x, P[0].y, col, Brand.Bg.toArgb(), 12f)
        "emoji" -> chartText(d.text.ifBlank { "\uD83D\uDE00" }, P[0].x - 12.dp.toPx(), P[0].y + 10.dp.toPx(), ci, 26f)
        "marker" -> {
            val k = spec.labels
            val s = 12.dp.toPx()
            val path = Path()
            when (k) {
                "up" -> { path.moveTo(P[0].x, P[0].y); path.lineTo(P[0].x - s, P[0].y + s * 1.6f); path.lineTo(P[0].x + s, P[0].y + s * 1.6f); path.close() }
                "down" -> { path.moveTo(P[0].x, P[0].y); path.lineTo(P[0].x - s, P[0].y - s * 1.6f); path.lineTo(P[0].x + s, P[0].y - s * 1.6f); path.close() }
                "flag" -> { path.moveTo(P[0].x, P[0].y); path.lineTo(P[0].x, P[0].y - s * 2.4f); path.lineTo(P[0].x + s * 1.6f, P[0].y - s * 1.8f); path.lineTo(P[0].x, P[0].y - s * 1.2f) }
                else -> { path.addOval(androidx.compose.ui.geometry.Rect(P[0].x - s * 0.6f, P[0].y - s * 2f, P[0].x + s * 0.6f, P[0].y - s * 0.8f)); path.moveTo(P[0].x - s * 0.5f, P[0].y - s * 0.9f); path.lineTo(P[0].x, P[0].y); path.lineTo(P[0].x + s * 0.5f, P[0].y - s * 0.9f) }
            }
            drawPath(path, col)
        }
        else -> {}
    }

    if (sel) {
        for (h in Draw.handles(d, g)) {
            drawCircle(Brand.Bg, 8.dp.toPx(), h)
            drawCircle(col, 8.dp.toPx(), h, style = Stroke(width = 2.dp.toPx()))
        }
        if (Draw.handles(d, g).isEmpty() && P.size >= 2) {
            val m = P[P.size / 2]
            drawCircle(col.copy(alpha = 0.5f), 8.dp.toPx(), m)
        }
    }
}
