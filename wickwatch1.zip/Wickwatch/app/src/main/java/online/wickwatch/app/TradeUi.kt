package online.wickwatch.app

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.abs

/** Pure sums for a position. */
private fun r1(v: Double): String = fp(v, 2)

/**
 * Position size calculator. Give the account size, the percent to risk, the entry and the stop (and a target if you like).
 * Shows the money at risk, how many units fit, the position value and the reward to risk.
 * The numbers are a guide: they ignore spreads, fees and the currency a pair is quoted in.
 */
@Composable
fun PositionCalcPanel(market: Market, entry0: Double, stop0: Double, target0: Double) {
    var entry by remember { mutableDoubleStateOf(entry0) }
    var stop by remember { mutableDoubleStateOf(stop0) }
    var target by remember { mutableDoubleStateOf(target0) }
    var account by remember { mutableDoubleStateOf(Store.account) }
    var risk by remember { mutableDoubleStateOf(Store.riskPct) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Muted(market.name, 12)
        DecField("Account size", account, Modifier.fillMaxWidth()) { account = it; Store.account = it; Store.save() }
        DecField("Risk per trade (%)", risk, Modifier.fillMaxWidth()) { risk = it.coerceIn(0.01, 100.0); Store.riskPct = risk; Store.save() }
        DecField("Entry price", entry, Modifier.fillMaxWidth()) { entry = it }
        DecField("Stop price", stop, Modifier.fillMaxWidth()) { stop = it }
        DecField("Target price (optional)", target, Modifier.fillMaxWidth()) { target = it }
        val dist = abs(entry - stop)
        if (entry > 0 && stop > 0 && dist > 0) {
            val riskMoney = account * risk / 100.0
            val units = riskMoney / dist
            PCard {
                Text(if (entry > stop) "Long" else "Short", fontWeight = FontWeight.Bold, color = if (entry > stop) Brand.Good else Brand.Danger)
                Row { Muted("Money at risk", 13); Text("", Modifier.weight(1f)); Mono(r1(riskMoney), 14, Brand.Text, true) }
                Row { Muted("Stop distance", 13); Text("", Modifier.weight(1f)); Mono(fp(dist, market.dec) + "  (" + r1(dist / entry * 100.0) + "%)", 14, Brand.Text, true) }
                Row { Muted("Size in units", 13); Text("", Modifier.weight(1f)); Mono(fp(units, if (units < 10) 4 else 2), 14, Brand.Text, true) }
                if (market.grp == "Forex") Row { Muted("Size in lots", 13); Text("", Modifier.weight(1f)); Mono(fp(units / 100000.0, 3), 14, Brand.Text, true) }
                Row { Muted("Position value", 13); Text("", Modifier.weight(1f)); Mono(r1(units * entry), 14, Brand.Text, true) }
                if (target > 0) {
                    val ok = if (entry > stop) target > entry else target < entry
                    if (ok) {
                        val reward = abs(target - entry) * units
                        Row { Muted("Reward at target", 13); Text("", Modifier.weight(1f)); Mono(r1(reward), 14, Brand.Good, true) }
                        Row { Muted("Reward to risk", 13); Text("", Modifier.weight(1f)); Mono("1 : " + r1(abs(target - entry) / dist), 14, Brand.Text, true) }
                    } else {
                        Muted("The target is on the wrong side of the entry.", 12)
                    }
                }
            }
        } else {
            Muted("Enter an entry and a stop to see the size.", 12)
        }
    }
}

private val RESULTS = listOf("Open", "Win", "Loss", "Break even")

/** Saves a trade idea. The chart picture is taken only when the switch is on. */
@Composable
fun JournalAddDialog(market: Market, entry0: Double, stop0: Double, target0: Double, onDismiss: () -> Unit, takeShot: () -> String, onSaved: () -> Unit) {
    var side by remember { mutableStateOf(if (stop0 > 0 && stop0 > entry0) "Short" else "Long") }
    var entry by remember { mutableDoubleStateOf(entry0) }
    var stop by remember { mutableDoubleStateOf(stop0) }
    var target by remember { mutableDoubleStateOf(target0) }
    var notes by remember { mutableStateOf("") }
    var shot by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Elevated,
        title = { Text("Save to journal", color = Brand.Text) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Muted(market.name, 12)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ChoiceChip("Long", side == "Long") { side = "Long" }
                    ChoiceChip("Short", side == "Short") { side = "Short" }
                }
                DecField("Entry", entry, Modifier.fillMaxWidth()) { entry = it }
                DecField("Stop", stop, Modifier.fillMaxWidth()) { stop = it }
                DecField("Target", target, Modifier.fillMaxWidth()) { target = it }
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Keep a picture of the chart", Modifier.weight(1f), color = Brand.Text)
                    Switch(checked = shot, onCheckedChange = { shot = it })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val pic = if (shot) takeShot() else ""
                Store.upsertJournal(JournalEntry(UUID.randomUUID().toString(), System.currentTimeMillis(), market.key, side, entry, stop, target, "Open", notes.trim(), pic))
                onSaved()
            }) { Text("Save", color = Brand.Alert, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Brand.Muted) } },
    )
}

private fun rOf(e: JournalEntry): Double {
    val risk = abs(e.entry - e.stop)
    if (risk <= 0.0) return 0.0
    return when (e.result) {
        "Win" -> abs(e.target - e.entry) / risk
        "Loss" -> -1.0
        else -> 0.0
    }
}

@Composable
private fun Thumb(uri: String) {
    val ctx = LocalContext.current
    val bmp by produceState<android.graphics.Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            try {
                val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it, null, o) }
            } catch (e: Exception) {
                null
            }
        }
    }
    val b = bmp
    if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxWidth().height(150.dp), contentScale = ContentScale.Crop)
}

@Composable
fun JournalPage() {
    val fmt = remember { SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault()) }
    val list = Store.journal
    val closed = list.filter { it.result != "Open" }
    val wins = closed.count { it.result == "Win" }
    val totalR = closed.sumOf { rOf(it) }
    PCard {
        Row {
            Column(Modifier.weight(1f)) { Muted("Trades", 12); Mono(list.size.toString(), 18, Brand.Text, true) }
            Column(Modifier.weight(1f)) { Muted("Win rate", 12); Mono(if (closed.isEmpty()) "-" else fp(wins * 100.0 / closed.size, 0) + "%", 18, Brand.Text, true) }
            Column(Modifier.weight(1f)) { Muted("Total R", 12); Mono((if (totalR > 0) "+" else "") + fp(totalR, 2), 18, if (totalR >= 0) Brand.Good else Brand.Danger, true) }
        }
    }
    if (list.isEmpty()) Muted("Nothing yet. On the chart open the Analysis hub and tap Save to journal.", 13)
    for (e in list) {
        val m = marketByKey(e.key)
        PCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text((m?.name ?: e.key) + "  " + e.side, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = if (e.side == "Long") Brand.Good else Brand.Danger)
                    Muted(fmt.format(Date(e.time)))
                }
                if (e.result != "Open") Mono((if (rOf(e) > 0) "+" else "") + fp(rOf(e), 2) + "R", 14, if (rOf(e) >= 0) Brand.Good else Brand.Danger, true)
            }
            val dec = m?.dec ?: 2
            Muted("Entry " + fp(e.entry, dec) + "   Stop " + fp(e.stop, dec) + "   Target " + fp(e.target, dec), 12)
            if (e.notes.isNotBlank()) Text(e.notes, fontSize = 13.sp, color = Brand.Text)
            if (e.shot.isNotBlank()) Thumb(e.shot)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                for (r in RESULTS) ChoiceChip(r, e.result == r) { Store.upsertJournal(e.copy(result = r)) }
                TextButton(onClick = { Store.removeJournal(e.id) }) { Text("Delete", color = Brand.Danger) }
            }
        }
    }
}
