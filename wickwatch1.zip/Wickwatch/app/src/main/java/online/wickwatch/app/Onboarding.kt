package online.wickwatch.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val LAST_STEP = 6

/**
 * The first-run setup: theme, candle colours, chart defaults, markets, favourite tools, alert style.
 * Every choice is saved the moment it is made, and the screen re-themes live, so the person sees the result at once.
 */
@Composable
fun Onboarding(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableIntStateOf(0) }
    var profile by rememberSaveable { mutableIntStateOf(-1) }
    var startNow by rememberSaveable { mutableStateOf(true) }
    BackHandler(enabled = step > 0) { step -= 1 }

    fun finish() {
        Store.onboarded = true
        Store.save()
        if (startNow && Store.watch.isNotEmpty()) {
            Store.watching = true
            Store.save()
            WatchService.start(ctx)
        }
        onDone()
    }

    Column(Modifier.fillMaxSize().background(Brand.Bg).statusBarsPadding().navigationBarsPadding()) {
        // progress
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 0..LAST_STEP) {
                Box(
                    Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp))
                        .background(if (i <= step) Brand.Primary else Brand.Border),
                )
            }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            when (step) {
                0 -> {
                    Text("Wickwatch", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Text, modifier = Modifier.padding(top = 24.dp))
                    Text("Charts and price alerts for Deriv and Binance markets, with a watcher that keeps working while the app is closed.", color = Brand.Text, fontSize = 16.sp)
                    Muted("A short setup follows: theme, candle colours, chart defaults, markets, favourite drawing tools and how loud alerts should be. It takes about a minute. Everything can be changed later in More.", 14)
                }
                1 -> {
                    StepTitle("Choose a theme", "It changes as you tap, so you can see it.")
                    ThemePicker()
                }
                2 -> {
                    StepTitle("Candle colours", "Pick a preset or your own colours. Hollow candles are one switch away.")
                    CandlePicker()
                }
                3 -> {
                    StepTitle("Chart defaults", "How a chart looks when you open it. You can change these from the chart at any time.")
                    PCard { ChartDefaultsPicker() }
                }
                4 -> {
                    StepTitle("Markets to watch", "The background watcher follows these and alerts you. You can skip this and add markets later.")
                    PCard { MarketChooser() }
                }
                5 -> {
                    StepTitle("Favourite drawing tools", "These sit in a bar on top of the chart, so they are one tap away.")
                    PCard { FavToolsPicker() }
                }
                else -> {
                    StepTitle("How should alerts behave?", "You can fine-tune each alert type later in More.")
                    ALERT_PROFILES.forEach { (name, text, idx) ->
                        val sel = profile == idx
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .background(Brand.Panel)
                                .border(if (sel) 3.dp else 1.dp, if (sel) Brand.Primary else Brand.Border, RoundedCornerShape(12.dp))
                                .clickable { profile = idx; applyAlertProfile(idx) }
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Text(name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Brand.Text)
                            Muted(text, 13)
                        }
                    }
                    PCard {
                        SwitchRow("Quiet hours (22:00 to 07:00): urgent alerts only", Store.quietOn) { Store.quietOn = it; Store.save() }
                    }
                    H("Permissions")
                    Muted("Android must allow a few things, or the phone may stop the watcher or hide alerts. Notifications matter most. You can also do this later in More.", 13)
                    PermissionsPanel()
                    if (Store.watch.isNotEmpty()) {
                        PCard { SwitchRow("Start watching when setup ends", startNow) { startNow = it } }
                    }
                }
            }
            Box(Modifier.height(12.dp))
        }

        // buttons
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (step == 0) {
                TextButton(onClick = { finish() }) { Text("Skip setup", color = Brand.Muted) }
            } else {
                SecondaryButton("Back") { step -= 1 }
            }
            Box(Modifier.weight(1f))
            if (step < LAST_STEP) {
                PrimaryButton(if (step == 0) "Start" else "Next") { step += 1 }
            } else {
                PrimaryButton("Finish") { finish() }
            }
        }
    }
}

@Composable
private fun StepTitle(title: String, sub: String) {
    Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Text)
        Muted(sub, 14)
    }
}
