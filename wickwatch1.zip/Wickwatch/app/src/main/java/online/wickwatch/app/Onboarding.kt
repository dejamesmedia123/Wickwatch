package online.wickwatch.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val LAST_STEP = 2

/**
 * The first-run setup: welcome, theme and candle colours. Everything else is in More.
 * Every choice is saved the moment it is made, and the screen re-themes live, so the person sees the result at once.
 */
@Composable
fun Onboarding(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableIntStateOf(0) }
    BackHandler(enabled = step > 0) { step -= 1 }

    fun finish() {
        Store.onboarded = true
        Store.save()
        onDone()
    }

    Column(Modifier.fillMaxSize().background(Brand.Bg).statusBarsPadding().navigationBarsPadding()) {
        // progress
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 0..LAST_STEP) {
                Box(
                    Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp))
                        .background(if (i <= step) Brand.Primary else Brand.Border),
                )
            }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            when (step) {
                0 -> {
                    Text("Wickwatch", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Text, modifier = Modifier.padding(top = 24.dp))
                    Text("Charts and price alerts for Deriv and Binance markets, with a watcher that keeps working while the app is closed.", color = Brand.Text, fontSize = 16.sp)
                    Muted("Two quick choices follow: your theme and your candle colours. Everything else can be changed later in More.", 14)
                }
                1 -> {
                    StepTitle("Choose a theme", "It changes as you tap, so you can see it.")
                    ThemePicker()
                }
                else -> {
                    StepTitle("Candle colours", "Pick a preset or your own colours. Hollow candles are one switch away.")
                    CandlePicker()
                }
            }
            Box(Modifier.height(12.dp))
        }

        // buttons
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (step == 0) {
                TextButton(onClick = { finish() }) { Text("Skip setup", color = Brand.Muted) }
            } else {
                SecondaryButton("Back") { step -= 1 }
            }
            Box(Modifier.weight(1f))
            if (step < LAST_STEP) {
                PrimaryButton(if (step == 0) "Start" else "Next") { step += 1 }
            } else {
                PrimaryButton("Finish") { finish() }
            }
        }
    }
}

@Composable
private fun StepTitle(title: String, sub: String) {
    Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Text)
        Muted(sub, 14)
    }
}
