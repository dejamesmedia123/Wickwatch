package online.wickwatch.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class AlertRecord(val time: Long, val title: String, val text: String, val kind: String, val mode: Int, val silent: Boolean)

/** Everything the app remembers: watch list, alert settings, chart settings, drawings, price alerts, alert history. */
object Store {
    private var sp: SharedPreferences? = null

    var watch by mutableStateOf<List<WatchItem>>(emptyList())
    var modes by mutableStateOf<Map<String, Int>>(emptyMap())
    var history by mutableStateOf<List<AlertRecord>>(emptyList())
    var priceAlerts by mutableStateOf<List<PriceAlert>>(emptyList())
    var indicators by mutableStateOf<List<IndCfg>>(emptyList())

    var nearTargetR by mutableStateOf(0.65)      // "near a target": within this many risk units (R) of it
    var nearLineAtr by mutableStateOf(0.5)       // "near the trend line": within this many ATR of it
    var nearEdgeAtr by mutableStateOf(0.5)       // "near the channel edge"
    var nearLevelAtr by mutableStateOf(0.5)      // "near a key level"
    var cooldownMin by mutableStateOf(30)        // the same kind of "near" alert for a market at most once per this many minutes
    var quietOn by mutableStateOf(false)
    var quietFrom by mutableStateOf(22)
    var quietTo by mutableStateOf(7)
    var isoPeriod by mutableStateOf(19)
    var watching by mutableStateOf(false)        // the watcher was on, so it restarts after a reboot
    var chartKey by mutableStateOf("BINANCE:BTCUSDT")
    var chartTf by mutableStateOf(900)
    var chartType by mutableStateOf(0)           // 0 candles, 1 hollow, 2 bars, 3 line, 4 area, 5 Heikin Ashi
    var scaleType by mutableStateOf(0)           // 0 linear, 1 log, 2 percent
    var magnet by mutableStateOf(true)           // drawing points snap to the open, high, low and close
    var onboarded by mutableStateOf(false)
    var favTools by mutableStateOf<List<String>>(listOf("trend", "hline", "vline", "fib", "long", "short", "text"))

    private val seen = LinkedHashSet<String>()

    fun init(ctx: Context) {
        if (sp != null) return
        val s = ctx.applicationContext.getSharedPreferences("ww_prefs", Context.MODE_PRIVATE)
        sp = s
        fun d(k: String, def: Double): Double = s.getString(k, null)?.toDoubleOrNull() ?: def
        Brand.mode = s.getInt("tmode", 0)
        Brand.candleUp = s.getLong("cup", 0L)
        Brand.candleDown = s.getLong("cdn", 0L)
        Brand.hollowUp = s.getBoolean("chol", false)
        onboarded = s.getBoolean("onb", false)
        s.getString("favt", null)?.let { f -> favTools = f.split(',').filter { it.isNotBlank() } }
        nearTargetR = d("ntr", 0.65)
        nearLineAtr = d("nla", 0.5)
        nearEdgeAtr = d("nea", 0.5)
        nearLevelAtr = d("nlv", 0.5)
        cooldownMin = s.getInt("cool", 30)
        quietOn = s.getBoolean("qon", false)
        quietFrom = s.getInt("qf", 22)
        quietTo = s.getInt("qt", 7)
        isoPeriod = s.getInt("isop", 19)
        watching = s.getBoolean("watching", false)
        chartKey = s.getString("ckey", "BINANCE:BTCUSDT") ?: "BINANCE:BTCUSDT"
        chartTf = s.getInt("ctf", 900)
        chartType = s.getInt("ctype", 0)
        scaleType = s.getInt("stype", 0)
        magnet = s.getBoolean("magnet", true)
        try {
            val a = JSONArray(s.getString("watch", "[]"))
            watch = (0 until a.length()).map { a.getJSONObject(it) }.map { WatchItem(it.getString("k"), it.getInt("tf")) }
        } catch (e: Exception) {
            watch = emptyList()
        }
        try {
            val o = JSONObject(s.getString("modes", "{}"))
            val m = HashMap<String, Int>()
            for (k in o.keys()) m[k] = o.getInt(k)
            modes = m
        } catch (e: Exception) {
            modes = emptyMap()
        }
        try {
            val a = JSONArray(s.getString("history", "[]"))
            history = (0 until a.length()).map { a.getJSONObject(it) }.map {
                AlertRecord(it.getLong("t"), it.optString("title"), it.optString("text"), it.optString("kind"), it.optInt("mode"), it.optBoolean("silent"))
            }
        } catch (e: Exception) {
            history = emptyList()
        }
        try {
            val a = JSONArray(s.getString("palerts", "[]"))
            priceAlerts = (0 until a.length()).map { a.getJSONObject(it) }.map {
                PriceAlert(it.getString("id"), it.getString("k"), it.getDouble("lv"), it.optString("dr"), it.optBoolean("up"), it.optInt("mode", 1), it.optBoolean("once", true), it.optString("note"), it.optBoolean("on", true))
            }
        } catch (e: Exception) {
            priceAlerts = emptyList()
        }
        try {
            val a = JSONArray(s.getString("inds", "null") ?: "null")
            indicators = (0 until a.length()).map { a.getJSONObject(it) }.map {
                IndCfg(it.getString("id"), it.getString("type"), it.optInt("p1"), it.optInt("p2"), it.optInt("p3"), it.optLong("color"))
            }
        } catch (e: Exception) {
            indicators = emptyList()
        }
        try {
            val a = JSONArray(s.getString("seen", "[]"))
            synchronized(seen) { for (i in 0 until a.length()) seen.add(a.getString(i)) }
        } catch (e: Exception) {
            // start empty
        }
    }

    fun save() {
        val s = sp ?: return
        val w = JSONArray()
        for (x in watch) w.put(JSONObject().put("k", x.key).put("tf", x.tf))
        val m = JSONObject()
        for ((k, v) in modes) m.put(k, v)
        val pa = JSONArray()
        for (x in priceAlerts) {
            pa.put(JSONObject().put("id", x.id).put("k", x.key).put("lv", x.level).put("dr", x.drawingId).put("up", x.above).put("mode", x.mode).put("once", x.once).put("note", x.note).put("on", x.active))
        }
        val ia = JSONArray()
        for (x in indicators) ia.put(JSONObject().put("id", x.id).put("type", x.type).put("p1", x.p1).put("p2", x.p2).put("p3", x.p3).put("color", x.color))
        s.edit()
            .putInt("tmode", Brand.mode)
            .putLong("cup", Brand.candleUp)
            .putLong("cdn", Brand.candleDown)
            .putBoolean("chol", Brand.hollowUp)
            .putBoolean("onb", onboarded)
            .putString("favt", favTools.joinToString(","))
            .putString("ntr", nearTargetR.toString())
            .putString("nla", nearLineAtr.toString())
            .putString("nea", nearEdgeAtr.toString())
            .putString("nlv", nearLevelAtr.toString())
            .putInt("cool", cooldownMin)
            .putBoolean("qon", quietOn)
            .putInt("qf", quietFrom)
            .putInt("qt", quietTo)
            .putInt("isop", isoPeriod)
            .putBoolean("watching", watching)
            .putString("ckey", chartKey)
            .putInt("ctf", chartTf)
            .putInt("ctype", chartType)
            .putInt("stype", scaleType)
            .putBoolean("magnet", magnet)
            .putString("watch", w.toString())
            .putString("modes", m.toString())
            .putString("palerts", pa.toString())
            .putString("inds", ia.toString())
            .apply()
    }

    fun modeOf(k: AlertKind): Int = modes[k.name] ?: k.defaultMode

    fun setMode(k: AlertKind, mode: Int) {
        val m = HashMap(modes)
        m[k.name] = mode
        modes = m
        save()
    }

    /** True the first time an id is seen, false after. Persisted, so a restart does not repeat old alerts. */
    fun markSeen(id: String): Boolean {
        synchronized(seen) {
            if (!seen.add(id)) return false
            while (seen.size > 600) {
                val it = seen.iterator()
                it.next()
                it.remove()
            }
            val a = JSONArray()
            for (x in seen) a.put(x)
            sp?.edit()?.putString("seen", a.toString())?.apply()
        }
        return true
    }

    fun addHistory(r: AlertRecord) {
        synchronized(this) {
            history = (listOf(r) + history).take(100)
            val a = JSONArray()
            for (x in history) a.put(JSONObject().put("t", x.time).put("title", x.title).put("text", x.text).put("kind", x.kind).put("mode", x.mode).put("silent", x.silent))
            sp?.edit()?.putString("history", a.toString())?.apply()
        }
    }

    fun clearHistory() {
        synchronized(this) {
            history = emptyList()
            sp?.edit()?.putString("history", "[]")?.apply()
        }
    }

    // ---- price alerts ---------------------------------------------------------------------------

    fun addPriceAlert(key: String, level: Double, drawingId: String, above: Boolean, mode: Int, once: Boolean, note: String) {
        synchronized(this) {
            priceAlerts = priceAlerts + PriceAlert(UUID.randomUUID().toString(), key, level, drawingId, above, mode, once, note, true)
            save()
        }
    }

    fun removePriceAlert(id: String) {
        synchronized(this) {
            priceAlerts = priceAlerts.filter { it.id != id }
            save()
        }
    }

    fun setAlertActive(id: String, on: Boolean) {
        synchronized(this) {
            priceAlerts = priceAlerts.map { if (it.id == id) it.copy(active = on) else it }
            save()
        }
    }

    // ---- indicators -----------------------------------------------------------------------------

    /** The first time the app runs it starts with a couple of common indicators. */
    fun ensureDefaultIndicators() {
        if (sp?.contains("inds") == true) return
        indicators = listOf(
            IndCfg(UUID.randomUUID().toString(), "EMA", 50, 0, 0, IND_COLORS[0]),
            IndCfg(UUID.randomUUID().toString(), "RSI", 14, 0, 0, IND_COLORS[2]),
        )
        save()
    }

    // ---- drawings (kept per market, in time and price, so they stay put on every timeframe) -----

    fun loadDrawings(key: String): List<Drawing> {
        val s = sp ?: return emptyList()
        return try {
            val a = JSONArray(s.getString("draw:" + key, "[]"))
            (0 until a.length()).map { a.getJSONObject(it) }.map { o ->
                val pa = o.getJSONArray("pts")
                Drawing(
                    o.getString("id"), o.getString("type"),
                    (0 until pa.length()).map { pa.getJSONObject(it) }.map { DPoint(it.getLong("t"), it.getDouble("p")) },
                    o.optLong("c"), o.optString("txt"), o.optBoolean("lock"), o.optInt("w", 2), o.optBoolean("ds"),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveDrawings(key: String, list: List<Drawing>) {
        val s = sp ?: return
        val a = JSONArray()
        for (d in list) {
            val pa = JSONArray()
            for (p in d.pts) pa.put(JSONObject().put("t", p.t).put("p", p.p))
            a.put(JSONObject().put("id", d.id).put("type", d.type).put("c", d.color).put("txt", d.text).put("lock", d.locked).put("w", d.width).put("ds", d.dashed).put("pts", pa))
        }
        s.edit().putString("draw:" + key, a.toString()).apply()
    }
}
