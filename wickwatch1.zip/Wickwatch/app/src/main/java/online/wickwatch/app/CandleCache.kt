package online.wickwatch.app

import java.io.File

/**
 * Candles saved on the phone, one small file per market and timeframe, so a chart opens at once (even offline)
 * and only the missing candles are fetched when the phone is online again.
 */
object CandleCache {
    private fun file(market: Market, tf: Int): File? {
        val ctx = Store.appCtx ?: return null
        val dir = File(ctx.filesDir, "candles")
        dir.mkdirs()
        return File(dir, market.key.replace(Regex("[^A-Za-z0-9_]"), "_") + "_" + tf + ".csv")
    }

    fun load(market: Market, tf: Int): List<Candle> {
        return try {
            val f = file(market, tf) ?: return emptyList()
            if (!f.exists()) return emptyList()
            val out = ArrayList<Candle>()
            f.forEachLine { line ->
                val p = line.split(',')
                if (p.size >= 6) {
                    out.add(Candle(p[0].toLong(), p[1].toDouble(), p[2].toDouble(), p[3].toDouble(), p[4].toDouble(), p[5].toDouble()))
                }
            }
            out.sortBy { it.t }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun save(market: Market, tf: Int, list: List<Candle>) {
        try {
            val f = file(market, tf) ?: return
            val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.bufferedWriter().use { w ->
                for (c in list) {
                    w.write(c.t.toString() + "," + c.o + "," + c.h + "," + c.l + "," + c.c + "," + c.v)
                    w.newLine()
                }
            }
            if (!tmp.renameTo(f)) {
                f.delete()
                tmp.renameTo(f)
            }
        } catch (e: Exception) {
            // saving is a bonus; a failure must never break the chart
        }
    }
}
