package online.wickwatch.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.background
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Each build works for [DAYS] days after it was installed (or updated over an older one).
 * After that the app is view-only: charts, drawings, the watch list and past alerts can still be looked at,
 * but nothing can be changed or created and the background watcher stops. Installing a new version starts a new period.
 */
object Expiry {
    const val DAYS = 14
    /** Where the "Get the new version" button goes. Change this to your real download page. */
    const val UPDATE_URL = "https://wickwatch.cfd"

    var locked by mutableStateOf(false)
        private set

    private var app: Context? = null
    private var lastCheck = 0L

    /** Works out whether this build has run out. Cheap enough to call often (it re-checks at most every 20 seconds). */
    fun check(ctx: Context, force: Boolean = false) {
        val c = ctx.applicationContext
        app = c
        val real = System.currentTimeMillis()
        if (!force && real - lastCheck < 20_000L) return
        lastCheck = real
        try {
            val sp = c.getSharedPreferences("ww_expiry", Context.MODE_PRIVATE)
            // lastUpdateTime moves forward every time a new version is installed over the old one (a fresh install too)
            val installed = c.packageManager.getPackageInfo(c.packageName, 0).lastUpdateTime
            // if the phone clock is moved back, keep using the latest time ever seen
            val now = maxOf(real, sp.getLong("seen", 0L))
            if (now > sp.getLong("seen", 0L)) sp.edit().putLong("seen", now).apply()
            val over = now - installed >= DAYS * 24L * 60L * 60L * 1000L
            if (over != locked) locked = over
        } catch (e: Exception) {
            // if the install time cannot be read, do not lock anyone out
        }
    }

    fun refresh() {
        app?.let { check(it) }
    }

    fun openUpdatePage(ctx: Context) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(UPDATE_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            // no browser available
        }
    }
}

/**
 * Lets scrolling and dragging through but swallows taps, so a screen can be looked at and not changed.
 * The tap is cancelled before the buttons and switches under it ever see it finish.
 */
fun Modifier.blockTaps(): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        val start = down.position
        val slop = viewConfiguration.touchSlop
        var moved = false
        while (true) {
            val ev = awaitPointerEvent(PointerEventPass.Initial)
            val ch = ev.changes.firstOrNull { it.id == down.id } ?: return@awaitEachGesture
            if ((ch.position - start).getDistance() > slop) moved = true
            if (ch.changedToUp()) {
                if (!moved) ch.consume()
                return@awaitEachGesture
            }
            if (!ch.pressed) return@awaitEachGesture
        }
    }
}

/** The bar shown over the app once this version has run out. */
@Composable
fun ExpiredBanner() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxWidth().background(Brand.Danger).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text("This version has expired", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(
            "Download the new version of Wickwatch to keep using it. You can still view your charts, drawings, watch list and alerts, but nothing can be changed and alerts have stopped.",
            color = androidx.compose.ui.graphics.Color.White, fontSize = 12.sp,
        )
        PrimaryButton("Get the new version", Modifier.fillMaxWidth()) { Expiry.openUpdatePage(ctx) }
    }
}
