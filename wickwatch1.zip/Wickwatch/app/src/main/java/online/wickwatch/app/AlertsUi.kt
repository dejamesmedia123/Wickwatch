package online.wickwatch.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.Arrangement.spacedBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val EXPIRY_NAMES = listOf("Never", "1 day", "1 week", "1 month")

/** 0 never, 1 one day, 2 one week, 3 one month, as a time in milliseconds (0 = never). */
fun expiryTime(choice: Int): Long {
    val day = 86_400_000L
    val now = System.currentTimeMillis()
    return when (choice) { 1 -> now + day; 2 -> now + 7 * day; 3 -> now + 30 * day; else -> 0L }
}

fun expiryText(t: Long): String =
    if (t <= 0L) "No expiry" else "Expires " + SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(t))

@Composable
fun ExpiryChips(choice: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        EXPIRY_NAMES.forEachIndexed { i, n -> FilterChip(selected = choice == i, onClick = { onPick(i) }, label = { Text(n) }) }
    }
}

/** Alert on an indicator: RSI crossing a level, or the price crossing a moving average, checked on every closed candle. */
@Composable
fun NewIndAlertDialog(market: Market, tf: Int, onDismiss: () -> Unit, onCreated: () -> Unit) {
    var type by remember { mutableStateOf("RSI") }
    var period by remember { mutableIntStateOf(14) }
    var level by remember { mutableDoubleStateOf(70.0) }
    var above by remember { mutableStateOf(true) }
    var mode by remember { mutableIntStateOf(Store.modeOf(AlertKind.INDICATOR_ALERT).coerceAtLeast(1)) }
    var once by remember { mutableStateOf(true) }
    var expiry by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Elevated,
        title = { Text("Indicator alert", color = Brand.Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Muted(market.name + "  \u00B7  " + tfLabel(tf) + ". Checked when a candle closes.", 12)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (t in listOf("RSI", "EMA", "SMA")) FilterChip(selected = type == t, onClick = {
                        type = t
                        period = if (t == "RSI") 14 else 50
                    }, label = { Text(t) })
                }
                IntField("Period", period, Modifier.fillMaxWidth()) { period = it.coerceIn(2, 500) }
                if (type == "RSI") DecField("RSI level", level, Modifier.fillMaxWidth()) { level = it.coerceIn(1.0, 99.0) }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = above, onClick = { above = true }, label = { Text(if (type == "RSI") "Crosses up" else "Price crosses above") })
                    FilterChip(selected = !above, onClick = { above = false }, label = { Text(if (type == "RSI") "Crosses down" else "Price crosses below") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text("Normal") })
                    FilterChip(selected = mode == 2, onClick = { mode = 2 }, label = { Text("Urgent") })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (once) "Only once" else "Every time", Modifier.weight(1f), color = Brand.Text)
                    Switch(checked = once, onCheckedChange = { once = it })
                }
                Muted("Expires", 12)
                ExpiryChips(expiry) { expiry = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Store.addIndAlert(IndAlert(UUID.randomUUID().toString(), market.key, tf, type, period, level, above, mode, once, expiryTime(expiry), true))
                // the watcher needs this market and timeframe
                if (Store.allWatch().none { it.key == market.key && it.tf == tf }) {
                    Store.watch = Store.watch + WatchItem(market.key, tf)
                }
                Store.save()
                Watcher.refresh()
                onCreated()
            }) { Text("Create alert", color = Brand.Alert, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Brand.Muted) } },
    )
}

@Composable
fun IndAlertCard(a: IndAlert, onOpenChart: (String) -> Unit) {
    val ctx = LocalContext.current
    val m = marketByKey(a.key)
    PCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text((m?.name ?: a.key) + "  " + tfLabel(a.tf), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Muted(
                    if (a.type == "RSI") "RSI(" + a.period + ") crosses " + (if (a.above) "up through " else "down through ") + fp(a.level, 1)
                    else "Price crosses " + (if (a.above) "above " else "below ") + a.type + "(" + a.period + ")",
                    13,
                )
                Muted((if (a.once) "Once" else "Every time") + "  \u00B7  " + (if (a.mode == 2) "Urgent" else "Normal") + "  \u00B7  " + expiryText(a.expires))
            }
            if (a.active) Pill("ACTIVE", Brand.Good) else Pill("OFF", Brand.Muted)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            SecondaryButton(if (a.active) "Turn off" else "Turn on", Modifier.weight(1f)) {
                Store.setIndActive(a.id, !a.active)
                Watcher.refresh()
            }
            SecondaryButton("Show on chart", Modifier.weight(1f)) { onOpenChart(a.key) }
            TextButton(onClick = {
                Store.removeIndAlert(a.id)
                Watcher.refresh()
                if (!Watcher.hasWork() && WatchService.running) WatchService.stop(ctx)
            }) { Text("Delete", color = Brand.Danger) }
        }
    }
}
