package online.wickwatch.app

import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

class PaneRect(val top: Float, val bottom: Float)

/**
 * Where everything sits on the chart. Candle i is drawn at xAt(i). The price pane is panes[0]; indicator panes follow.
 * Prices are turned into a "scale space" first: the price itself (linear), its logarithm, or the percent change from [base].
 */
class Geo(
    val w: Float,
    val h: Float,
    val axisW: Float,
    val botH: Float,
    val times: LongArray,
    val step: Long,
    val bars: Float,
    val lastIdx: Int,
    val firstIdx: Int,
    val scaleType: Int,
    val base: Double,
    val lo: Double,
    val hi: Double,
    val autoLo: Double,
    val autoHi: Double,
    val panes: List<PaneRect>,
) {
    val n: Int get() = times.size
    val rightPad: Int get() = 4
    val pw: Float get() = w - axisW
    val barW: Float get() = pw / bars
    val top: Float get() = panes[0].top
    val bottom: Float get() = panes[0].bottom

    fun xAt(i: Double): Float = (pw - ((lastIdx - i) + rightPad + 0.5) * barW).toDouble().toFloat()
    fun idxAtX(x: Float): Double = lastIdx + rightPad + 0.5 - (pw - x).toDouble() / barW.toDouble()

    fun tr(v: Double): Double = when (scaleType) {
        1 -> ln(max(v, 1e-12))
        2 -> (v / base - 1.0) * 100.0
        else -> v
    }

    fun inv(t: Double): Double = when (scaleType) {
        1 -> exp(t)
        2 -> base * (1.0 + t / 100.0)
        else -> t
    }

    fun yAt(v: Double): Float = (bottom - (tr(v) - lo) / (hi - lo) * (bottom - top)).toFloat()
    fun priceAtY(y: Float): Double = inv(lo + (bottom - y).toDouble() / (bottom - top).toDouble() * (hi - lo))

    /** The (fractional) candle position of a time. Times after the last candle continue at the same spacing. */
    fun idxOfTime(t: Long): Double {
        if (n == 0) return 0.0
        if (t >= times[n - 1]) return (n - 1) + (t - times[n - 1]).toDouble() / step
        if (t <= times[0]) return (t - times[0]).toDouble() / step
        var a = 0
        var b = n - 1
        while (a < b) {
            val m = (a + b + 1) ushr 1
            if (times[m] <= t) a = m else b = m - 1
        }
        val t0 = times[a]
        val t1 = times[min(a + 1, n - 1)]
        return a + (if (t1 > t0) (t - t0).toDouble() / (t1 - t0) else 0.0)
    }

    fun timeOfIdx(i: Double): Long {
        if (n == 0) return 0L
        if (i >= n - 1) return times[n - 1] + Math.round((i - (n - 1)) * step)
        if (i <= 0) return times[0] + Math.round(i * step)
        val a = floor(i).toInt()
        val f = i - a
        return times[a] + Math.round(f * (times[a + 1] - times[a]))
    }
}

fun buildGeo(
    w: Float, h: Float, axisW: Float, botH: Float, cs: List<Candle>,
    bars: Float, off: Float, scaleType: Int, auto: Boolean, freeLo: Double, freeHi: Double, nSub: Int,
): Geo {
    val n = cs.size
    val times = LongArray(n) { cs[it].t }
    val step = if (n >= 2) max(1L, times[n - 1] - times[n - 2]) else 60L
    val barsF = bars.coerceIn(20f, 400f)
    val offI = Math.round(off).coerceIn(0, max(0, n - 1))
    val lastIdx = (n - 1 - offI).coerceIn(0, max(0, n - 1))
    val firstIdx = max(0, lastIdx - barsF.toInt() + 1)
    val plotH = h - botH
    val gap = 6f
    val subH = plotH * 0.17f
    val mainH = plotH - nSub * (subH + gap)
    val panes = ArrayList<PaneRect>()
    panes.add(PaneRect(0f, mainH))
    for (k in 0 until nSub) {
        val t = mainH + gap + k * (subH + gap)
        panes.add(PaneRect(t, t + subH))
    }
    val base = if (n > 0) cs[firstIdx].c else 1.0
    fun trf(v: Double): Double = when (scaleType) {
        1 -> ln(max(v, 1e-12))
        2 -> (v / base - 1.0) * 100.0
        else -> v
    }
    var lo = Double.MAX_VALUE
    var hi = -Double.MAX_VALUE
    for (i in firstIdx..lastIdx) {
        if (i < 0 || i >= n) continue
        lo = min(lo, trf(cs[i].l))
        hi = max(hi, trf(cs[i].h))
    }
    if (n == 0 || hi <= lo) {
        lo = 0.0
        hi = 1.0
    }
    val pad = (hi - lo) * 0.08
    lo -= pad
    hi += pad
    return Geo(w, h, axisW, botH, times, step, barsF, lastIdx, firstIdx, scaleType, base, if (auto) lo else freeLo, if (auto) hi else freeHi, lo, hi, panes)
}
