package online.wickwatch.app

import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import java.util.UUID
import kotlin.math.exp
import kotlin.math.hypot
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.runtime.mutableLongStateOf
import kotlinx.coroutines.delay
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.geometry.Size

/** Loads one market, keeps it live, and runs the Ribbon and key-level engines on every new closed candle. */
class ChartModel(private val scope: CoroutineScope) {
    var candles by mutableStateOf<List<Candle>>(emptyList())
    var ribbon by mutableStateOf<RibbonResult?>(null)
    var levels by mutableStateOf<LevelsResult?>(null)
    var setups by mutableStateOf<Map<Int, SetupScan>>(emptyMap())
    var alch by mutableStateOf<List<ExtraEngines.AlchLevel>>(emptyList())
    var status by mutableStateOf("loading...")
    @Volatile var live: List<Candle> = emptyList()      // what the feed delivered; the chart shows less of it while a bar replay runs
    var replayT by mutableStateOf(0L)                   // time of the last candle shown in the replay, 0 = no replay
    val replaying: Boolean get() = replayT != 0L
    @Volatile private var seq = 0
    private var feed: SeriesFeed? = null
    private var lastClosed = 0L
    private var lastFirst = 0L
    private val main = Handler(Looper.getMainLooper())

    fun open(m: Market, tf: Int) {
        feed?.stop()
        candles = emptyList()
        ribbon = null
        levels = null
        setups = emptyMap()
        alch = emptyList()
        replayT = 0L
        live = emptyList()
        lastClosed = 0L
        lastFirst = 0L
        status = "loading..."
        val f = SeriesFeed(m, tf, scope, { list, _, _ -> onData(list) }, { s -> main.post { status = s } }, cache = true, maxCandles = 8000)
        feed = f
        f.start()
    }

    fun loadOlder() {
        feed?.loadOlder()
    }

    /** For the setup dashboard: older candles are loaded, then the finder runs again on them (see onData). */
    val backfillMsg: String
        get() = if (feed?.exhausted == true) "no more older candles for this market" else if (feed?.loadingMore == true) "loading older candles..." else ""

    /** Every setup that is on (and the one open in the dashboard), each scanned by its own strategy. */
    private fun scanSetups(closed: List<Candle>): Map<Int, SetupScan> {
        val out = HashMap<Int, SetupScan>()
        val mask = Store.setupScanMask()
        for (i in 0..8) {
            if (mask and (1 shl i) == 0) continue
            try {
                out[i] = SetupEngine.scan(closed, Store.setupParams(i))
            } catch (e: Exception) {
                // that strategy shows nothing this time
            }
        }
        return out
    }

    /** Run the setup finder again (after its settings changed). */
    fun refreshSetups() {
        val closed = candles.dropLast(1)
        if (closed.size < 100) return
        Thread {
            val sc = try { scanSetups(closed) } catch (e: Exception) { null }
            if (sc != null) main.post { setups = sc }
        }.start()
    }

    private fun onData(list: List<Candle>) {
        live = list
        if (replaying) return                      // the replay decides what is shown
        present(list)
    }

    /** Alchemist levels from the last 2500 closed candles (the work grows with the history, so it is capped). */
    private fun alchFor(closed: List<Candle>): List<ExtraEngines.AlchLevel> {
        if (!Store.showAlch || closed.size < 30) return emptyList()
        return try {
            val w = closed.takeLast(2500)
            val off = closed.size - w.size
            ExtraEngines.alchemistLevels(w).map { ExtraEngines.AlchLevel(it.price, it.label, it.fresh, it.uses, it.bornIdx + off) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Called when the indicator is switched on or off. */
    fun refreshAlch() {
        val closed = candles.dropLast(1)
        Thread {
            val a = alchFor(closed)
            main.post { alch = a }
        }.start()
    }

    private fun indexOfT(t: Long): Int {
        val l = live
        var lo = 0
        var hi = l.size - 1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (l[mid].t < t) lo = mid + 1 else if (l[mid].t > t) hi = mid - 1 else return mid
        }
        return -1
    }

    /** Bar replay: the chart is cut after candle [idx] and everything (ribbon, levels, setups) is worked out from that part only. */
    fun startReplay(idx: Int) {
        val l = live
        if (l.size < 120) return
        val i = idx.coerceIn(100, l.size - 2)
        replayT = l[i].t
        showReplay(i)
    }

    /** Moves the replay by [d] candles. False when it cannot go further. */
    fun replayStep(d: Int): Boolean {
        val i = indexOfT(replayT) + d
        if (indexOfT(replayT) < 0 || i < 100 || i > live.size - 1) return false
        replayT = live[i].t
        showReplay(i)
        return i < live.size - 1
    }

    fun stopReplay() {
        replayT = 0L
        lastClosed = 0L
        lastFirst = 0L
        present(live)
    }

    private fun showReplay(i: Int) {
        present(live.take(i + 1))
    }

    private fun present(list: List<Candle>) {
        val my = ++seq
        val closed = list.dropLast(1)
        var rb: RibbonResult? = null
        var lv: LevelsResult? = null
        var fresh = false
        var sc: Map<Int, SetupScan>? = null
        var al: List<ExtraEngines.AlchLevel>? = null
        // analyse again on a new closed candle, or when older candles were added in front (the results are indexed by candle)
        if (closed.size >= 100 && (closed[closed.size - 1].t != lastClosed || closed[0].t != lastFirst)) {
            lastClosed = closed[closed.size - 1].t
            lastFirst = closed[0].t
            try {
                rb = Ribbon.analyze(closed)
                lv = Levels.analyze(closed)
                fresh = true
            } catch (e: Exception) {
                // still show the candles
            }
            // the setup finder runs again whenever older candles were added in front, so scrolling back fills the history
            try {
                sc = scanSetups(closed)
            } catch (e: Exception) {
                sc = null
            }
            al = alchFor(closed)
        }
        main.post {
            if (my != seq) return@post
            candles = list
            if (al != null) alch = al
            if (fresh) {
                ribbon = rb
                levels = lv
            }
            if (sc != null) setups = sc
        }
    }

    fun close() {
        feed?.stop()
        feed = null
    }
}

/** Everything the chart screen keeps track of: view, drawings, selection, gestures. */
class ChartUi {
    var bars by mutableFloatStateOf(90f)
    var off by mutableFloatStateOf(0f)
    var auto by mutableStateOf(true)
    var freeLo by mutableDoubleStateOf(0.0)
    var freeHi by mutableDoubleStateOf(1.0)
    var size by mutableStateOf(IntSize.Zero)
    var geo: Geo? = null
    var candles: List<Candle> = emptyList()
    var rev by mutableIntStateOf(0)
    var tool by mutableStateOf("")
    val pending = mutableStateListOf<DPoint>()
    val drawings = mutableStateListOf<Drawing>()
    var selectedId by mutableStateOf<String?>(null)
    var cross by mutableStateOf<Offset?>(null)
    var textFor by mutableStateOf<Drawing?>(null)
    var editText by mutableStateOf<Drawing?>(null)
    var marketKey = ""

    private var dragMode = 0
    private var dragHandle = -1
    private var dragStart = Offset.Zero
    private var dragOrig: List<DPoint> = emptyList()

    fun load(key: String) {
        marketKey = key
        drawings.clear()
        drawings.addAll(Store.loadDrawings(key))
        selectedId = null
        pending.clear()
        tool = ""
        cross = null
        rev += 1
    }

    fun persist() {
        if (marketKey.isNotEmpty()) Store.saveDrawings(marketKey, drawings.toList())
    }

    fun selected(): Drawing? = drawings.firstOrNull { it.id == selectedId }

    fun pickTool(id: String) {
        tool = id
        pending.clear()
        selectedId = null
        cross = null
    }

    fun cancelTool() {
        tool = ""
        pending.clear()
    }

    /** Removes the drawing that was added last. */
    fun undoLast() {
        val d = drawings.lastOrNull() ?: return
        drawings.remove(d)
        selectedId = null
        persist()
        rev += 1
    }

    private fun add(d: Drawing) {
        drawings.add(d)
        selectedId = d.id
        tool = ""
        pending.clear()
        persist()
        rev += 1
    }

    fun drawTap(o: Offset) {
        val g = geo ?: return
        val spec = Tools.spec(tool) ?: return
        if (o.y > g.bottom || o.x > g.pw) return
        pending.add(Draw.fromScreen(g, candles, o, Store.magnet, spec.kind == "vline"))
        if (spec.n > 0 && pending.size >= spec.n) finish()
    }

    /** Completes a drawing (used by the Done button for Path and Polyline). */
    fun finish() {
        val spec = Tools.spec(tool) ?: return
        if (pending.size < (if (spec.n == -1) 2 else max1(spec.n))) return
        val d = Draw.make(spec, pending.toList(), "")
        if (Tools.needsText(spec.kind)) {
            textFor = d
            pending.clear()
        } else {
            add(d)
        }
    }

    private fun max1(n: Int): Int = if (n < 1) 2 else n

    fun commitText(d: Drawing, text: String) {
        d.text = text
        textFor = null
        add(d)
    }

    fun freeStart(o: Offset) {
        val g = geo ?: return
        pending.clear()
        pending.add(Draw.fromScreen(g, candles, o, false))
    }

    fun freeMove(o: Offset) {
        val g = geo ?: return
        pending.add(Draw.fromScreen(g, candles, o, false))
    }

    fun freeEnd() {
        val spec = Tools.spec(tool) ?: return
        if (pending.size >= 2) add(Draw.make(spec, pending.toList(), "")) else pending.clear()
    }

    fun tapNormal(o: Offset) {
        val g = geo ?: return
        var best: Drawing? = null
        var bd = 36f
        for (d in drawings) {
            val dist = Draw.hitDist(d, g, o.x, o.y)
            if (dist < bd) {
                bd = dist
                best = d
            }
        }
        if (best != null) {
            selectedId = best.id
        } else {
            selectedId = null
            cross = null
        }
        rev += 1
    }

    fun panZoom(pan: Offset, zoom: Float) {
        val g = geo ?: return
        bars = (bars / zoom).coerceIn(20f, 400f)
        off = (off + pan.x / (g.pw / bars)).coerceIn(-MAX_FUTURE.toFloat(), 8000f)
        if (!auto) {
            val dTr = pan.y / (g.bottom - g.top) * (g.hi - g.lo)
            freeLo += dTr
            freeHi += dTr
        }
    }

    fun axisDrag(dy: Float) {
        val g = geo ?: return
        if (auto) {
            auto = false
            freeLo = g.autoLo
            freeHi = g.autoHi
        }
        val f = exp((dy / 250f).toDouble())
        val c = (freeLo + freeHi) / 2.0
        val half = (freeHi - freeLo) / 2.0 * f
        freeLo = c - half
        freeHi = c + half
    }

    fun editStart(o: Offset) {
        val g = geo ?: return
        val d = selected()
        dragStart = o
        if (d == null) {
            dragMode = 3
            return
        }
        if (!d.locked) {
            val hs = Draw.handles(d, g)
            var bi = -1
            var bd = 56f
            for ((i, h) in hs.withIndex()) {
                val dist = hypot(o.x - h.x, o.y - h.y)
                if (dist < bd) {
                    bd = dist
                    bi = i
                }
            }
            if (bi >= 0) {
                dragMode = 1
                dragHandle = bi
                return
            }
            if (Draw.hitDist(d, g, o.x, o.y) < 40f) {
                dragMode = 2
                dragOrig = d.pts
                return
            }
        }
        dragMode = 3
    }

    fun editMove(pos: Offset, amt: Offset) {
        val g = geo ?: return
        val d = selected()
        if (dragMode == 1 && d != null) {
            Draw.movePoint(d, g, candles, dragHandle, pos, Store.magnet)
            rev += 1
        } else if (dragMode == 2 && d != null) {
            val dIdx = (pos.x - dragStart.x).toDouble() / g.barW.toDouble()
            val dTr = -(pos.y - dragStart.y).toDouble() / (g.bottom - g.top).toDouble() * (g.hi - g.lo)
            d.pts = Draw.translate(g, dragOrig, dIdx, dTr)
            rev += 1
        } else {
            panZoom(amt, 1f)
        }
    }

    fun editEnd() {
        if (dragMode == 1 || dragMode == 2) persist()
        dragMode = 0
    }

    fun deleteSelected() {
        val d = selected() ?: return
        drawings.remove(d)
        selectedId = null
        persist()
        rev += 1
    }

    fun duplicateSelected() {
        val d = selected() ?: return
        val g = geo
        val shift = if (g != null) g.step * 3 else 180L
        val c = Drawing(UUID.randomUUID().toString(), d.type, d.pts.map { DPoint(it.t + shift, it.p) }, d.color, d.text, false, d.width, d.dashed)
        drawings.add(c)
        selectedId = c.id
        persist()
        rev += 1
    }

    fun touch() {
        persist()
        rev += 1
    }
}

class AlertDraft(val level: Double, val drawingId: String, val title: String)

private val TYPE_NAMES = listOf("Candles", "Hollow candles", "Bars", "Line", "Area", "Heikin Ashi")
private val TYPE_ICONS = listOf("candles", "candles", "bars", "line", "area", "candles")

/** The value (price) of a straight-line drawing at a given time. */
fun lineValueAt(d: Drawing, t: Long): Double? {
    if (d.pts.size < 2) return null
    val a = d.pts[0]
    val b = d.pts[1]
    if (b.t == a.t) return a.p
    return a.p + (b.p - a.p) * (t - a.t).toDouble() / (b.t - a.t).toDouble()
}

private fun alertTargets(d: Drawing, now: Long): List<AlertDraft> {
    val k = Tools.spec(d.type)?.kind ?: return emptyList()
    return when (k) {
        "hline", "hray" -> listOf(AlertDraft(d.pts[0].p, "", "This price line"))
        "seg", "ray", "ext", "info" -> {
            val v = lineValueAt(d, now)
            if (v == null) emptyList() else listOf(AlertDraft(v, d.id, "This line (the alert follows the line)"))
        }
        "rect", "pdrange" -> listOf(AlertDraft(maxOf(d.pts[0].p, d.pts[1].p), "", "Top edge"), AlertDraft(minOf(d.pts[0].p, d.pts[1].p), "", "Bottom edge"))
        "long", "short" -> if (d.pts.size >= 3) listOf(AlertDraft(d.pts[0].p, "", "Entry"), AlertDraft(d.pts[1].p, "", "Stop"), AlertDraft(d.pts[2].p, "", "Target")) else emptyList()
        else -> emptyList()
    }
}

@Composable
private fun SmallBtn(text: String, selected: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(8.dp)).background(if (selected) Brand.Primary else Brand.Elevated)
            .clickable { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp),
    ) {
        Text(text, color = if (selected) Brand.Bg else Brand.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ChartScreen() {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val model = remember { ChartModel(scope) }
    val ui = remember { ChartUi() }
    var showPicker by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var showInds by remember { mutableStateOf(false) }
    var showTypeMenu by remember { mutableStateOf(false) }
    var showHub by remember { mutableStateOf(false) }
    var showTf by remember { mutableStateOf(false) }
    var showDetails by remember { mutableStateOf(false) }
    var showSetupBoard by remember { mutableStateOf(false) }
    LaunchedEffect(Store.showAlch) { model.refreshAlch() }
    LaunchedEffect(Store.setupEmaLen, Store.setupTrendSrc, Store.setupReverse, Store.setupOn, Store.setupStrategy, Store.setupBias, Store.setupMode, Store.setupScore, Store.setupRR, Store.setupImpulse, Store.setupDirs) { model.refreshSetups() }
    var showIndAlert by remember { mutableStateOf(false) }
    var showCalc by remember { mutableStateOf(false) }
    var showJournal by remember { mutableStateOf(false) }
    var showShot by remember { mutableStateOf(false) }
    var showBar by remember { mutableStateOf(true) }          // the floating tools bar, switched by the pen button
    var clock by remember { mutableLongStateOf(0L) }          // ticks every second so the candle countdown moves
    var barOff by remember { mutableStateOf(Offset.Zero) }    // where the person dragged the tools bar to
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            clock = System.currentTimeMillis()
        }
    }
    var showRibbon by rememberSaveable { mutableStateOf(false) }
    var showLevels by rememberSaveable { mutableStateOf(true) }
    var alertDraft by remember { mutableStateOf<AlertDraft?>(null) }
    var alertChoices by remember { mutableStateOf<List<AlertDraft>>(emptyList()) }

    val locked = Expiry.locked   // view-only once this version has run out
    val isOffline = model.status.startsWith("offline")
    val market = marketByKey(Store.chartKey) ?: MARKETS[0]
    LaunchedEffect(Store.chartKey, Store.chartTf) {
        ui.load(Store.chartKey)
        marketByKey(Store.chartKey)?.let { model.open(it, Store.chartTf) }
    }
    LaunchedEffect(Store.scaleType) { ui.auto = true }
    DisposableEffect(Unit) { onDispose { model.close() } }

    val cs = model.candles
    ui.candles = cs
    val shown = if (Store.chartType == 5) heikin(cs) else cs
    val outs = remember(cs, Store.indicators) { Store.indicators.map { it to computeInd(it, cs) } }
    val subCount = outs.count { !IndSpecs.spec(it.first.type).overlay }.coerceAtMost(3)
    val sz = ui.size
    val geo: Geo? = if (cs.size >= 2 && sz.width > 0 && sz.height > 0) {
        with(density) {
            buildGeo(sz.width.toFloat(), sz.height.toFloat(), 64.dp.toPx(), 22.dp.toPx(), shown, ui.bars, ui.off, Store.scaleType, ui.auto, ui.freeLo, ui.freeHi, subCount)
        }
    } else null
    ui.geo = geo
    // scrolled back to the start of the loaded candles: fetch older ones
    LaunchedEffect(cs.size, (ui.off / 8f).toInt(), ui.bars.toInt()) {
        if (cs.isNotEmpty() && (cs.size - 1 - ui.off) - ui.bars < 25f) model.loadOlder()
    }
    val last = cs.lastOrNull()
    val first = if (cs.size >= 2) cs[maxOf(0, cs.size - 1 - 96)] else null
    val change = if (last != null && first != null && first.o != 0.0) (last.c / first.o - 1.0) * 100.0 else 0.0

    fun newAlert(d: AlertDraft) {
        alertDraft = d
    }

    /** Draws the chart into a picture with the Wickwatch marks, then saves it to the gallery (and opens sharing when asked). */
    fun capture(share: Boolean, quiet: Boolean = false): android.net.Uri? {
        val g = geo
        val w = ui.size.width
        val h = ui.size.height
        if (g == null || w <= 0 || h <= 0) {
            toast(ctx, "The chart is not ready yet")
            return null
        }
        val footer = with(density) { 36.dp.roundToPx() }
        val img = ImageBitmap(w, h + footer)
        val cv = androidx.compose.ui.graphics.Canvas(img)
        val mineNow = Store.priceAlerts.filter { it.active && it.key == market.key }
        CanvasDrawScope().draw(density, LayoutDirection.Ltr, cv, Size(w.toFloat(), (h + footer).toFloat())) {
            drawRect(Brand.Bg)
            clipRect(0f, 0f, w.toFloat(), h.toFloat()) {
                drawChart(
                    g, cs, shown, Store.chartType, market.dec, outs,
                    if (showRibbon) model.ribbon else null, model.levels, showRibbon, showLevels,
                    mineNow, ui.drawings.toList(), null, emptyList(), "", null,
                    model.setups, model.alch,
                )
            }
        }
        val bmp = img.asAndroidBitmap()
        val up = change >= 0
        val chgAbs = if (last != null && first != null) last.c - first.o else 0.0
        val title = market.name + "  \u00B7  " + tfLabel(Store.chartTf) + "  \u00B7  " + (if (market.src == 'b') "Binance" else "Deriv")
        val priceLine = if (last != null) fp(last.c, market.dec) + "  " + (if (up) "+" else "") + fp(chgAbs, market.dec) + " (" + (if (up) "+" else "") + fp(change, 2) + "%)" else ""
        stampScreenshot(bmp, h, title, priceLine, up, density.density)
        val name = "Wickwatch_" + market.name.replace(Regex("[^A-Za-z0-9]"), "") + "_" + System.currentTimeMillis()
        val uri = saveScreenshot(ctx, bmp, name)
        if (uri == null) {
            toast(ctx, "Could not save the picture")
        } else {
            if (!quiet) toast(ctx, "Saved to Pictures/Wickwatch")
            if (share) shareScreenshot(ctx, uri)
        }
        return uri
    }

    Column(Modifier.fillMaxSize().background(Brand.Bg)) {
        // ---- the chart
        Box(Modifier.weight(1f).fillMaxWidth().onSizeChanged { ui.size = it }) {
            if (geo == null) {
                Text("Loading " + market.name + "...", color = Brand.Muted, modifier = Modifier.align(Alignment.Center))
            } else {
                val mine = Store.priceAlerts.filter { it.active && it.key == market.key }
                val gestures: Modifier = when {
                    locked ->
                        Modifier.pointerInput(Unit) { detectTransformGestures { _, pan, zoom, _ -> ui.panZoom(pan, zoom) } }
                            .pointerInput(3) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { ui.cross = it },
                                    onDrag = { c, _ -> c.consume(); ui.cross = c.position },
                                )
                            }
                    ui.tool != "" && (Tools.spec(ui.tool)?.n == 0) ->
                        Modifier.pointerInput(ui.tool) {
                            detectDragGestures(
                                onDragStart = { ui.freeStart(it) },
                                onDrag = { c, _ -> c.consume(); ui.freeMove(c.position) },
                                onDragEnd = { ui.freeEnd() },
                                onDragCancel = { ui.freeEnd() },
                            )
                        }
                    ui.tool != "" -> Modifier.pointerInput(ui.tool) { detectTapGestures(onTap = { ui.drawTap(it) }) }
                    ui.selectedId != null ->
                        Modifier.pointerInput(ui.selectedId) {
                            detectDragGestures(
                                onDragStart = { ui.editStart(it) },
                                onDrag = { c, amt -> c.consume(); ui.editMove(c.position, amt) },
                                onDragEnd = { ui.editEnd() },
                                onDragCancel = { ui.editEnd() },
                            )
                        }.pointerInput(ui.selectedId, 1) { detectTapGestures(onTap = { ui.tapNormal(it) }) }
                    else ->
                        Modifier.pointerInput(Unit) { detectTransformGestures { _, pan, zoom, _ -> ui.panZoom(pan, zoom) } }
                            .pointerInput(2) { detectTapGestures(onTap = { ui.tapNormal(it) }) }
                            .pointerInput(3) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { ui.cross = it },
                                    onDrag = { c, _ -> c.consume(); ui.cross = c.position },
                                )
                            }
                }
                Canvas(Modifier.fillMaxSize().then(gestures)) {
                    ui.rev
                    clock
                    drawChart(
                        geo, cs, shown, Store.chartType, market.dec, outs,
                        if (showRibbon) model.ribbon else null, model.levels, showRibbon, showLevels,
                        mine, ui.drawings.toList(), ui.selectedId, ui.pending.toList(), Tools.spec(ui.tool)?.kind ?: "", ui.cross,
                        model.setups, model.alch,
                    )
                }
                // drag the price axis to stretch the scale; double tap to go back to auto
                Box(
                    Modifier.align(Alignment.TopEnd).width(64.dp).height(with(density) { geo.bottom.toDp() })
                        .pointerInput(Unit) { detectVerticalDragGestures(onVerticalDrag = { c, dy -> c.consume(); ui.axisDrag(dy) }) }
                        .pointerInput(4) { detectTapGestures(onDoubleTap = { ui.auto = true }) },
                )
                // floating tools bar: drag the grip to move it
                if (!locked && showBar) Row(
                    Modifier.align(Alignment.TopCenter).offset { IntOffset(barOff.x.roundToInt(), barOff.y.roundToInt()) }.padding(top = 56.dp)
                        .clip(RoundedCornerShape(14.dp)).background(Brand.Elevated.copy(alpha = 0.97f)).border(1.dp, Brand.Border, RoundedCornerShape(14.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.width(26.dp).height(40.dp).pointerInput(Unit) { detectDragGestures { c, d -> c.consume(); barOff += d } },
                        contentAlignment = Alignment.Center,
                    ) { WIcon("grip", size = 20.dp, tint = Brand.Muted) }
                    Row(Modifier.widthIn(max = 260.dp).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                        IconBtn("cursor", ui.tool == "") { ui.cancelTool() }
                        for (id in Store.favTools) {
                            val spec = Tools.spec(id) ?: continue
                            IconBtn(toolIcon(spec.kind), ui.tool == id) { ui.pickTool(id) }
                        }
                        IconBtn("plus") { showTools = true }
                    }
                }
                // scale controls
                Row(Modifier.align(Alignment.BottomStart).padding(start = 8.dp, bottom = 30.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    SmallBtn(if (ui.auto) "Auto" else "Free", !ui.auto) { if (ui.auto) { ui.auto = false; ui.freeLo = geo.autoLo; ui.freeHi = geo.autoHi } else ui.auto = true }
                    SmallBtn("Log", Store.scaleType == 1) { Store.scaleType = if (Store.scaleType == 1) 0 else 1; Store.save() }
                    SmallBtn("%", Store.scaleType == 2) { Store.scaleType = if (Store.scaleType == 2) 0 else 2; Store.save() }
                    IconBtn("right", size = 32.dp) { ui.off = 0f }
                }
                // what to do next
                val spec = if (locked) null else Tools.spec(ui.tool)
                if (spec != null) {
                    Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 58.dp).clip(RoundedCornerShape(12.dp)).background(Brand.Elevated).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            if (spec.n == 0) spec.name + ": drag on the chart" else if (spec.n == -1) spec.name + ": tap points (" + ui.pending.size + ")" else spec.name + ": tap point " + (ui.pending.size + 1) + " of " + spec.n,
                            color = Brand.Text, fontSize = 12.sp,
                        )
                        if (spec.n == -1) SmallBtn("Done") { ui.finish() }
                        SmallBtn("Cancel") { ui.cancelTool() }
                    }
                }
                // selected drawing toolbar
                val sd = if (locked) null else ui.selected()
                if (sd != null && spec == null) {
                    Column(
                        Modifier.align(Alignment.BottomCenter).padding(bottom = 30.dp, start = 8.dp, end = 8.dp).clip(RoundedCornerShape(12.dp)).background(Brand.Elevated).padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            for (c in SWATCHES.take(10)) {
                                Box(Modifier.size(24.dp).clip(CircleShape).background(Color(c)).border(if (sd.color == c) 3.dp else 1.dp, if (sd.color == c) Brand.Alert else Brand.Border, CircleShape).clickable { sd.color = c; ui.touch() })
                            }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            for (w in listOf(1, 2, 3, 5)) SmallBtn(w.toString(), sd.width == w) { sd.width = w; ui.touch() }
                            IconBtn("dash", sd.dashed, size = 36.dp) { sd.dashed = !sd.dashed; ui.touch() }
                            IconBtn(if (sd.locked) "lock" else "unlock", sd.locked, size = 36.dp) { sd.locked = !sd.locked; ui.touch() }
                            IconBtn("copy", size = 36.dp) { ui.duplicateSelected() }
                            if (Tools.needsText(Tools.spec(sd.type)?.kind ?: "")) IconBtn("pencil", size = 36.dp) { ui.editText = sd }
                            val targets = alertTargets(sd, System.currentTimeMillis() / 1000L)
                            if (targets.isNotEmpty()) IconBtn("alarm", size = 36.dp) { if (targets.size == 1) newAlert(targets[0]) else alertChoices = targets }
                            IconBtn("trash", size = 36.dp) { ui.deleteSelected() }
                        }
                    }
                }
                // long press: crosshair actions
                val cr = ui.cross
                if (cr != null && sd == null && spec == null) {
                    val p = geo.priceAtY(cr.y)
                    Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 30.dp).clip(RoundedCornerShape(12.dp)).background(Brand.Elevated).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Mono(fp(p, market.dec), 13)
                        if (!locked) SmallBtn("Alert here", true) { newAlert(AlertDraft(p, "", "Price " + fp(p, market.dec))); ui.cross = null }
                        SmallBtn("Clear") { ui.cross = null }
                    }
                }
            }
            // title and legend over the chart, like TradingView's mobile chart
            val up = change >= 0
            val chg = if (last != null && first != null) last.c - first.o else 0.0
            Column(Modifier.align(Alignment.TopStart).padding(start = 10.dp, top = 6.dp)) {
                Row(Modifier.clickable { showPicker = true }, verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(20.dp).clip(CircleShape).background(Brand.Elevated).border(1.dp, Brand.Border, CircleShape), contentAlignment = Alignment.Center) {
                        Text(market.name.take(1).uppercase(), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Text)
                    }
                    Spacer(Modifier.width(6.dp))
                    Text(
                        market.name + "  \u00B7  " + tfLabel(Store.chartTf) + "  \u00B7  " + (if (market.src == 'b') "Binance" else "Deriv"),
                        fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Brand.Text, maxLines = 1,
                    )
                }
                if (last != null) {
                    Text(
                        fp(last.c, market.dec) + "  " + (if (up) "+" else "") + fp(chg, market.dec) + " (" + (if (up) "+" else "") + fp(change, 2) + "%)",
                        fontSize = 12.sp, color = if (up) Brand.Up else Brand.Down, maxLines = 1,
                    )
                }
                Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        Modifier.clip(RoundedCornerShape(6.dp)).border(1.dp, Brand.Border, RoundedCornerShape(6.dp))
                            .clickable(enabled = !locked) { showInds = true }.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        WIcon("down", size = 14.dp, tint = Brand.Text)
                        Spacer(Modifier.width(4.dp))
                        Text(Store.indicators.size.toString(), fontSize = 13.sp, color = Brand.Text)
                    }
                    if (isOffline) {
                        WIcon("cloudoff", size = 16.dp, tint = Brand.Alert)
                        Text("Offline", fontSize = 12.sp, color = Brand.Alert)
                    }
                }
                if (model.replaying) ReplayBar(model)
                // every setup that is on is listed like an indicator: name and results, tap for the dashboard, the cross switches it off
                if (Store.setupOn != 0) {
                    Text(
                        if (Store.setupReverse) "REVERSED: showing the opposite trades (tap to go back)" else "Reverse: show the opposite trades",
                        fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (Store.setupReverse) Brand.Alert else Brand.Muted,
                        modifier = Modifier.padding(top = 4.dp).clip(RoundedCornerShape(6.dp)).border(1.dp, if (Store.setupReverse) Brand.Alert else Brand.Border, RoundedCornerShape(6.dp))
                            .clickable { Store.setupReverse = !Store.setupReverse; Store.save() }.padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                }
                for (si in SETUP_ORDER) {
                    if (!Store.setupIsOn(si)) continue
                    val scNow = model.setups[si]
                    Row(Modifier.padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val stl = scNow?.statsLast(10)
                        Text(
                            SETUP_SHORT[si] + (if (stl != null && stl.total > 0) "  " + stl.wins + "W " + stl.losses + "L " + fp(stl.winRate, 0) + "%" else "") +
                                (if (scNow != null && scNow.waiting().isNotEmpty()) "  " + scNow.waiting().size + " waiting" else ""),
                            fontSize = 12.sp, color = Brand.Text, maxLines = 1,
                            modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable { Store.setupStrategy = si; Store.save(); showSetupBoard = true }.padding(vertical = 2.dp),
                        )
                        IconBtn("close", size = 26.dp) { Store.toggleSetup(si) }
                    }
                }
            }
        }
        // ---- bottom toolbar: symbol, timeframe, draw, indicators, menu, undo
        Box(Modifier.fillMaxWidth().height(1.dp).background(Brand.Border))
        Row(Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                market.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Brand.Text, maxLines = 1,
                modifier = Modifier.widthIn(max = 130.dp).clip(RoundedCornerShape(8.dp)).clickable { showPicker = true }.padding(horizontal = 8.dp, vertical = 8.dp),
            )
            Box {
                Text(
                    tfLabel(Store.chartTf), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Brand.Text,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { showTf = true }.padding(horizontal = 10.dp, vertical = 8.dp),
                )
                DropdownMenu(expanded = showTf, onDismissRequest = { showTf = false }, containerColor = Brand.Elevated) {
                    for ((g, label) in TIMEFRAMES) {
                        DropdownMenuItem(
                            text = { Text(label, color = if (Store.chartTf == g) Brand.Text else Brand.Muted, fontWeight = if (Store.chartTf == g) FontWeight.Bold else FontWeight.Normal) },
                            onClick = { Store.chartTf = g; Store.save(); showTf = false },
                        )
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            if (!locked) IconBtn("pencil", showBar) { showBar = !showBar; if (!showBar) ui.cancelTool() }
            if (!locked) IconBtn("indicators") { showInds = true }
            Box {
                IconBtn("camera") { showShot = true }
                DropdownMenu(expanded = showShot, onDismissRequest = { showShot = false }, containerColor = Brand.Elevated) {
                    DropdownMenuItem(text = { Text("Save image", color = Brand.Text) }, onClick = { showShot = false; capture(false) })
                    DropdownMenuItem(text = { Text("Save and share", color = Brand.Text) }, onClick = { showShot = false; capture(true) })
                }
            }
            Box {
                IconBtn("more") { showHub = true }
                DropdownMenu(expanded = showTypeMenu, onDismissRequest = { showTypeMenu = false }, containerColor = Brand.Elevated) {
                    TYPE_NAMES.forEachIndexed { i, n ->
                        DropdownMenuItem(text = { Text(n, color = if (Store.chartType == i) Brand.Text else Brand.Muted, fontWeight = if (Store.chartType == i) FontWeight.Bold else FontWeight.Normal) }, onClick = { Store.chartType = i; Store.save(); showTypeMenu = false })
                    }
                }
            }
            if (!locked) {
                Box(Modifier.padding(horizontal = 4.dp).width(1.dp).height(22.dp).background(Brand.Border))
                IconBtn("undo") { ui.undoLast() }
            }
        }
    }

    // ---- dialogs
    if (showPicker) MarketPicker(onPick = { Store.chartKey = it.key; Store.save(); showPicker = false }, onDismiss = { showPicker = false })
    if (showTools) ToolsDialog(onPick = { ui.pickTool(it); showTools = false }, onDismiss = { showTools = false })
    if (showInds) IndicatorsDialog(onDismiss = { showInds = false })
    if (showSetupBoard) SetupBoardSheet(model.setups[Store.setupStrategy.coerceIn(0, 8)], market, Store.chartTf, model.candles.dropLast(1), model.backfillMsg, { model.loadOlder() }) { showSetupBoard = false }
    if (showHub) Sheet(onDismiss = { showHub = false }) {
        Text("Analysis hub", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Text, modifier = Modifier.padding(bottom = 4.dp))
        HubLabel("TOOLS")
        HubRow {
            HubTile("indicators", "Indicators " + Store.indicators.size, Modifier.weight(1f), enabled = !locked) { showHub = false; showInds = true }
            HubTile("pencil", "Drawings", Modifier.weight(1f), enabled = !locked) { showHub = false; showTools = true }
        }
        HubRow {
            HubTile("alarm", "Alert at price", Modifier.weight(1f), enabled = !locked && last != null) {
                showHub = false
                if (last != null) newAlert(AlertDraft(last.c, "", "Price " + fp(last.c, market.dec)))
            }
            HubTile(TYPE_ICONS[Store.chartType.coerceIn(0, TYPE_ICONS.size - 1)], "Chart type", Modifier.weight(1f)) { showHub = false; showTypeMenu = true }
        }
        HubRow {
            HubTile("bell", "Indicator alert", Modifier.weight(1f), enabled = !locked) { showHub = false; showIndAlert = true }
            HubTile("sliders", "Position size", Modifier.weight(1f)) { showHub = false; showCalc = true }
        }
        HubRow {
            HubTile("copy", "Save to journal", Modifier.weight(1f), enabled = !locked) { showHub = false; showJournal = true }
            HubTile("cursor", "Open journal", Modifier.weight(1f)) { showHub = false; showJournal = true }
        }
        HubLabel("REPLAY")
        HubRow {
            HubTile("right", "Bar replay", Modifier.weight(1f), active = model.replaying) {
                showHub = false
                if (model.replaying) model.stopReplay()
                else model.startReplay(model.candles.size - 1 - ui.off.toInt() - (ui.bars / 2f).toInt())
            }
            HubTile("layers", "Alchemist levels", Modifier.weight(1f), active = Store.showAlch) { Store.showAlch = !Store.showAlch; Store.save() }
        }
        HubLabel("SETUPS")
        HubRow {
            HubTile("candles", "Setups on chart", Modifier.weight(1f), active = Store.setupOn != 0) { showHub = false; showInds = true }
            HubTile("info", "Setup dashboard", Modifier.weight(1f)) { showHub = false; showSetupBoard = true }
        }
        HubLabel("ON THE CHART")
        HubRow {
            HubTile("layers", "Key levels", Modifier.weight(1f), active = showLevels) { showLevels = !showLevels }
            HubTile("chart", "Trend ribbon", Modifier.weight(1f), active = showRibbon) { showRibbon = !showRibbon }
        }
        HubLabel("INFO")
        HubRow {
            HubTile("info", "Symbol details", Modifier.weight(1f)) { showHub = false; showDetails = true }
            HubTile(if (isOffline) "cloudoff" else "candles", if (isOffline) "Offline" else "Saved candles", Modifier.weight(1f)) { showHub = false; showDetails = true }
        }
    }
    if (showDetails) AlertDialog(
        onDismissRequest = { showDetails = false },
        containerColor = Brand.Elevated,
        title = { Text(market.name, color = Brand.Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Muted("Source: " + (if (market.src == 'b') "Binance" else "Deriv"), 13)
                Muted("Timeframe: " + tfLabel(Store.chartTf), 13)
                Muted("Price decimals: " + market.dec, 13)
                Muted("Candles on screen: " + cs.size + ". They are saved on this phone, so the chart opens offline and only the missing candles are fetched when you are back online.", 13)
                Muted("Status: " + model.status, 13)
            }
        },
        confirmButton = { TextButton(onClick = { showDetails = false }) { Text("Close", color = Brand.Text) } },
    )
    val tf = ui.textFor
    if (tf != null) {
        TextInputDialog(Tools.spec(tf.type)?.kind ?: "text", "", onOk = { ui.commitText(tf, it) }, onCancel = { ui.textFor = null })
    }
    val et = ui.editText
    if (et != null) {
        TextInputDialog("text", et.text, onOk = { et.text = it; ui.editText = null; ui.touch() }, onCancel = { ui.editText = null })
    }
    if (alertChoices.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { alertChoices = emptyList() },
            containerColor = Brand.Elevated,
            title = { Text("Alert on", color = Brand.Text) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (c in alertChoices) SecondaryButton(c.title + "  " + fp(c.level, market.dec), Modifier.fillMaxWidth()) { newAlert(c); alertChoices = emptyList() }
                }
            },
            confirmButton = { TextButton(onClick = { alertChoices = emptyList() }) { Text("Cancel", color = Brand.Text) } },
        )
    }
    // entry, stop and target from the selected long / short box, if there is one
    fun boxLevels(): DoubleArray {
        val d = ui.selected()
        return if (d != null && (d.type == "long" || d.type == "short") && d.pts.size >= 3) doubleArrayOf(d.pts[0].p, d.pts[1].p, d.pts[2].p) else doubleArrayOf(last?.c ?: 0.0, 0.0, 0.0)
    }
    if (showIndAlert) NewIndAlertDialog(market, Store.chartTf, onDismiss = { showIndAlert = false }, onCreated = {
        showIndAlert = false
        if (!WatchService.running) {
            Store.watching = true
            Store.save()
            WatchService.start(ctx)
        }
        Toast.makeText(ctx, "Indicator alert set.", Toast.LENGTH_SHORT).show()
    })
    if (showCalc) {
        val lv = boxLevels()
        AlertDialog(
            onDismissRequest = { showCalc = false },
            containerColor = Brand.Elevated,
            title = { Text("Position size", color = Brand.Text) },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { PositionCalcPanel(market, lv[0], lv[1], lv[2]) } },
            confirmButton = { TextButton(onClick = { showCalc = false }) { Text("Done", color = Brand.Text) } },
        )
    }
    if (showJournal) {
        val lv = boxLevels()
        JournalAddDialog(market, lv[0], lv[1], lv[2], onDismiss = { showJournal = false }, takeShot = { capture(false, true)?.toString() ?: "" }, onSaved = {
            showJournal = false
            Toast.makeText(ctx, "Saved to your journal (More, Trade journal).", Toast.LENGTH_SHORT).show()
        })
    }
    val ad = alertDraft
    if (ad != null) {
        NewAlertDialog(market, last?.c ?: ad.level, ad, onDismiss = { alertDraft = null }, onCreated = {
            alertDraft = null
            if (WatchService.running) {
                Watcher.refresh()
                Toast.makeText(ctx, "Alert set.", Toast.LENGTH_SHORT).show()
            } else {
                // the watcher is what checks the alert in the background, so start it
                Store.watching = true
                Store.save()
                WatchService.start(ctx)
                Toast.makeText(ctx, "Alert set. The watcher is now running so it can reach you.", Toast.LENGTH_LONG).show()
            }
        })
    }
}

@Composable
fun NewAlertDialog(market: Market, current: Double, draft: AlertDraft, onDismiss: () -> Unit, onCreated: () -> Unit) {
    var level by remember { mutableDoubleStateOf(draft.level) }
    var above by remember { mutableStateOf(draft.level > current) }
    var mode by remember { mutableIntStateOf(Store.modeOf(AlertKind.PRICE_ALERT).coerceAtLeast(1)) }
    var once by remember { mutableStateOf(true) }
    var expiry by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Elevated,
        title = { Text("New alert", color = Brand.Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Muted(market.name + "  \u00B7  " + draft.title + ". Now " + fp(current, market.dec), 12)
                DecField("Price", level, Modifier.fillMaxWidth()) { level = it; above = it > current }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = above, onClick = { above = true }, label = { Text("Crosses up") })
                    FilterChip(selected = !above, onClick = { above = false }, label = { Text("Crosses down") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text("Normal") })
                    FilterChip(selected = mode == 2, onClick = { mode = 2 }, label = { Text("Urgent") })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (once) "Only once" else "Every time it crosses", Modifier.weight(1f), color = Brand.Text)
                    Switch(checked = once, onCheckedChange = { once = it })
                }
                Muted("Expires", 12)
                ExpiryChips(expiry) { expiry = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Store.addPriceAlert(market.key, level, draft.drawingId, above, mode, once, draft.title, expiryTime(expiry))
                onCreated()
            }) { Text("Create alert", color = Brand.Alert, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Brand.Muted) } },
    )
}

@Composable
fun IndicatorsDialog(onDismiss: () -> Unit) {
    var editId by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Elevated,
        title = { Text("Indicators", color = Brand.Text) },
        text = {
            LazyColumn(Modifier.heightIn(max = 440.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                item {
                    Row(Modifier.fillMaxWidth().background(Brand.Panel, RoundedCornerShape(10.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Alchemist levels", color = Brand.Text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Muted("Fresh and used levels on closes, with RBS / SBR flips. No trades.", 11)
                        }
                        Switch(checked = Store.showAlch, onCheckedChange = { Store.showAlch = it; Store.save() })
                    }
                }
                item { Muted("Setups (entry, stop, target and an arrow)", 12) }
                items(SETUP_ORDER) { si ->
                    Row(Modifier.fillMaxWidth().background(Brand.Panel, RoundedCornerShape(10.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(SETUP_SHORT[si], Modifier.weight(1f), color = Brand.Text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Switch(checked = Store.setupIsOn(si), onCheckedChange = { Store.toggleSetup(si) })
                    }
                }
                item { Muted("On the chart", 12) }
                if (Store.indicators.isEmpty()) item { Muted("None yet. Add one below.", 12) }
                items(Store.indicators) { cfg ->
                    val spec = IndSpecs.spec(cfg.type)
                    Column(Modifier.fillMaxWidth().background(Brand.Panel, RoundedCornerShape(10.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(spec.name, Modifier.weight(1f), color = Brand.Text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            TextButton(onClick = { editId = if (editId == cfg.id) null else cfg.id }) { Text("Edit", color = Brand.Text) }
                            TextButton(onClick = { Store.indicators = Store.indicators.filter { it.id != cfg.id }; Store.save() }) { Text("Remove", color = Brand.Danger) }
                        }
                        if (editId == cfg.id) {
                            if (spec.labels.isNotEmpty()) IntField(spec.labels[0], cfg.p1, Modifier.fillMaxWidth()) { v -> Store.indicators = Store.indicators.map { if (it.id == cfg.id) it.copy(p1 = v) else it }; Store.save() }
                            if (spec.labels.size > 1) IntField(spec.labels[1], cfg.p2, Modifier.fillMaxWidth()) { v -> Store.indicators = Store.indicators.map { if (it.id == cfg.id) it.copy(p2 = v) else it }; Store.save() }
                            if (spec.labels.size > 2) IntField(spec.labels[2], cfg.p3, Modifier.fillMaxWidth()) { v -> Store.indicators = Store.indicators.map { if (it.id == cfg.id) it.copy(p3 = v) else it }; Store.save() }
                            SwatchRow(cfg.color) { c -> Store.indicators = Store.indicators.map { if (it.id == cfg.id) it.copy(color = c) else it }; Store.save() }
                        }
                    }
                }
                item { Muted("Add", 12) }
                items(IndSpecs.ALL) { spec ->
                    Text(
                        (if (spec.overlay) "On chart: " else "Below chart: ") + spec.name, color = Brand.Text, fontSize = 14.sp,
                        modifier = Modifier.fillMaxWidth().clickable {
                            Store.indicators = Store.indicators + IndCfg(UUID.randomUUID().toString(), spec.type, spec.d1, spec.d2, spec.d3, IND_COLORS[Store.indicators.size % IND_COLORS.size])
                            Store.save()
                        }.padding(vertical = 8.dp),
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done", color = Brand.Text) } },
    )
}
