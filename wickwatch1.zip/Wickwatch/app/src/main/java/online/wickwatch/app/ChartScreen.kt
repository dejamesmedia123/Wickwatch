package online.wickwatch.app

import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import java.util.UUID
import kotlin.math.exp
import kotlin.math.hypot
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.runtime.mutableLongStateOf
import kotlinx.coroutines.delay

/** Loads one market, keeps it live, and runs the Ribbon and key-level engines on every new closed candle. */
class ChartModel(private val scope: CoroutineScope) {
    var candles by mutableStateOf<List<Candle>>(emptyList())
    var ribbon by mutableStateOf<RibbonResult?>(null)
    var levels by mutableStateOf<LevelsResult?>(null)
    var setups by mutableStateOf<SetupScan?>(null)
    var status by mutableStateOf("loading...")
    private var feed: SeriesFeed? = null
    private var lastClosed = 0L
    private val main = Handler(Looper.getMainLooper())

    fun open(m: Market, tf: Int) {
        feed?.stop()
        candles = emptyList()
        ribbon = null
        levels = null
        setups = null
        lastClosed = 0L
        status = "loading..."
        val f = SeriesFeed(m, tf, scope, { list, _, _ -> onData(list) }, { s -> main.post { status = s } }, cache = true, maxCandles = 2000)
        feed = f
        f.start()
    }

    private fun onData(list: List<Candle>) {
        val closed = list.dropLast(1)
        var rb: RibbonResult? = null
        var lv: LevelsResult? = null
        var fresh = false
        var sc: SetupScan? = null
        if (closed.size >= 100 && closed[closed.size - 1].t != lastClosed) {
            lastClosed = closed[closed.size - 1].t
            try {
                rb = Ribbon.analyze(closed)
                lv = Levels.analyze(closed)
                fresh = true
            } catch (e: Exception) {
                // still show the candles
            }
            try {
                sc = SetupEngine.scan(closed, Store.setupParams())
            } catch (e: Exception) {
                sc = null
            }
        }
        main.post {
            candles = list
            if (fresh) {
                ribbon = rb
                levels = lv
            }
            if (sc != null) setups = sc
        }
    }

    /** Run the setup finder again on the candles on screen (after its settings changed). */
    fun refreshSetups() {
        val closed = candles.dropLast(1)
        if (closed.size < 100) return
        val p = Store.setupParams()
        Thread {
            val sc = try { SetupEngine.scan(closed, p) } catch (e: Exception) { null }
            if (sc != null) main.post { setups = sc }
        }.start()
    }

    fun close() {
        feed?.stop()
        feed = null
    }
}

/** Everything the chart screen keeps track of: view, drawings, selection, gestures. */
class ChartUi {
    var bars by mutableFloatStateOf(90f)
    var off by mutableFloatStateOf(0f)
    var auto by mutableStateOf(true)
    var freeLo by mutableDoubleStateOf(0.0)
    var freeHi by mutableDoubleStateOf(1.0)
    var size by mutableStateOf(IntSize.Zero)
    var geo: Geo? = null
    var candles: List<Candle> = emptyList()
    var rev by mutableIntStateOf(0)
    var tool by mutableStateOf("")
    val pending = mutableStateListOf<DPoint>()
    val drawings = mutableStateListOf<Drawing>()
    var selectedId by mutableStateOf<String?>(null)
    var cross by mutableStateOf<Offset?>(null)
    var textFor by mutableStateOf<Drawing?>(null)
    var editText by mutableStateOf<Drawing?>(null)
    var marketKey = ""

    private var dragMode = 0
    private var dragHandle = -1
    private var dragStart = Offset.Zero
    private var dragOrig: List<DPoint> = emptyList()

    fun load(key: String) {
        marketKey = key
        drawings.clear()
        drawings.addAll(Store.loadDrawings(key))
        selectedId = null
        pending.clear()
        tool = ""
        cross = null
        rev += 1
    }

    fun persist() {
        if (marketKey.isNotEmpty()) Store.saveDrawings(marketKey, drawings.toList())
    }

    fun selected(): Drawing? = drawings.firstOrNull { it.id == selectedId }

    fun pickTool(id: String) {
        tool = id
        pending.clear()
        selectedId = null
        cross = null
    }

    fun cancelTool() {
        tool = ""
        pending.clear()
    }

    private fun add(d: Drawing) {
        drawings.add(d)
        selectedId = d.id
        tool = ""
        pending.clear()
        persist()
        rev += 1
    }

    fun drawTap(o: Offset) {
        val g = geo ?: return
        val spec = Tools.spec(tool) ?: return
        if (o.y > g.bottom || o.x > g.pw) return
        pending.add(Draw.fromScreen(g, candles, o, Store.magnet))
        if (spec.n > 0 && pending.size >= spec.n) finish()
    }

    /** Completes a drawing (used by the Done button for Path and Polyline). */
    fun finish() {
        val spec = Tools.spec(tool) ?: return
        if (pending.size < (if (spec.n == -1) 2 else max1(spec.n))) return
        val d = Draw.make(spec, pending.toList(), "")
        if (Tools.needsText(spec.kind)) {
            textFor = d
            pending.clear()
        } else {
            add(d)
        }
    }

    private fun max1(n: Int): Int = if (n < 1) 2 else n

    fun commitText(d: Drawing, text: String) {
        d.text = text
        textFor = null
        add(d)
    }

    fun freeStart(o: Offset) {
        val g = geo ?: return
        pending.clear()
        pending.add(Draw.fromScreen(g, candles, o, false))
    }

    fun freeMove(o: Offset) {
        val g = geo ?: return
        pending.add(Draw.fromScreen(g, candles, o, false))
    }

    fun freeEnd() {
        val spec = Tools.spec(tool) ?: return
        if (pending.size >= 2) add(Draw.make(spec, pending.toList(), "")) else pending.clear()
    }

    fun tapNormal(o: Offset) {
        val g = geo ?: return
        var best: Drawing? = null
        var bd = 36f
        for (d in drawings) {
            val dist = Draw.hitDist(d, g, o.x, o.y)
            if (dist < bd) {
                bd = dist
                best = d
            }
        }
        if (best != null) {
            selectedId = best.id
        } else {
            selectedId = null
            cross = null
        }
        rev += 1
    }

    fun panZoom(pan: Offset, zoom: Float) {
        val g = geo ?: return
        bars = (bars / zoom).coerceIn(20f, 400f)
        off = (off + pan.x / (g.pw / bars)).coerceIn(0f, 2000f)
        if (!auto) {
            val dTr = pan.y / (g.bottom - g.top) * (g.hi - g.lo)
            freeLo += dTr
            freeHi += dTr
        }
    }

    fun axisDrag(dy: Float) {
        val g = geo ?: return
        if (auto) {
            auto = false
            freeLo = g.autoLo
            freeHi = g.autoHi
        }
        val f = exp((dy / 250f).toDouble())
        val c = (freeLo + freeHi) / 2.0
        val half = (freeHi - freeLo) / 2.0 * f
        freeLo = c - half
        freeHi = c + half
    }

    fun editStart(o: Offset) {
        val g = geo ?: return
        val d = selected()
        dragStart = o
        if (d == null) {
            dragMode = 3
            return
        }
        if (!d.locked) {
            val hs = Draw.handles(d, g)
            var bi = -1
            var bd = 56f
            for ((i, h) in hs.withIndex()) {
                val dist = hypot(o.x - h.x, o.y - h.y)
                if (dist < bd) {
                    bd = dist
                    bi = i
                }
            }
            if (bi >= 0) {
                dragMode = 1
                dragHandle = bi
                return
            }
            if (Draw.hitDist(d, g, o.x, o.y) < 40f) {
                dragMode = 2
                dragOrig = d.pts
                return
            }
        }
        dragMode = 3
    }

    fun editMove(pos: Offset, amt: Offset) {
        val g = geo ?: return
        val d = selected()
        if (dragMode == 1 && d != null) {
            Draw.movePoint(d, g, candles, dragHandle, pos, Store.magnet)
            rev += 1
        } else if (dragMode == 2 && d != null) {
            val dIdx = (pos.x - dragStart.x).toDouble() / g.barW.toDouble()
            val dTr = -(pos.y - dragStart.y).toDouble() / (g.bottom - g.top).toDouble() * (g.hi - g.lo)
            d.pts = Draw.translate(g, dragOrig, dIdx, dTr)
            rev += 1
        } else {
            panZoom(amt, 1f)
        }
    }

    fun editEnd() {
        if (dragMode == 1 || dragMode == 2) persist()
        dragMode = 0
    }

    fun deleteSelected() {
        val d = selected() ?: return
        drawings.remove(d)
        selectedId = null
        persist()
        rev += 1
    }

    fun duplicateSelected() {
        val d = selected() ?: return
        val g = geo
        val shift = if (g != null) g.step * 3 else 180L
        val c = Drawing(UUID.randomUUID().toString(), d.type, d.pts.map { DPoint(it.t + shift, it.p) }, d.color, d.text, false, d.width, d.dashed)
        drawings.add(c)
        selectedId = c.id
        persist()
        rev += 1
    }

    fun touch() {
        persist()
        rev += 1
    }
}

class AlertDraft(val level: Double, val drawingId: String, val title: String)

private val TYPE_NAMES = listOf("Candles", "Hollow candles", "Bars", "Line", "Area", "Heikin Ashi")
private val TYPE_ICONS = listOf("candles", "candles", "bars", "line", "area", "candles")

/** The value (price) of a straight-line drawing at a given time. */
fun lineValueAt(d: Drawing, t: Long): Double? {
    if (d.pts.size < 2) return null
    val a = d.pts[0]
    val b = d.pts[1]
    if (b.t == a.t) return a.p
    return a.p + (b.p - a.p) * (t - a.t).toDouble() / (b.t - a.t).toDouble()
}

private fun alertTargets(d: Drawing, now: Long): List<AlertDraft> {
    val k = Tools.spec(d.type)?.kind ?: return emptyList()
    return when (k) {
        "hline", "hray" -> listOf(AlertDraft(d.pts[0].p, "", "This price line"))
        "seg", "ray", "ext", "info" -> {
            val v = lineValueAt(d, now)
            if (v == null) emptyList() else listOf(AlertDraft(v, d.id, "This line (the alert follows the line)"))
        }
        "rect", "pdrange" -> listOf(AlertDraft(maxOf(d.pts[0].p, d.pts[1].p), "", "Top edge"), AlertDraft(minOf(d.pts[0].p, d.pts[1].p), "", "Bottom edge"))
        "long", "short" -> if (d.pts.size >= 3) listOf(AlertDraft(d.pts[0].p, "", "Entry"), AlertDraft(d.pts[1].p, "", "Stop"), AlertDraft(d.pts[2].p, "", "Target")) else emptyList()
        else -> emptyList()
    }
}

@Composable
private fun SmallBtn(text: String, selected: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(8.dp)).background(if (selected) Brand.Primary else Brand.Elevated)
            .clickable { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp),
    ) {
        Text(text, color = if (selected) Brand.Bg else Brand.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun ChartScreen() {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val model = remember { ChartModel(scope) }
    val ui = remember { ChartUi() }
    var showPicker by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var showInds by remember { mutableStateOf(false) }
    var showTypeMenu by remember { mutableStateOf(false) }
    var showHub by remember { mutableStateOf(false) }
    var showTf by remember { mutableStateOf(false) }
    var showDetails by remember { mutableStateOf(false) }
    var clock by remember { mutableLongStateOf(0L) }          // ticks every second so the candle countdown moves
    var barOff by remember { mutableStateOf(Offset.Zero) }    // where the person dragged the tools bar to
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            clock = System.currentTimeMillis()
        }
    }
    var showRibbon by rememberSaveable { mutableStateOf(false) }
    var showLevels by rememberSaveable { mutableStateOf(true) }
    var showSetups by rememberSaveable { mutableStateOf(true) }
    var showSetupBoard by remember { mutableStateOf(false) }
    LaunchedEffect(Store.setupMode, Store.setupScore, Store.setupRR, Store.setupImpulse, Store.setupDirs) { model.refreshSetups() }
    var alertDraft by remember { mutableStateOf<AlertDraft?>(null) }
    var alertChoices by remember { mutableStateOf<List<AlertDraft>>(emptyList()) }

    val locked = Expiry.locked   // view-only once this version has run out
    val isOffline = model.status.startsWith("offline")
    val market = marketByKey(Store.chartKey) ?: MARKETS[0]
    LaunchedEffect(Store.chartKey, Store.chartTf) {
        ui.load(Store.chartKey)
        marketByKey(Store.chartKey)?.let { model.open(it, Store.chartTf) }
    }
    LaunchedEffect(Store.scaleType) { ui.auto = true }
    DisposableEffect(Unit) { onDispose { model.close() } }

    val cs = model.candles
    ui.candles = cs
    val shown = if (Store.chartType == 5) heikin(cs) else cs
    val outs = remember(cs, Store.indicators) { Store.indicators.map { it to computeInd(it, cs) } }
    val subCount = outs.count { !IndSpecs.spec(it.first.type).overlay }.coerceAtMost(3)
    val sz = ui.size
    val geo: Geo? = if (cs.size >= 2 && sz.width > 0 && sz.height > 0) {
        with(density) {
            buildGeo(sz.width.toFloat(), sz.height.toFloat(), 64.dp.toPx(), 22.dp.toPx(), shown, ui.bars, ui.off, Store.scaleType, ui.auto, ui.freeLo, ui.freeHi, subCount)
        }
    } else null
    ui.geo = geo
    val last = cs.lastOrNull()
    val first = if (cs.size >= 2) cs[maxOf(0, cs.size - 1 - 96)] else null
    val change = if (last != null && first != null && first.o != 0.0) (last.c / first.o - 1.0) * 100.0 else 0.0

    fun newAlert(d: AlertDraft) {
        alertDraft = d
    }

    Column(Modifier.fillMaxSize().background(Brand.Bg)) {
        // ---- header: symbol, status, price
        val st = model.status
        val isLive = st == "live"
        val isOff = st.startsWith("offline")
        val statusText = if (isLive) "Live" else if (isOff) "Offline - showing saved candles" else st
        val dotColor = if (isLive) Brand.Good else if (isOff) Brand.Alert else Brand.Muted
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Brand.Elevated).border(1.dp, Brand.Border, CircleShape), contentAlignment = Alignment.Center) {
                Text(market.name.take(2).uppercase(), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Text)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.clickable { showPicker = true }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(market.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Brand.Text)
                    Spacer(Modifier.width(2.dp))
                    WIcon("down", size = 16.dp, tint = Brand.Muted)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).clip(CircleShape).background(dotColor))
                    Spacer(Modifier.width(5.dp))
                    Muted((if (market.src == 'b') "Binance" else "Deriv") + "  \u00B7  " + statusText, 11)
                }
            }
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.End) {
                Mono(if (last != null) fp(last.c, market.dec) else "-", 20, Brand.Text, true)
                Mono((if (change >= 0) "+" else "") + fp(change, 2) + "%", 12, if (change >= 0) Brand.Good else Brand.Danger)
            }
        }
        // ---- top bar: timeframe, chart type, indicators, alert, menu
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box {
                Row(Modifier.clip(RoundedCornerShape(10.dp)).clickable { showTf = true }.padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tfLabel(Store.chartTf), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Brand.Text)
                    Spacer(Modifier.width(2.dp))
                    WIcon("down", size = 14.dp, tint = Brand.Muted)
                }
                DropdownMenu(expanded = showTf, onDismissRequest = { showTf = false }, containerColor = Brand.Elevated) {
                    for ((g, label) in TIMEFRAMES) {
                        DropdownMenuItem(
                            text = { Text(label, color = if (Store.chartTf == g) Brand.Alert else Brand.Text, fontWeight = if (Store.chartTf == g) FontWeight.Bold else FontWeight.Normal) },
                            onClick = { Store.chartTf = g; Store.save(); showTf = false },
                        )
                    }
                }
            }
            Box(Modifier.width(1.dp).height(20.dp).background(Brand.Border))
            Box {
                IconBtn(TYPE_ICONS[Store.chartType.coerceIn(0, TYPE_ICONS.size - 1)]) { showTypeMenu = true }
                DropdownMenu(expanded = showTypeMenu, onDismissRequest = { showTypeMenu = false }, containerColor = Brand.Elevated) {
                    TYPE_NAMES.forEachIndexed { i, n ->
                        DropdownMenuItem(text = { Text(n, color = if (Store.chartType == i) Brand.Alert else Brand.Text) }, onClick = { Store.chartType = i; Store.save(); showTypeMenu = false })
                    }
                }
            }
            if (!locked) IconBtn("indicators") { showInds = true }
            if (!locked) IconBtn("alarm") { if (last != null) newAlert(AlertDraft(last.c, "", "Price " + fp(last.c, market.dec))) }
            Spacer(Modifier.weight(1f))
            IconBtn("layers") { showHub = true }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Brand.Border))

        // ---- the chart
        Box(Modifier.weight(1f).fillMaxWidth().padding(top = 4.dp).onSizeChanged { ui.size = it }) {
            if (geo == null) {
                Text("Loading " + market.name + "...", color = Brand.Muted, modifier = Modifier.align(Alignment.Center))
            } else {
                val mine = Store.priceAlerts.filter { it.active && it.key == market.key }
                val gestures: Modifier = when {
                    locked ->
                        Modifier.pointerInput(Unit) { detectTransformGestures { _, pan, zoom, _ -> ui.panZoom(pan, zoom) } }
                            .pointerInput(3) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { ui.cross = it },
                                    onDrag = { c, _ -> c.consume(); ui.cross = c.position },
                                )
                            }
                    ui.tool != "" && (Tools.spec(ui.tool)?.n == 0) ->
                        Modifier.pointerInput(ui.tool) {
                            detectDragGestures(
                                onDragStart = { ui.freeStart(it) },
                                onDrag = { c, _ -> c.consume(); ui.freeMove(c.position) },
                                onDragEnd = { ui.freeEnd() },
                                onDragCancel = { ui.freeEnd() },
                            )
                        }
                    ui.tool != "" -> Modifier.pointerInput(ui.tool) { detectTapGestures(onTap = { ui.drawTap(it) }) }
                    ui.selectedId != null ->
                        Modifier.pointerInput(ui.selectedId) {
                            detectDragGestures(
                                onDragStart = { ui.editStart(it) },
                                onDrag = { c, amt -> c.consume(); ui.editMove(c.position, amt) },
                                onDragEnd = { ui.editEnd() },
                                onDragCancel = { ui.editEnd() },
                            )
                        }.pointerInput(ui.selectedId, 1) { detectTapGestures(onTap = { ui.tapNormal(it) }) }
                    else ->
                        Modifier.pointerInput(Unit) { detectTransformGestures { _, pan, zoom, _ -> ui.panZoom(pan, zoom) } }
                            .pointerInput(2) { detectTapGestures(onTap = { ui.tapNormal(it) }) }
                            .pointerInput(3) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { ui.cross = it },
                                    onDrag = { c, _ -> c.consume(); ui.cross = c.position },
                                )
                            }
                }
                Canvas(Modifier.fillMaxSize().then(gestures)) {
                    ui.rev
                    clock
                    drawChart(
                        geo, cs, shown, Store.chartType, market.dec, outs,
                        if (showRibbon) model.ribbon else null, model.levels, showRibbon, showLevels,
                        mine, ui.drawings.toList(), ui.selectedId, ui.pending.toList(), Tools.spec(ui.tool)?.kind ?: "", ui.cross,
                        setups = if (showSetups) model.setups else null, showSetups = showSetups,
                    )
                }
                // drag the price axis to stretch the scale; double tap to go back to auto
                Box(
                    Modifier.align(Alignment.TopEnd).width(64.dp).height(with(density) { geo.bottom.toDp() })
                        .pointerInput(Unit) { detectVerticalDragGestures(onVerticalDrag = { c, dy -> c.consume(); ui.axisDrag(dy) }) }
                        .pointerInput(4) { detectTapGestures(onDoubleTap = { ui.auto = true }) },
                )
                // setup finder: last 10 result and win rate, tap for the dashboard
                if (showSetups) model.setups?.let { sc ->
                    SetupChip(sc, Modifier.align(Alignment.TopStart).padding(start = 8.dp, top = 58.dp)) { showSetupBoard = true }
                }
                // floating tools bar: drag the grip to move it
                if (!locked) Row(
                    Modifier.align(Alignment.TopCenter).offset { IntOffset(barOff.x.roundToInt(), barOff.y.roundToInt()) }.padding(top = 8.dp)
                        .clip(RoundedCornerShape(14.dp)).background(Brand.Elevated.copy(alpha = 0.97f)).border(1.dp, Brand.Border, RoundedCornerShape(14.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.width(26.dp).height(40.dp).pointerInput(Unit) { detectDragGestures { c, d -> c.consume(); barOff += d } },
                        contentAlignment = Alignment.Center,
                    ) { WIcon("grip", size = 20.dp, tint = Brand.Muted) }
                    Row(Modifier.widthIn(max = 260.dp).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                        IconBtn("cursor", ui.tool == "") { ui.cancelTool() }
                        for (id in Store.favTools) {
                            val spec = Tools.spec(id) ?: continue
                            IconBtn(toolIcon(spec.kind), ui.tool == id) { ui.pickTool(id) }
                        }
                        IconBtn("plus") { showTools = true }
                    }
                }
                // scale controls
                Row(Modifier.align(Alignment.BottomStart).padding(start = 8.dp, bottom = 30.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    SmallBtn(if (ui.auto) "Auto" else "Free", !ui.auto) { if (ui.auto) { ui.auto = false; ui.freeLo = geo.autoLo; ui.freeHi = geo.autoHi } else ui.auto = true }
                    SmallBtn("Log", Store.scaleType == 1) { Store.scaleType = if (Store.scaleType == 1) 0 else 1; Store.save() }
                    SmallBtn("%", Store.scaleType == 2) { Store.scaleType = if (Store.scaleType == 2) 0 else 2; Store.save() }
                    IconBtn("right", size = 32.dp) { ui.off = 0f }
                }
                // what to do next
                val spec = if (locked) null else Tools.spec(ui.tool)
                if (spec != null) {
                    Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 58.dp).clip(RoundedCornerShape(12.dp)).background(Brand.Elevated).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            if (spec.n == 0) spec.name + ": drag on the chart" else if (spec.n == -1) spec.name + ": tap points (" + ui.pending.size + ")" else spec.name + ": tap point " + (ui.pending.size + 1) + " of " + spec.n,
                            color = Brand.Text, fontSize = 12.sp,
                        )
                        if (spec.n == -1) SmallBtn("Done") { ui.finish() }
                        SmallBtn("Cancel") { ui.cancelTool() }
                    }
                }
                // selected drawing toolbar
                val sd = if (locked) null else ui.selected()
                if (sd != null && spec == null) {
                    Column(
                        Modifier.align(Alignment.BottomCenter).padding(bottom = 30.dp, start = 8.dp, end = 8.dp).clip(RoundedCornerShape(12.dp)).background(Brand.Elevated).padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            for (c in SWATCHES.take(10)) {
                                Box(Modifier.size(24.dp).clip(CircleShape).background(Color(c)).border(if (sd.color == c) 3.dp else 1.dp, if (sd.color == c) Brand.Alert else Brand.Border, CircleShape).clickable { sd.color = c; ui.touch() })
                            }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            for (w in listOf(1, 2, 3, 5)) SmallBtn(w.toString(), sd.width == w) { sd.width = w; ui.touch() }
                            IconBtn("dash", sd.dashed, size = 36.dp) { sd.dashed = !sd.dashed; ui.touch() }
                            IconBtn(if (sd.locked) "lock" else "unlock", sd.locked, size = 36.dp) { sd.locked = !sd.locked; ui.touch() }
                            IconBtn("copy", size = 36.dp) { ui.duplicateSelected() }
                            if (Tools.needsText(Tools.spec(sd.type)?.kind ?: "")) IconBtn("pencil", size = 36.dp) { ui.editText = sd }
                            val targets = alertTargets(sd, System.currentTimeMillis() / 1000L)
                            if (targets.isNotEmpty()) IconBtn("alarm", size = 36.dp) { if (targets.size == 1) newAlert(targets[0]) else alertChoices = targets }
                            IconBtn("trash", size = 36.dp) { ui.deleteSelected() }
                        }
                    }
                }
                // long press: crosshair actions
                val cr = ui.cross
                if (cr != null && sd == null && spec == null) {
                    val p = geo.priceAtY(cr.y)
                    Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 30.dp).clip(RoundedCornerShape(12.dp)).background(Brand.Elevated).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Mono(fp(p, market.dec), 13)
                        if (!locked) SmallBtn("Alert here", true) { newAlert(AlertDraft(p, "", "Price " + fp(p, market.dec))); ui.cross = null }
                        SmallBtn("Clear") { ui.cross = null }
                    }
                }
            }
        }
    }

    // ---- dialogs
    if (showPicker) MarketPicker(onPick = { Store.chartKey = it.key; Store.save(); showPicker = false }, onDismiss = { showPicker = false })
    if (showTools) ToolsDialog(onPick = { ui.pickTool(it); showTools = false }, onDismiss = { showTools = false })
    if (showInds) IndicatorsDialog(onDismiss = { showInds = false })
    if (showSetupBoard) SetupBoardSheet(model.setups, market, Store.chartTf) { showSetupBoard = false }
    if (showHub) Sheet(onDismiss = { showHub = false }) {
        Text("Analysis hub", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Text, modifier = Modifier.padding(bottom = 4.dp))
        HubLabel("TOOLS")
        HubRow {
            HubTile("indicators", "Indicators " + Store.indicators.size, Modifier.weight(1f), enabled = !locked) { showHub = false; showInds = true }
            HubTile("pencil", "Drawings", Modifier.weight(1f), enabled = !locked) { showHub = false; showTools = true }
        }
        HubRow {
            HubTile("alarm", "Alert at price", Modifier.weight(1f), enabled = !locked && last != null) {
                showHub = false
                if (last != null) newAlert(AlertDraft(last.c, "", "Price " + fp(last.c, market.dec)))
            }
            HubTile(TYPE_ICONS[Store.chartType.coerceIn(0, TYPE_ICONS.size - 1)], "Chart type", Modifier.weight(1f)) { showHub = false; showTypeMenu = true }
        }
        HubLabel("ON THE CHART")
        HubRow {
            HubTile("layers", "Key levels", Modifier.weight(1f), active = showLevels) { showLevels = !showLevels }
            HubTile("chart", "Trend ribbon", Modifier.weight(1f), active = showRibbon) { showRibbon = !showRibbon }
        }
        HubRow {
            HubTile("candles", "Setup finder", Modifier.weight(1f), active = showSetups) { showSetups = !showSetups }
            HubTile("info", "Setup dashboard", Modifier.weight(1f)) { showHub = false; showSetupBoard = true }
        }
        HubLabel("INFO")
        HubRow {
            HubTile("info", "Symbol details", Modifier.weight(1f)) { showHub = false; showDetails = true }
            HubTile(if (isOffline) "cloudoff" else "candles", if (isOffline) "Offline" else "Saved candles", Modifier.weight(1f)) { showHub = false; showDetails = true }
        }
    }
    if (showDetails) AlertDialog(
        onDismissRequest = { showDetails = false },
        containerColor = Brand.Elevated,
        title = { Text(market.name, color = Brand.Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Muted("Source: " + (if (market.src == 'b') "Binance" else "Deriv"), 13)
                Muted("Timeframe: " + tfLabel(Store.chartTf), 13)
                Muted("Price decimals: " + market.dec, 13)
                Muted("Candles on screen: " + cs.size + ". They are saved on this phone, so the chart opens offline and only the missing candles are fetched when you are back online.", 13)
                Muted("Status: " + model.status, 13)
            }
        },
        confirmButton = { TextButton(onClick = { showDetails = false }) { Text("Close", color = Brand.Text) } },
    )
    val tf = ui.textFor
    if (tf != null) {
        TextInputDialog(Tools.spec(tf.type)?.kind ?: "text", "", onOk = { ui.commitText(tf, it) }, onCancel = { ui.textFor = null })
    }
    val et = ui.editText
    if (et != null) {
        TextInputDialog("text", et.text, onOk = { et.text = it; ui.editText = null; ui.touch() }, onCancel = { ui.editText = null })
    }
    if (alertChoices.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { alertChoices = emptyList() },
            containerColor = Brand.Elevated,
            title = { Text("Alert on", color = Brand.Text) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (c in alertChoices) SecondaryButton(c.title + "  " + fp(c.level, market.dec), Modifier.fillMaxWidth()) { newAlert(c); alertChoices = emptyList() }
                }
            },
            confirmButton = { TextButton(onClick = { alertChoices = emptyList() }) { Text("Cancel", color = Brand.Text) } },
        )
    }
    val ad = alertDraft
    if (ad != null) {
        NewAlertDialog(market, last?.c ?: ad.level, ad, onDismiss = { alertDraft = null }, onCreated = {
            alertDraft = null
            if (WatchService.running) {
                Watcher.refresh()
                Toast.makeText(ctx, "Alert set.", Toast.LENGTH_SHORT).show()
            } else {
                // the watcher is what checks the alert in the background, so start it
                Store.watching = true
                Store.save()
                WatchService.start(ctx)
                Toast.makeText(ctx, "Alert set. The watcher is now running so it can reach you.", Toast.LENGTH_LONG).show()
            }
        })
    }
}

@Composable
fun NewAlertDialog(market: Market, current: Double, draft: AlertDraft, onDismiss: () -> Unit, onCreated: () -> Unit) {
    var level by remember { mutableDoubleStateOf(draft.level) }
    var above by remember { mutableStateOf(draft.level > current) }
    var mode by remember { mutableIntStateOf(Store.modeOf(AlertKind.PRICE_ALERT).coerceAtLeast(1)) }
    var once by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Elevated,
        title = { Text("New alert", color = Brand.Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Muted(market.name + "  \u00B7  " + draft.title + ". Now " + fp(current, market.dec), 12)
                DecField("Price", level, Modifier.fillMaxWidth()) { level = it; above = it > current }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = above, onClick = { above = true }, label = { Text("Crosses up") })
                    FilterChip(selected = !above, onClick = { above = false }, label = { Text("Crosses down") })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text("Normal") })
                    FilterChip(selected = mode == 2, onClick = { mode = 2 }, label = { Text("Urgent") })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Only once", Modifier.weight(1f), color = Brand.Text)
                    Switch(checked = once, onCheckedChange = { once = it })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Store.addPriceAlert(market.key, level, draft.drawingId, above, mode, once, draft.title)
                onCreated()
            }) { Text("Create alert", color = Brand.Alert, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Brand.Muted) } },
    )
}

@Composable
fun IndicatorsDialog(onDismiss: () -> Unit) {
    var editId by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Elevated,
        title = { Text("Indicators", color = Brand.Text) },
        text = {
            LazyColumn(Modifier.heightIn(max = 440.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                item { Muted("On the chart", 12) }
                if (Store.indicators.isEmpty()) item { Muted("None yet. Add one below.", 12) }
                items(Store.indicators) { cfg ->
                    val spec = IndSpecs.spec(cfg.type)
                    Column(Modifier.fillMaxWidth().background(Brand.Panel, RoundedCornerShape(10.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(spec.name, Modifier.weight(1f), color = Brand.Text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            TextButton(onClick = { editId = if (editId == cfg.id) null else cfg.id }) { Text("Edit", color = Brand.Text) }
                            TextButton(onClick = { Store.indicators = Store.indicators.filter { it.id != cfg.id }; Store.save() }) { Text("Remove", color = Brand.Danger) }
                        }
                        if (editId == cfg.id) {
                            if (spec.labels.isNotEmpty()) IntField(spec.labels[0], cfg.p1, Modifier.fillMaxWidth()) { v -> Store.indicators = Store.indicators.map { if (it.id == cfg.id) it.copy(p1 = v) else it }; Store.save() }
                            if (spec.labels.size > 1) IntField(spec.labels[1], cfg.p2, Modifier.fillMaxWidth()) { v -> Store.indicators = Store.indicators.map { if (it.id == cfg.id) it.copy(p2 = v) else it }; Store.save() }
                            if (spec.labels.size > 2) IntField(spec.labels[2], cfg.p3, Modifier.fillMaxWidth()) { v -> Store.indicators = Store.indicators.map { if (it.id == cfg.id) it.copy(p3 = v) else it }; Store.save() }
                            SwatchRow(cfg.color) { c -> Store.indicators = Store.indicators.map { if (it.id == cfg.id) it.copy(color = c) else it }; Store.save() }
                        }
                    }
                }
                item { Muted("Add", 12) }
                items(IndSpecs.ALL) { spec ->
                    Text(
                        (if (spec.overlay) "On chart: " else "Below chart: ") + spec.name, color = Brand.Text, fontSize = 14.sp,
                        modifier = Modifier.fillMaxWidth().clickable {
                            Store.indicators = Store.indicators + IndCfg(UUID.randomUUID().toString(), spec.type, spec.d1, spec.d2, spec.d3, IND_COLORS[Store.indicators.size % IND_COLORS.size])
                            Store.save()
                        }.padding(vertical = 8.dp),
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done", color = Brand.Text) } },
    )
}
