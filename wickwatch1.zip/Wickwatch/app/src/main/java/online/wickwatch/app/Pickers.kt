package online.wickwatch.app

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner

/*
 * Pieces shared by the onboarding and the More tab, so a choice looks and works the same in both places.
 */

const val MAX_WATCH = 8
const val MAX_FAV_TOOLS = 8

val CHART_TYPE_NAMES: List<String> = listOf("Candles", "Hollow candles", "Bars", "Line", "Area", "Heikin Ashi")
val SCALE_NAMES: List<String> = listOf("Linear", "Log", "Percent")
private val MARKET_GROUPS = listOf("Forex", "Metals", "Crypto", "Stock indices", "Synthetic indices")

// ---------------------------------------------------------------------------------------------

@Composable
fun Pill(text: String, bg: Color, fg: Color = Color.White) {
    Text(
        text, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.background(bg, RoundedCornerShape(99.dp)).padding(horizontal = 9.dp, vertical = 3.dp),
    )
}

/** A small pick-one button. Selected = filled with the theme's main colour. */
@Composable
fun ChoiceChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(10.dp))
            .background(if (selected) Brand.Primary else Brand.Elevated)
            .border(1.dp, if (selected) Brand.Primary else Brand.Border, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (selected) Brand.Bg else Brand.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp, color = Brand.Text)
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Brand.Bg, checkedTrackColor = Brand.Primary,
                uncheckedThumbColor = Brand.Muted, uncheckedTrackColor = Brand.Elevated, uncheckedBorderColor = Brand.Border,
            ),
        )
    }
}

// ---- theme --------------------------------------------------------------------------------------

@Composable
fun ThemePicker() {
    val names = listOf("Black and white", "White", "Navy and teal")
    val bgs = listOf(Color(0xFF000000), Color(0xFFFFFFFF), Color(0xFF0B1220))
    val fgs = listOf(Color(0xFFFFFFFF), Color(0xFF000000), Color(0xFF14B8A6))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (i in 0..2) {
            val sel = Brand.mode == i
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                    .border(if (sel) 3.dp else 1.dp, if (sel) Brand.Primary else Brand.Border, RoundedCornerShape(12.dp))
                    .clickable { Brand.mode = i; Store.save() },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(Modifier.fillMaxWidth().height(64.dp).background(bgs[i]), contentAlignment = Alignment.Center) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp, 28.dp).background(fgs[i]))
                        Box(Modifier.size(10.dp, 18.dp).border(1.5.dp, fgs[i]))
                        Box(Modifier.size(10.dp, 34.dp).background(fgs[i]))
                    }
                }
                Text(names[i], color = Brand.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(8.dp))
            }
        }
    }
}

// ---- candles ------------------------------------------------------------------------------------

private val PREVIEW_CLOSES = listOf(40f, 52f, 47f, 61f, 56f, 70f, 63f, 57f, 66f, 82f, 75f, 90f, 84f, 78f)

/** A row of sample candles drawn with the colours that are chosen right now. */
@Composable
fun CandlePreview(modifier: Modifier = Modifier) {
    val up = Brand.Up
    val down = Brand.Down
    val hollow = Brand.HollowUp
    val bg = Brand.Bg
    Canvas(modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(12.dp)).background(bg).border(1.dp, Brand.Border, RoundedCornerShape(12.dp))) {
        val n = PREVIEW_CLOSES.size
        val lo = 25f
        val hi = 100f
        fun y(v: Float): Float = size.height - 10.dp.toPx() - (v - lo) / (hi - lo) * (size.height - 20.dp.toPx())
        val slot = size.width / n
        val bw = slot * 0.55f
        var prev = 45f
        for (i in 0 until n) {
            val c = PREVIEW_CLOSES[i]
            val o = prev
            prev = c
            val isUp = c >= o
            val col = if (isUp) up else down
            val hh = maxOf(o, c) + 5f
            val ll = minOf(o, c) - 5f
            val cx = slot * i + slot / 2f
            drawLine(col, Offset(cx, y(hh)), Offset(cx, y(ll)), 2f)
            val top = y(maxOf(o, c))
            val h = maxOf(2f, y(minOf(o, c)) - top)
            if (isUp && hollow) {
                drawRect(bg, Offset(cx - bw / 2, top), Size(bw, h))
                drawRect(col, Offset(cx - bw / 2, top), Size(bw, h), style = Stroke(width = 2f))
            } else {
                drawRect(col, Offset(cx - bw / 2, top), Size(bw, h))
            }
        }
    }
}

@Composable
fun CandlePicker() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CandlePreview()
        for (row in CANDLE_PRESETS.chunked(3)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (p in row) {
                    val sel = Brand.candleUp == p.up && Brand.candleDown == p.down && (p.up == 0L || Brand.hollowUp == p.hollow)
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                            .background(Brand.Elevated)
                            .border(if (sel) 3.dp else 1.dp, if (sel) Brand.Primary else Brand.Border, RoundedCornerShape(10.dp))
                            .clickable { Brand.candleUp = p.up; Brand.candleDown = p.down; Brand.hollowUp = p.hollow; Store.save() }
                            .padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            val u = if (p.up == 0L) Brand.Text else Color(p.up)
                            val d = if (p.down == 0L) Brand.Muted else Color(p.down)
                            if (p.hollow) Box(Modifier.size(14.dp, 22.dp).border(2.dp, u)) else Box(Modifier.size(14.dp, 22.dp).background(u))
                            Box(Modifier.size(14.dp, 22.dp).background(d))
                        }
                        Text(p.name, color = Brand.Text, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                for (k in row.size until 3) Box(Modifier.weight(1f))
            }
        }
        SwitchRow("Hollow rising candles", Brand.HollowUp) { Brand.hollowUp = it; if (Brand.candleUp == 0L) Brand.candleUp = if (Brand.dark) 0xFFFFFFFFL else 0xFF000000L; Store.save() }
        var custom by remember { mutableStateOf(false) }
        ChoiceChip(if (custom) "Hide custom colours" else "Pick your own colours", custom) { custom = !custom }
        if (custom) {
            Text("Rising candles", color = Brand.Muted, fontSize = 12.sp)
            SwatchRow(Brand.candleUp) { Brand.candleUp = it; Store.save() }
            Text("Falling candles", color = Brand.Muted, fontSize = 12.sp)
            SwatchRow(Brand.candleDown) { Brand.candleDown = it; Store.save() }
        }
    }
}

// ---- chart defaults -----------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChartDefaultsPicker() {
    var pickMarket by remember { mutableStateOf(false) }
    val market = marketByKey(Store.chartKey)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Chart type", color = Brand.Muted, fontSize = 12.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            CHART_TYPE_NAMES.forEachIndexed { i, n -> ChoiceChip(n, Store.chartType == i) { Store.chartType = i; Store.save() } }
        }
        Text("Price scale", color = Brand.Muted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SCALE_NAMES.forEachIndexed { i, n -> ChoiceChip(n, Store.scaleType == i) { Store.scaleType = i; Store.save() } }
        }
        Text("Timeframe", color = Brand.Muted, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((g, label) in TIMEFRAMES) ChoiceChip(label, Store.chartTf == g) { Store.chartTf = g; Store.save() }
        }
        Text("The chart opens with", color = Brand.Muted, fontSize = 12.sp)
        SecondaryButton(market?.name ?: "Choose a market", Modifier.fillMaxWidth()) { pickMarket = true }
        SwitchRow("Magnet: drawing points snap to open, high, low, close", Store.magnet) { Store.magnet = it; Store.save() }
    }
    if (pickMarket) MarketPicker(onPick = { Store.chartKey = it.key; Store.save(); pickMarket = false }, onDismiss = { pickMarket = false })
}

// ---- watch list ---------------------------------------------------------------------------------

/** Search and tick markets for the watch list. Changes are saved at once and applied to a running watcher. */
@Composable
fun MarketChooser(onChanged: () -> Unit = {}) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var tf by remember { mutableIntStateOf(900) }
    var open by remember { mutableStateOf(setOf<String>()) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Timeframe for the markets you add", color = Brand.Muted, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((g, label) in TIMEFRAMES) ChoiceChip(label, tf == g) { tf = g }
        }
        OutlinedTextField(
            value = q, onValueChange = { q = it }, label = { Text("Search markets") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        for (g in MARKET_GROUPS) {
            val list = MARKETS.filter { it.grp == g && (q.isBlank() || it.name.contains(q.trim(), ignoreCase = true)) }
            if (list.isEmpty()) continue
            val expanded = q.isNotBlank() || g in open
            Row(
                Modifier.fillMaxWidth().clickable { open = if (g in open) open - g else open + g }.padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(g + "  (" + list.size + ")", Modifier.weight(1f), color = Brand.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(if (expanded) "▾" else "▸", color = Brand.Muted)
            }
            if (expanded) {
                for (m in list) {
                    val on = Store.watch.any { it.key == m.key && it.tf == tf }
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            if (on) {
                                Store.watch = Store.watch.filter { !(it.key == m.key && it.tf == tf) }
                            } else if (Store.watch.size >= MAX_WATCH) {
                                Toast.makeText(ctx, "Up to $MAX_WATCH markets keeps battery and data use reasonable.", Toast.LENGTH_SHORT).show()
                                return@clickable
                            } else {
                                Store.watch = Store.watch + WatchItem(m.key, tf)
                            }
                            Store.save()
                            Watcher.refresh()
                            onChanged()
                        }.padding(vertical = 9.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(m.name, color = Brand.Text, fontSize = 14.sp)
                            Text(if (m.src == 'b') "Binance" else "Deriv", color = Brand.Muted, fontSize = 11.sp)
                        }
                        Text(if (on) "✓" else "+", color = if (on) Brand.Good else Brand.Muted, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
            }
        }
        Text(Store.watch.size.toString() + " of " + MAX_WATCH + " watch slots used.", color = Brand.Muted, fontSize = 12.sp)
    }
}

// ---- favourite drawing tools --------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FavToolsPicker() {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Tap up to $MAX_FAV_TOOLS tools. They appear in a bar on top of the chart. Selected: " + Store.favTools.size, color = Brand.Muted, fontSize = 12.sp)
        OutlinedTextField(value = q, onValueChange = { q = it }, label = { Text("Search tools") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        for (cat in Tools.CATS) {
            val list = Tools.ALL.filter { it.cat == cat && it.ready && (q.isBlank() || it.name.contains(q.trim(), ignoreCase = true)) }
            if (list.isEmpty()) continue
            Text(cat, color = Brand.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                for (t in list) {
                    val on = t.id in Store.favTools
                    ChoiceChip(t.name, on) {
                        if (on) {
                            Store.favTools = Store.favTools.filter { it != t.id }
                        } else if (Store.favTools.size >= MAX_FAV_TOOLS) {
                            Toast.makeText(ctx, "Up to $MAX_FAV_TOOLS favourites. Untick one first.", Toast.LENGTH_SHORT).show()
                            return@ChoiceChip
                        } else {
                            Store.favTools = Store.favTools + t.id
                        }
                        Store.save()
                    }
                }
            }
        }
    }
}

// ---- alerts -------------------------------------------------------------------------------------

/** 0 = quiet (notifications only), 1 = balanced (the app's defaults), 2 = loud (urgent for what matters most). */
fun applyAlertProfile(p: Int) {
    val loud = setOf(AlertKind.PRICE_ALERT, AlertKind.RIBBON_SIGNAL, AlertKind.RIBBON_STOP, AlertKind.LEVEL_BROKEN)
    val m = HashMap<String, Int>()
    for (k in AlertKind.values()) {
        m[k.name] = when (p) {
            0 -> if (k.defaultMode == 0) 0 else 1
            1 -> k.defaultMode
            else -> if (k in loud) 2 else if (k.defaultMode == 0) 0 else 1
        }
    }
    Store.modes = m
    Store.save()
}

val ALERT_PROFILES: List<Triple<String, String, Int>> = listOf(
    Triple("Quiet", "Everything is a normal notification. Nothing rings.", 0),
    Triple("Balanced", "Normal notifications, and an urgent alarm only when a stop is hit.", 1),
    Triple("Loud", "Urgent alarm for your chart alerts, new signals, stops and broken key levels.", 2),
)

/** Off / Normal / Urgent for every alert type, grouped by strategy. */
@Composable
fun AlertTypesEditor() {
    var lastStrategy = ""
    for (k in AlertKind.values()) {
        if (k.strategy != lastStrategy) {
            lastStrategy = k.strategy
            Text(k.strategy, fontWeight = FontWeight.Bold, color = Brand.Text, modifier = Modifier.padding(top = 8.dp))
        }
        PCard {
            Text(k.label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Brand.Text)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val cur = Store.modeOf(k)
                listOf("Off", "Normal", "Urgent").forEachIndexed { i, name -> ChoiceChip(name, cur == i) { Store.setMode(k, i) } }
            }
        }
    }
}

// ---- permissions --------------------------------------------------------------------------------

fun launchSettings(ctx: Context, intent: Intent) {
    try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not open that screen on this phone", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun PermRow(title: String, why: String, ok: Boolean, action: String, onAction: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Brand.Text)
            Text(why, color = Brand.Muted, fontSize = 12.sp)
        }
        if (ok) Pill("ON", Brand.Good) else SecondaryButton(action, onClick = onAction)
    }
}

/** The permissions the watcher needs, each with its state and a button that opens the right Android screen. */
@Composable
fun PermissionsPanel() {
    val ctx = LocalContext.current
    val pkg = ctx.packageName
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick += 1 }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick += 1 }
    val nm = ctx.getSystemService(NotificationManager::class.java)
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    val notifOk = tick >= 0 && (Build.VERSION.SDK_INT < 33 || ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
    val battOk = tick >= 0 && pm.isIgnoringBatteryOptimizations(pkg)
    val dndOk = tick >= 0 && nm.isNotificationPolicyAccessGranted
    val fullOk = tick >= 0 && (Build.VERSION.SDK_INT < 34 || nm.canUseFullScreenIntent())
    PCard {
        PermRow("Notifications", "Needed to show any alert.", notifOk, "Allow") {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        PermRow("Battery: unrestricted", "Stops Android from putting the watcher to sleep.", battOk, "Allow") {
            launchSettings(ctx, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$pkg")))
        }
        PermRow("Override Do Not Disturb", "Lets urgent alerts ring in silent mode.", dndOk, "Allow") {
            launchSettings(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        PermRow("Full-screen alerts", "Lets urgent alerts light up the lock screen.", fullOk, "Allow") {
            if (Build.VERSION.SDK_INT >= 34) launchSettings(ctx, Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$pkg")))
        }
        Text(
            "Also set on your phone: open App info, then Battery, and choose Unrestricted. On Tecno, Infinix and Itel phones turn on Autostart and lock the app in the recent apps list. Without these, the phone may close the watcher.",
            color = Brand.Muted, fontSize = 12.sp,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SecondaryButton("App info", Modifier.weight(1f)) { launchSettings(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) }
            SecondaryButton("Urgent channel", Modifier.weight(1f)) {
                Alerts.ensureChannels(ctx)
                launchSettings(ctx, Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg).putExtra(Settings.EXTRA_CHANNEL_ID, Alerts.CH_URGENT))
            }
        }
    }
}
