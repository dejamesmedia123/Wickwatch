package online.wickwatch.app

import kotlin.math.abs
import kotlin.math.max

/*
 * Key levels: price levels that the market has turned at several times.
 * Written for Wickwatch: swing highs and lows are found, swings that sit at nearly the same price are grouped, and a group
 * with enough swings becomes a level. It is a map of where price reacted before, not a prediction.
 */

class Level(val price: Double, val touches: Int, val first: Int, val last: Int)

class LevelsResult(val levels: List<Level>, val atr: Double, val px: Double, val n: Int)

object Levels {
    /** [cs] must hold closed candles only. */
    fun analyze(cs: List<Candle>, span: Int = 5, minTouches: Int = 3, lookback: Int = 400): LevelsResult? {
        val n = cs.size
        if (n < 60) return null
        val atrArr = Ind.atr(cs, 14)
        val atr = atrArr[n - 1]
        if (atr.isNaN() || atr <= 0) return null
        val px = cs[n - 1].c
        val start = max(span, n - lookback)

        // swing points: a bar whose high (or low) is the extreme of [span] bars on each side
        val pts = ArrayList<Pair<Int, Double>>()
        for (i in start until n - span) {
            var isHigh = true
            var isLow = true
            for (j in i - span..i + span) {
                if (cs[j].h > cs[i].h) isHigh = false
                if (cs[j].l < cs[i].l) isLow = false
            }
            if (isHigh) pts.add(Pair(i, cs[i].h))
            if (isLow) pts.add(Pair(i, cs[i].l))
        }
        if (pts.size < minTouches) return LevelsResult(emptyList(), atr, px, n)

        // group swings whose prices are within 0.4 ATR of each other
        pts.sortBy { it.second }
        val tol = 0.4 * atr
        val groups = ArrayList<MutableList<Pair<Int, Double>>>()
        var cur = ArrayList<Pair<Int, Double>>()
        for (p in pts) {
            if (cur.isNotEmpty() && p.second - cur[cur.size - 1].second > tol) {
                groups.add(cur)
                cur = ArrayList()
            }
            cur.add(p)
        }
        if (cur.isNotEmpty()) groups.add(cur)

        val levels = ArrayList<Level>()
        for (g in groups) {
            if (g.size < minTouches) continue
            val price = g.sumOf { it.second } / g.size
            if (abs(price - px) > 10 * atr) continue
            levels.add(Level(price, g.size, g.minOf { it.first }, g.maxOf { it.first }))
        }
        levels.sortWith(compareByDescending<Level> { it.touches }.thenBy { abs(it.price - px) })
        return LevelsResult(levels.take(8), atr, px, n)
    }
}
