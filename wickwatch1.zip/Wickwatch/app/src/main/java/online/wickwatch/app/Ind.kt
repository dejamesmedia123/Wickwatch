package online.wickwatch.app

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sqrt

/** Indicator maths shared by the strategies. Values that cannot be computed yet are NaN. */
object Ind {

    /** Average True Range, Wilder smoothing seeded with a simple average (the same as TradingView's ta.atr). */
    fun atr(c: List<Candle>, len: Int): DoubleArray {
        val n = c.size
        val out = DoubleArray(n) { Double.NaN }
        if (n < len || len < 1) return out
        val tr = DoubleArray(n)
        for (i in 0 until n) {
            tr[i] = if (i == 0) c[i].h - c[i].l else max(c[i].h - c[i].l, max(abs(c[i].h - c[i - 1].c), abs(c[i].l - c[i - 1].c)))
        }
        var sum = 0.0
        for (i in 0 until len) sum += tr[i]
        var prev = sum / len
        out[len - 1] = prev
        for (i in len until n) {
            prev = (prev * (len - 1) + tr[i]) / len
            out[i] = prev
        }
        return out
    }

    /** Arnaud Legoux moving average (the same weights as TradingView's ta.alma). */
    fun alma(src: DoubleArray, len: Int, offset: Double, sigma: Double): DoubleArray {
        val n = src.size
        val out = DoubleArray(n) { Double.NaN }
        if (n < len || len < 1) return out
        val m = floor(offset * (len - 1))
        val s = len / sigma
        val w = DoubleArray(len) { k -> exp(-((k - m) * (k - m)) / (2.0 * s * s)) }
        var norm = 0.0
        for (x in w) norm += x
        for (i in len - 1 until n) {
            var sum = 0.0
            for (k in 0 until len) sum += src[i - (len - 1) + k] * w[k]
            out[i] = sum / norm
        }
        return out
    }

    /** Standard deviation over a window (population form, like TradingView's ta.stdev). */
    fun stdev(src: DoubleArray, len: Int): DoubleArray {
        val n = src.size
        val out = DoubleArray(n) { Double.NaN }
        if (n < len || len < 1) return out
        for (i in len - 1 until n) {
            var mean = 0.0
            for (k in 0 until len) mean += src[i - k]
            mean /= len
            var v = 0.0
            for (k in 0 until len) {
                val d = src[i - k] - mean
                v += d * d
            }
            out[i] = sqrt(v / len)
        }
        return out
    }

    /** Simple moving average. Leading values that cannot be computed are NaN. */
    fun sma(src: DoubleArray, n: Int): DoubleArray {
        val len = src.size
        val out = DoubleArray(len) { Double.NaN }
        if (n < 1) return out
        for (i in n - 1 until len) {
            var sum = 0.0
            var ok = true
            for (k in 0 until n) {
                val v = src[i - k]
                if (v.isNaN()) { ok = false; break }
                sum += v
            }
            if (ok) out[i] = sum / n
        }
        return out
    }

    /** Exponential moving average, seeded with a simple average of the first [n] usable values. */
    fun ema(src: DoubleArray, n: Int): DoubleArray {
        val len = src.size
        val out = DoubleArray(len) { Double.NaN }
        if (n < 1) return out
        var f = 0
        while (f < len && src[f].isNaN()) f += 1
        if (f + n > len) return out
        var sum = 0.0
        for (k in 0 until n) sum += src[f + k]
        var prev = sum / n
        out[f + n - 1] = prev
        val a = 2.0 / (n + 1)
        for (i in f + n until len) {
            prev = if (src[i].isNaN()) prev else prev + a * (src[i] - prev)
            out[i] = prev
        }
        return out
    }

    /** Relative Strength Index with Wilder smoothing. */
    fun rsi(close: DoubleArray, n: Int): DoubleArray {
        val len = close.size
        val out = DoubleArray(len) { Double.NaN }
        if (n < 1 || len <= n) return out
        var gain = 0.0
        var loss = 0.0
        for (i in 1..n) {
            val d = close[i] - close[i - 1]
            if (d >= 0) gain += d else loss -= d
        }
        gain /= n
        loss /= n
        out[n] = if (loss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + gain / loss)
        for (i in n + 1 until len) {
            val d = close[i] - close[i - 1]
            gain = (gain * (n - 1) + (if (d > 0) d else 0.0)) / n
            loss = (loss * (n - 1) + (if (d < 0) -d else 0.0)) / n
            out[i] = if (loss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + gain / loss)
        }
        return out
    }

    /** Stochastic: raw %K over [n] bars. */
    fun stochRaw(c: List<Candle>, n: Int): DoubleArray {
        val len = c.size
        val out = DoubleArray(len) { Double.NaN }
        for (i in n - 1 until len) {
            var hi = -Double.MAX_VALUE
            var lo = Double.MAX_VALUE
            for (k in 0 until n) {
                hi = max(hi, c[i - k].h)
                lo = kotlin.math.min(lo, c[i - k].l)
            }
            out[i] = if (hi > lo) 100.0 * (c[i].c - lo) / (hi - lo) else 50.0
        }
        return out
    }

    /** Supertrend. Returns the line while the trend is up (index 0) and while it is down (index 1); the other is NaN. */
    fun supertrend(c: List<Candle>, atrLen: Int, mult: Double): Array<DoubleArray> {
        val n = c.size
        val up = DoubleArray(n) { Double.NaN }
        val dn = DoubleArray(n) { Double.NaN }
        val atr = atr(c, atrLen)
        var fub = Double.NaN
        var flb = Double.NaN
        var dir = 1
        for (i in 0 until n) {
            if (atr[i].isNaN()) continue
            val hl2 = (c[i].h + c[i].l) / 2.0
            val ub = hl2 + mult * atr[i]
            val lb = hl2 - mult * atr[i]
            if (fub.isNaN()) {
                fub = ub
                flb = lb
            } else {
                val pc = c[i - 1].c
                fub = if (ub < fub || pc > fub) ub else fub
                flb = if (lb > flb || pc < flb) lb else flb
                if (dir == 1 && c[i].c < flb) dir = -1
                else if (dir == -1 && c[i].c > fub) dir = 1
            }
            if (dir == 1) up[i] = flb else dn[i] = fub
        }
        return arrayOf(up, dn)
    }

    /** Volume weighted average price, restarting every UTC day. All NaN when the market has no volume. */
    fun vwap(c: List<Candle>): DoubleArray {
        val n = c.size
        val out = DoubleArray(n) { Double.NaN }
        var pv = 0.0
        var vv = 0.0
        var day = -1L
        for (i in 0 until n) {
            val d = c[i].t / 86400L
            if (d != day) {
                day = d
                pv = 0.0
                vv = 0.0
            }
            val tp = (c[i].h + c[i].l + c[i].c) / 3.0
            pv += tp * c[i].v
            vv += c[i].v
            if (vv > 0) out[i] = pv / vv
        }
        return out
    }
}
