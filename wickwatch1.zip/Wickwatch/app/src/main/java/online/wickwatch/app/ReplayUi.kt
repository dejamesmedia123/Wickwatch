package online.wickwatch.app

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
private fun RPill(text: String, hot: Boolean = false, onClick: () -> Unit) {
    Text(
        text, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (hot) Brand.Alert else Brand.Text,
        modifier = Modifier.clip(RoundedCornerShape(6.dp)).border(1.dp, if (hot) Brand.Alert else Brand.Border, RoundedCornerShape(6.dp))
            .clickable { onClick() }.padding(horizontal = 9.dp, vertical = 5.dp),
    )
}

/**
 * Bar replay controls. The chart shows the market only up to the replay candle (ribbon, levels and setups are worked out from that part only),
 * so you can watch it unfold one candle at a time. Start it from the Analysis hub; it begins in the middle of the screen.
 */
@Composable
fun ReplayBar(model: ChartModel) {
    var playing by remember { mutableStateOf(false) }
    var speed by remember { mutableIntStateOf(1) }            // candles per second: 1, 2, 5, 10
    LaunchedEffect(playing, speed, model.replayT) {
        if (!playing) return@LaunchedEffect
        delay((1000L / speed))
        if (!model.replayStep(1)) playing = false
    }
    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("REPLAY", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Alert)
        RPill("-1") { playing = false; model.replayStep(-1) }
        RPill(if (playing) "Pause" else "Play", hot = playing) { playing = !playing }
        RPill("+1") { playing = false; model.replayStep(1) }
        RPill(speed.toString() + "x") { speed = when (speed) { 1 -> 2; 2 -> 5; 5 -> 10; else -> 1 } }
        RPill("Exit") { playing = false; model.stopReplay() }
    }
}
