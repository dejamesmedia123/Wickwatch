package online.wickwatch.app

import kotlin.math.max

/*
 * Trend engine: trades WITH the trend, tight stop, big fixed target.
 *
 *   Downtrend (sell): the EMA is falling and price is below it (or only a pullback above it).
 *   Price makes a LOWER HIGH (the pullback). The lowest swing low before that pullback is the trigger.
 *   Entry: a candle closes below the trigger (the trend continues). Stop: just above the lower high. Target: minRR times the risk.
 *   The stop must be tight: at most maxRiskAtr ATR from the entry. Uptrend (buy) is the same code on mirrored prices.
 *   Closed candles only. If one candle touches both the stop and the target, the stop counts first.
 */
private class TCand(val k: Int, val trig: Double, val stopBase: Double, val born: Int) {
    var dead = false
}

object TrendEngine {
    fun scan(cs: List<Candle>, p: SetupParams = SetupParams()): SetupScan {
        val n = cs.size
        val atr = SweepEngine.atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 80) return SetupScan(emptyList(), n, last)
        val all = ArrayList<Setup>()
        if (p.dirMask and 1 != 0) all.addAll(scanDir(cs, atr, p, true))
        if (p.dirMask and 2 != 0) all.addAll(scanDir(cs, atr, p, false))
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    private fun scanDir(cs: List<Candle>, a: DoubleArray, p: SetupParams, short: Boolean): List<Setup> {
        val n = cs.size
        val o = DoubleArray(n) { if (short) cs[it].o else -cs[it].o }
        val h = DoubleArray(n) { if (short) cs[it].h else -cs[it].l }
        val l = DoubleArray(n) { if (short) cs[it].l else -cs[it].h }
        val c = DoubleArray(n) { if (short) cs[it].c else -cs[it].c }
        fun px(x: Double): Double = if (short) x else -x

        val ema = DoubleArray(n)
        val kk = 2.0 / (p.trendLen + 1)
        ema[0] = c[0]
        for (q in 1 until n) ema[q] = ema[q - 1] + kk * (c[q] - ema[q - 1])
        fun trendOk(i: Int): Boolean = i >= p.trendSlopeBars && ema[i] < ema[i - p.trendSlopeBars] && c[i] < ema[i] + p.trendTolAtr * a[i]

        val span = p.pivotSpan
        val pivH = ArrayList<Int>()
        val pivL = ArrayList<Int>()
        val cands = ArrayList<TCand>()
        val out = ArrayList<Setup>()

        fun enter(cd: TCand, i: Int) {
            val entry = c[i]
            val stop = cd.stopBase + p.sweepStopBufAtr * a[i]
            val risk = stop - entry
            if (risk < 0.2 * a[i] || risk > p.maxRiskAtr * a[i]) return
            val target = entry - p.minRR * risk
            val s = Setup(if (short) 1 else -1, cd.k, cs[cd.k].t)
            s.kind = "trend"
            s.valid = true
            s.proximal = px(cd.trig)
            s.distal = px(cd.stopBase)
            s.entry = px(entry)
            s.stop = px(stop)
            s.target = px(target)
            s.risk = risk
            s.rr = p.minRR
            s.lockIdx = i
            s.lockT = cs[i].t
            s.fillIdx = i
            s.fillT = cs[i].t
            s.touchIdx = cd.k
            s.state = ST_ACTIVE
            var k = i + 1
            while (k < n) {
                if (h[k] >= stop) { s.state = ST_LOSS; s.endIdx = k; s.endT = cs[k].t; s.result = -1.0; break }
                if (l[k] <= target) { s.state = ST_WIN; s.endIdx = k; s.endT = cs[k].t; s.result = s.rr; break }
                if (k - i > p.maxActiveBars) { s.state = ST_FLAT; s.endIdx = k; s.endT = cs[k].t; s.result = (entry - c[k]) / risk; break }
                k += 1
            }
            out.add(s)
        }

        for (i in 0 until n) {
            for (cd in cands) {
                if (cd.dead) continue
                if (i - cd.born > p.waitBars * 2) { cd.dead = true; continue }
                if (h[i] > cd.stopBase) { cd.dead = true; continue }          // the pullback grew into a higher high
                if (c[i] < cd.trig) {
                    cd.dead = true
                    if (trendOk(i)) enter(cd, i)
                }
            }
            cands.removeAll { it.dead }

            val j = i - span
            if (j - span >= 0) {
                var isH = true
                var isL = true
                for (q in j - span until j) { if (h[q] >= h[j]) isH = false; if (l[q] <= l[j]) isL = false }
                for (q in j + 1..j + span) { if (h[q] > h[j]) isH = false; if (l[q] < l[j]) isL = false }
                if (isL) pivL.add(j)
                if (isH) {
                    if (pivH.isNotEmpty()) {
                        val prev = pivH[pivH.size - 1]
                        if (h[j] < h[prev]) {                                   // a lower high: the pullback
                            var low = -1
                            for (q in pivL) if (q > prev && q < j && (low < 0 || l[q] < l[low])) low = q
                            if (low >= 0) {
                                var done = false
                                for (q in j..i) if (c[q] < l[low]) done = true  // already broke before we could know
                                if (!done) cands.add(TCand(j, l[low], h[j], i))
                            }
                        }
                    }
                    pivH.add(j)
                }
            }
        }
        return out
    }
}
