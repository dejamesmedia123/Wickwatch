package online.wickwatch.app

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object Net {
    val http: OkHttpClient = OkHttpClient.Builder().callTimeout(15, TimeUnit.SECONDS).build()
    val ws: OkHttpClient = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).build()
}

const val DERIV_URL = "wss://api.derivws.com/trading/v1/options/ws/public"
val BIN_REST: List<String> = listOf("https://api.binance.com", "https://data-api.binance.vision")   // the second one is Binance's public market-data mirror
val BIN_WS: List<String> = listOf("wss://stream.binance.com:9443", "wss://data-stream.binance.vision")
val BIN_INT: Map<Int, String> = mapOf(60 to "1m", 300 to "5m", 900 to "15m", 1800 to "30m", 3600 to "1h", 14400 to "4h", 86400 to "1d")

/**
 * History plus live updates for one market and timeframe. Candles are oldest first and the LAST one is still forming.
 * The same method many price sites use: Deriv history by ticks_history and live by tick subscription (rolled into candles),
 * Binance history by klines and live by the kline stream. It reconnects by itself.
 */
class SeriesFeed(
    private val market: Market,
    private val tf: Int,
    private val scope: CoroutineScope,
    private val onUpdate: (candles: List<Candle>, newCandle: Boolean, price: Double) -> Unit,
    private val onStatus: (String) -> Unit = {},
) {
    private val lock = Any()
    private val candles = ArrayList<Candle>()
    private var job: Job? = null
    private var socket: WebSocket? = null
    @Volatile private var active = false
    private var hostIdx = 0

    fun start() {
        if (active) return
        active = true
        job = scope.launch(Dispatchers.IO) { loop() }
    }

    fun stop() {
        active = false
        job?.cancel()
        socket?.cancel()
        socket = null
    }

    private suspend fun loop() {
        var attempt = 0
        while (active) {
            try {
                val hist = if (market.src == 'b') binanceHistory() else derivHistory()
                synchronized(lock) {
                    candles.clear()
                    candles.addAll(hist)
                }
                onStatus("live")
                publish(false)
                attempt = 0
                live()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onStatus((e.message ?: "connection problem") + " - retrying")
            }
            if (!active) break
            attempt += 1
            hostIdx += 1
            delay(minOf(30_000L, 1000L * (1L shl minOf(attempt, 5))))
        }
    }

    private fun binanceHistory(): List<Candle> {
        var last: Exception = Exception("history failed")
        for (k in BIN_REST.indices) {
            val host = BIN_REST[(k + hostIdx) % BIN_REST.size]
            try {
                val url = host + "/api/v3/klines?symbol=" + market.id + "&interval=" + BIN_INT[tf] + "&limit=500"
                Net.http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    if (!r.isSuccessful) throw Exception("HTTP " + r.code)
                    val arr = JSONArray(r.body!!.string())
                    val out = ArrayList<Candle>()
                    for (i in 0 until arr.length()) {
                        val x = arr.getJSONArray(i)
                        out.add(Candle(x.getLong(0) / 1000L, x.getString(1).toDouble(), x.getString(2).toDouble(), x.getString(3).toDouble(), x.getString(4).toDouble(), x.getString(5).toDouble()))
                    }
                    return out
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                last = e
            }
        }
        throw last
    }

    // History uses its own short-lived socket, so a history problem can never break the live stream.
    private suspend fun derivHistory(): List<Candle> {
        val result = withTimeoutOrNull(12_000L) {
            suspendCancellableCoroutine<List<Candle>> { cont ->
                val ws = Net.ws.newWebSocket(Request.Builder().url(DERIV_URL).build(), object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        webSocket.send("{\"ticks_history\":\"" + market.id + "\",\"adjust_start_time\":1,\"count\":500,\"end\":\"latest\",\"style\":\"candles\",\"granularity\":" + tf + "}")
                    }

                    override fun onMessage(webSocket: WebSocket, text: String) {
                        try {
                            val d = JSONObject(text)
                            if (d.has("error")) {
                                if (cont.isActive) cont.resumeWithException(Exception("Deriv: " + d.getJSONObject("error").optString("message")))
                                webSocket.close(1000, null)
                                return
                            }
                            val arr = d.optJSONArray("candles") ?: return
                            val out = ArrayList<Candle>()
                            for (i in 0 until arr.length()) {
                                val c = arr.getJSONObject(i)
                                out.add(Candle(c.getLong("epoch"), c.optString("open").toDouble(), c.optString("high").toDouble(), c.optString("low").toDouble(), c.optString("close").toDouble()))
                            }
                            if (cont.isActive) cont.resume(out)
                            webSocket.close(1000, null)
                        } catch (e: Exception) {
                            if (cont.isActive) cont.resumeWithException(e)
                        }
                    }

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        if (cont.isActive) cont.resumeWithException(Exception("could not reach Deriv"))
                    }
                })
                cont.invokeOnCancellation { ws.cancel() }
            }
        }
        return result ?: throw Exception("no history reply from Deriv")
    }

    private suspend fun live() = suspendCancellableCoroutine<Unit> { cont ->
        val url = if (market.src == 'b') BIN_WS[hostIdx % BIN_WS.size] + "/ws/" + market.id.lowercase() + "@kline_" + BIN_INT[tf] else DERIV_URL
        val ws = Net.ws.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (market.src == 'd') webSocket.send("{\"ticks\":\"" + market.id + "\",\"subscribe\":1}")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    handle(text)
                } catch (e: Exception) {
                    // ignore one bad message
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (cont.isActive) cont.resume(Unit)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (cont.isActive) cont.resume(Unit)
            }
        })
        socket = ws
        cont.invokeOnCancellation { ws.cancel() }
    }

    private fun handle(text: String) {
        val d = JSONObject(text)
        var isNew = false
        if (market.src == 'b') {
            val k = d.optJSONObject("k") ?: return
            val t = k.getLong("t") / 1000L
            val cd = Candle(t, k.getString("o").toDouble(), k.getString("h").toDouble(), k.getString("l").toDouble(), k.getString("c").toDouble(), k.optString("v", "0").toDouble())
            synchronized(lock) {
                val last = candles.lastOrNull()
                if (last != null && last.t == t) {
                    candles[candles.size - 1] = cd
                } else if (last == null || t > last.t) {
                    candles.add(cd)
                    isNew = true
                }
                Unit
            }
        } else {
            val tk = d.optJSONObject("tick") ?: return
            val price = tk.optString("quote").toDouble()
            val epoch = tk.getLong("epoch")
            val b = epoch / tf * tf
            synchronized(lock) {
                val last = candles.lastOrNull() ?: return
                if (b < last.t) return
                if (b == last.t) {
                    candles[candles.size - 1] = Candle(last.t, last.o, maxOf(last.h, price), minOf(last.l, price), price)
                } else {
                    candles.add(Candle(b, price, price, price, price))
                    isNew = true
                }
                Unit
            }
        }
        publish(isNew)
    }

    private fun publish(isNew: Boolean) {
        val copy: List<Candle> = synchronized(lock) {
            while (candles.size > 1000) candles.removeAt(0)
            ArrayList(candles)
        }
        if (copy.isNotEmpty()) onUpdate(copy, isNew, copy[copy.size - 1].c)
    }
}
