package online.wickwatch.app

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object Net {
    val http: OkHttpClient = OkHttpClient.Builder().callTimeout(15, TimeUnit.SECONDS).build()
    val ws: OkHttpClient = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).build()
}

const val DERIV_URL = "wss://api.derivws.com/trading/v1/options/ws/public"
val BIN_REST: List<String> = listOf("https://api.binance.com", "https://data-api.binance.vision")   // the second one is Binance's public market-data mirror
val BIN_WS: List<String> = listOf("wss://stream.binance.com:9443", "wss://data-stream.binance.vision")
val BIN_INT: Map<Int, String> = mapOf(60 to "1m", 300 to "5m", 900 to "15m", 1800 to "30m", 3600 to "1h", 14400 to "4h", 86400 to "1d")

/**
 * History plus live updates for one market and timeframe. Candles are oldest first and the LAST one is still forming.
 * The same method many price sites use: Deriv history by ticks_history and live by tick subscription (rolled into candles),
 * Binance history by klines and live by the kline stream. It reconnects by itself.
 */
class SeriesFeed(
    private val market: Market,
    private val tf: Int,
    private val scope: CoroutineScope,
    private val onUpdate: (candles: List<Candle>, newCandle: Boolean, price: Double) -> Unit,
    private val onStatus: (String) -> Unit = {},
    private val cache: Boolean = false,          // keep the candles on the phone and show them offline
    private val maxCandles: Int = 1000,
) {
    private val lock = Any()
    private val candles = ArrayList<Candle>()
    private var job: Job? = null
    private var socket: WebSocket? = null
    @Volatile private var active = false
    private var hostIdx = 0
    private var lastSave = 0L

    fun start() {
        if (active) return
        active = true
        job = scope.launch(Dispatchers.IO) { loop() }
    }

    fun stop() {
        active = false
        job?.cancel()
        socket?.cancel()
        socket = null
        if (cache) {
            val copy = synchronized(lock) { ArrayList(candles) }
            if (copy.isNotEmpty()) Thread { CandleCache.save(market, tf, copy) }.start()
        }
    }

    private suspend fun loop() {
        var attempt = 0
        if (cache) {
            // show what was saved straight away, then catch up
            val saved = CandleCache.load(market, tf)
            if (saved.isNotEmpty()) {
                synchronized(lock) {
                    candles.clear()
                    candles.addAll(saved)
                }
                onStatus("connecting...")
                publish(false)
            }
        }
        while (active) {
            try {
                val have = synchronized(lock) { candles.lastOrNull()?.t }
                val hist = if (market.src == 'b') binanceHistory(have) else derivHistory(have)
                synchronized(lock) { mergeInto(hist) }
                onStatus("live")
                publish(false)
                attempt = 0
                live()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val have = synchronized(lock) { candles.isNotEmpty() }
                onStatus(if (have) "offline - showing saved candles" else (e.message ?: "connection problem") + " - retrying")
            }
            if (!active) break
            attempt += 1
            hostIdx += 1
            delay(minOf(30_000L, 1000L * (1L shl minOf(attempt, 5))))
        }
    }

    /** Adds fetched candles to the ones already held (saved ones, or from before a reconnect). Call inside the lock. */
    private fun mergeInto(hist: List<Candle>) {
        if (hist.isEmpty()) return
        val map = java.util.TreeMap<Long, Candle>()
        for (c in candles) map[c.t] = c
        for (c in hist) map[c.t] = c
        candles.clear()
        candles.addAll(map.values)
    }

    /** True when the newest held candle is so old that the normal history request would leave a gap. */
    private fun gapTooBig(from: Long?): Boolean = from != null && System.currentTimeMillis() / 1000L - from > 400L * tf

    private fun binanceHistory(from: Long?): List<Candle> {
        if (!gapTooBig(from)) return binanceKlines(null)
        // the phone was offline for a while: walk forward from the last held candle
        val out = ArrayList<Candle>()
        var start = from!!
        var pages = 0
        while (pages < 6 && active) {
            val page = binanceKlines(start)
            if (page.isEmpty()) break
            out.addAll(page)
            pages += 1
            val lastT = page[page.size - 1].t
            if (page.size < 1000 || lastT <= start) break
            start = lastT + tf
        }
        return out
    }

    private fun binanceKlines(start: Long?): List<Candle> {
        var last: Exception = Exception("history failed")
        for (k in BIN_REST.indices) {
            val host = BIN_REST[(k + hostIdx) % BIN_REST.size]
            try {
                val url = host + "/api/v3/klines?symbol=" + market.id + "&interval=" + BIN_INT[tf] + (if (start != null) "&startTime=" + (start * 1000L) + "&limit=1000" else "&limit=500")
                Net.http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    if (!r.isSuccessful) throw Exception("HTTP " + r.code)
                    val arr = JSONArray(r.body!!.string())
                    val out = ArrayList<Candle>()
                    for (i in 0 until arr.length()) {
                        val x = arr.getJSONArray(i)
                        out.add(Candle(x.getLong(0) / 1000L, x.getString(1).toDouble(), x.getString(2).toDouble(), x.getString(3).toDouble(), x.getString(4).toDouble(), x.getString(5).toDouble()))
                    }
                    return out
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                last = e
            }
        }
        throw last
    }

    // History uses its own short-lived socket, so a history problem can never break the live stream.
    private suspend fun derivHistory(from: Long?): List<Candle> {
        val gap = gapTooBig(from)
        val result = withTimeoutOrNull(12_000L) {
            suspendCancellableCoroutine<List<Candle>> { cont ->
                val ws = Net.ws.newWebSocket(Request.Builder().url(DERIV_URL).build(), object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        webSocket.send(
                            if (gap) "{\"ticks_history\":\"" + market.id + "\",\"adjust_start_time\":1,\"count\":5000,\"start\":" + from + ",\"end\":\"latest\",\"style\":\"candles\",\"granularity\":" + tf + "}"
                            else "{\"ticks_history\":\"" + market.id + "\",\"adjust_start_time\":1,\"count\":500,\"end\":\"latest\",\"style\":\"candles\",\"granularity\":" + tf + "}",
                        )
                    }

                    override fun onMessage(webSocket: WebSocket, text: String) {
                        try {
                            val d = JSONObject(text)
                            if (d.has("error")) {
                                if (cont.isActive) cont.resumeWithException(Exception("Deriv: " + d.getJSONObject("error").optString("message")))
                                webSocket.close(1000, null)
                                return
                            }
                            val arr = d.optJSONArray("candles") ?: return
                            val out = ArrayList<Candle>()
                            for (i in 0 until arr.length()) {
                                val c = arr.getJSONObject(i)
                                out.add(Candle(c.getLong("epoch"), c.optString("open").toDouble(), c.optString("high").toDouble(), c.optString("low").toDouble(), c.optString("close").toDouble()))
                            }
                            if (cont.isActive) cont.resume(out)
                            webSocket.close(1000, null)
                        } catch (e: Exception) {
                            if (cont.isActive) cont.resumeWithException(e)
                        }
                    }

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        if (cont.isActive) cont.resumeWithException(Exception("could not reach Deriv"))
                    }
                })
                cont.invokeOnCancellation { ws.cancel() }
            }
        }
        return result ?: throw Exception("no history reply from Deriv")
    }

    private suspend fun live() = suspendCancellableCoroutine<Unit> { cont ->
        val url = if (market.src == 'b') BIN_WS[hostIdx % BIN_WS.size] + "/ws/" + market.id.lowercase() + "@kline_" + BIN_INT[tf] else DERIV_URL
        val ws = Net.ws.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (market.src == 'd') webSocket.send("{\"ticks\":\"" + market.id + "\",\"subscribe\":1}")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    handle(text)
                } catch (e: Exception) {
                    // ignore one bad message
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (cont.isActive) cont.resume(Unit)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (cont.isActive) cont.resume(Unit)
            }
        })
        socket = ws
        cont.invokeOnCancellation { ws.cancel() }
    }

    private fun handle(text: String) {
        val d = JSONObject(text)
        var isNew = false
        if (market.src == 'b') {
            val k = d.optJSONObject("k") ?: return
            val t = k.getLong("t") / 1000L
            val cd = Candle(t, k.getString("o").toDouble(), k.getString("h").toDouble(), k.getString("l").toDouble(), k.getString("c").toDouble(), k.optString("v", "0").toDouble())
            synchronized(lock) {
                val last = candles.lastOrNull()
                if (last != null && last.t == t) {
                    candles[candles.size - 1] = cd
                } else if (last == null || t > last.t) {
                    candles.add(cd)
                    isNew = true
                }
                Unit
            }
        } else {
            val tk = d.optJSONObject("tick") ?: return
            val price = tk.optString("quote").toDouble()
            val epoch = tk.getLong("epoch")
            val b = epoch / tf * tf
            synchronized(lock) {
                val last = candles.lastOrNull() ?: return
                if (b < last.t) return
                if (b == last.t) {
                    candles[candles.size - 1] = Candle(last.t, last.o, maxOf(last.h, price), minOf(last.l, price), price)
                } else {
                    candles.add(Candle(b, price, price, price, price))
                    isNew = true
                }
                Unit
            }
        }
        publish(isNew)
    }

    /** Oldest candle held (seconds), or null when empty. */
    fun oldestT(): Long? = synchronized(lock) { candles.firstOrNull()?.t }

    /** Adds older candles (fetched by [Backfill]) in front of the ones held, saves them and publishes. */
    fun addOlder(older: List<Candle>) {
        if (older.isEmpty()) return
        synchronized(lock) { mergeInto(older) }
        lastSave = 0L
        publish(false)
    }

    private fun publish(isNew: Boolean) {
        val copy: List<Candle> = synchronized(lock) {
            while (candles.size > maxCandles) candles.removeAt(0)
            ArrayList(candles)
        }
        if (cache && copy.isNotEmpty()) {
            val now = System.currentTimeMillis()
            if (isNew || now - lastSave > 30_000L) {
                lastSave = now
                CandleCache.save(market, tf, copy)
            }
        }
        if (copy.isNotEmpty()) onUpdate(copy, isNew, copy[copy.size - 1].c)
    }
}


/** Fetches candles OLDER than what is held, so the setup dashboard can reach enough finished setups. Blocking: call from a thread. */
object Backfill {
    private fun olderBinance(market: Market, tf: Int, endSec: Long): List<Candle> {
        for (host in BIN_REST) {
            try {
                val url = host + "/api/v3/klines?symbol=" + market.id + "&interval=" + BIN_INT[tf] + "&endTime=" + (endSec * 1000L) + "&limit=1000"
                Net.http.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    if (!r.isSuccessful) throw Exception("HTTP " + r.code)
                    val arr = JSONArray(r.body!!.string())
                    val out = ArrayList<Candle>()
                    for (i in 0 until arr.length()) {
                        val x = arr.getJSONArray(i)
                        out.add(Candle(x.getLong(0) / 1000L, x.getString(1).toDouble(), x.getString(2).toDouble(), x.getString(3).toDouble(), x.getString(4).toDouble(), x.getString(5).toDouble()))
                    }
                    return out
                }
            } catch (e: Exception) {
                // try the next host
            }
        }
        return emptyList()
    }

    private fun olderDeriv(market: Market, tf: Int, endSec: Long): List<Candle> {
        val latch = java.util.concurrent.CountDownLatch(1)
        val out = ArrayList<Candle>()
        val ws = Net.ws.newWebSocket(Request.Builder().url(DERIV_URL).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send("{\"ticks_history\":\"" + market.id + "\",\"adjust_start_time\":1,\"count\":5000,\"end\":\"" + endSec + "\",\"style\":\"candles\",\"granularity\":" + tf + "}")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val arr = JSONObject(text).optJSONArray("candles")
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val c = arr.getJSONObject(i)
                            out.add(Candle(c.getLong("epoch"), c.optString("open").toDouble(), c.optString("high").toDouble(), c.optString("low").toDouble(), c.optString("close").toDouble()))
                        }
                    }
                } catch (e: Exception) {
                    // an empty answer ends the paging
                }
                latch.countDown()
                webSocket.close(1000, null)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                latch.countDown()
            }
        })
        latch.await(12, TimeUnit.SECONDS)
        ws.cancel()
        return out
    }

    /** Pages backwards from [oldest] until about [want] older candles are collected (or the market has no more). */
    fun older(market: Market, tf: Int, oldest: Long, want: Int): List<Candle> {
        val got = java.util.TreeMap<Long, Candle>()
        var end = oldest - 1
        var pages = 0
        while (got.size < want && pages < 15) {
            val page = if (market.src == 'b') olderBinance(market, tf, end) else olderDeriv(market, tf, end)
            if (page.isEmpty()) break
            for (c in page) got[c.t] = c
            val first = page.minOf { it.t }
            if (first >= end) break
            end = first - 1
            pages += 1
        }
        return ArrayList(got.values)
    }
}
