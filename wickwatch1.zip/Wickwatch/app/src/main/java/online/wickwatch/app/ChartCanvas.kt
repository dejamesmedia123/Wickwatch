package online.wickwatch.app

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Heikin Ashi candles made from normal candles. */
fun heikin(cs: List<Candle>): List<Candle> {
    val out = ArrayList<Candle>(cs.size)
    var pO = 0.0
    var pC = 0.0
    for (i in cs.indices) {
        val c = cs[i]
        val hc = (c.o + c.h + c.l + c.c) / 4.0
        val ho = if (i == 0) (c.o + c.c) / 2.0 else (pO + pC) / 2.0
        out.add(Candle(c.t, ho, max(c.h, max(ho, hc)), min(c.l, min(ho, hc)), hc, c.v))
        pO = ho
        pC = hc
    }
    return out
}

private val HM = SimpleDateFormat("HH:mm", Locale.getDefault())
private val DM = SimpleDateFormat("d MMM", Locale.getDefault())

private fun DrawScope.candles(g: Geo, cs: List<Candle>, type: Int) {
    val up = Brand.Up
    val dn = Brand.Down
    val hollowUp = Brand.HollowOn || type == 1
    val bw = g.barW
    val first = max(0, g.firstIdx)
    val last = min(cs.size - 1, g.lastIdx)
    if (type == 3 || type == 4) {
        val path = Path()
        var started = false
        for (i in first..last) {
            val x = g.xAt(i.toDouble())
            val y = g.yAt(cs[i].c)
            if (!started) { path.moveTo(x, y); started = true } else path.lineTo(x, y)
        }
        if (!started) return
        if (type == 4) {
            val area = Path()
            area.addPath(path)
            area.lineTo(g.xAt(last.toDouble()), g.bottom)
            area.lineTo(g.xAt(first.toDouble()), g.bottom)
            area.close()
            drawPath(area, Brand.Primary.copy(alpha = 0.12f))
        }
        drawPath(path, Brand.Primary, style = Stroke(width = 2.dp.toPx()))
        return
    }
    val wick = max(1f, bw * 0.12f)
    for (i in first..last) {
        val c = cs[i]
        val x = g.xAt(i.toDouble())
        val isUp = c.c >= c.o
        val col = if (isUp) up else dn
        if (type == 2) {
            drawLine(col, Offset(x, g.yAt(c.h)), Offset(x, g.yAt(c.l)), wick)
            drawLine(col, Offset(x - bw * 0.35f, g.yAt(c.o)), Offset(x, g.yAt(c.o)), wick)
            drawLine(col, Offset(x, g.yAt(c.c)), Offset(x + bw * 0.35f, g.yAt(c.c)), wick)
        } else {
            drawLine(col, Offset(x, g.yAt(c.h)), Offset(x, g.yAt(c.l)), wick)
            val yTop = g.yAt(max(c.o, c.c))
            val yBot = g.yAt(min(c.o, c.c))
            val h = max(1.5f, yBot - yTop)
            if (isUp && hollowUp) drawRect(col, Offset(x - bw * 0.35f, yTop), Size(bw * 0.7f, h), style = Stroke(width = max(1.2f, bw * 0.1f)))
            else drawRect(col, Offset(x - bw * 0.35f, yTop), Size(bw * 0.7f, h))
        }
    }
}

private fun DrawScope.series(g: Geo, arr: DoubleArray, yOf: (Double) -> Float, color: Color, width: Float) {
    var prev: Offset? = null
    val from = max(0, g.firstIdx - 1)
    val to = min(arr.size - 1, g.lastIdx)
    for (i in from..to) {
        val v = arr[i]
        if (v.isNaN()) { prev = null; continue }
        val p = Offset(g.xAt(i.toDouble()), yOf(v))
        if (prev != null) drawLine(color, prev, p, width)
        prev = p
    }
}

private fun DrawScope.overlay(g: Geo, out: IndOut) {
    val yOf = { v: Double -> g.yAt(v) }
    if (out.bandFill && out.lines.size >= 3) {
        val up = out.lines[0]
        val lo = out.lines[2]
        val from = max(0, g.firstIdx)
        val to = min(up.size - 1, g.lastIdx)
        val path = Path()
        var started = false
        for (i in from..to) {
            if (up[i].isNaN()) continue
            val x = g.xAt(i.toDouble())
            if (!started) { path.moveTo(x, g.yAt(up[i])); started = true } else path.lineTo(x, g.yAt(up[i]))
        }
        if (started) {
            for (i in to downTo from) {
                if (lo[i].isNaN()) continue
                path.lineTo(g.xAt(i.toDouble()), g.yAt(lo[i]))
            }
            path.close()
            drawPath(path, Color(out.colors[0]).copy(alpha = 0.07f))
        }
    }
    for ((j, arr) in out.lines.withIndex()) series(g, arr, yOf, Color(out.colors[j]), 1.6.dp.toPx())
}

private fun DrawScope.subPane(g: Geo, pane: PaneRect, out: IndOut, cs: List<Candle>) {
    val h = pane.bottom - pane.top
    val hist = out.hist
    var dlo = Double.MAX_VALUE
    var dhi = -Double.MAX_VALUE
    fun scan(arr: DoubleArray) {
        for (i in max(0, g.firstIdx)..min(arr.size - 1, g.lastIdx)) {
            val v = arr[i]
            if (!v.isNaN()) { dlo = min(dlo, v); dhi = max(dhi, v) }
        }
    }
    for (l in out.lines) scan(l)
    if (hist != null) scan(hist)
    var lo = if (out.min.isNaN()) (if (dlo == Double.MAX_VALUE) 0.0 else dlo) else out.min
    var hi = if (out.max.isNaN()) (if (dhi == -Double.MAX_VALUE) 1.0 else dhi) else out.max
    if (out.min.isNaN() && out.max.isNaN()) {
        val pad = (hi - lo) * 0.1
        lo -= pad
        hi += pad
    } else if (out.max.isNaN()) {
        hi += (hi - lo) * 0.1
    }
    if (hi <= lo) hi = lo + 1.0
    fun y(v: Double): Float = pane.bottom - ((v - lo) / (hi - lo) * h).toFloat()

    drawLine(Brand.Border, Offset(0f, pane.top), Offset(g.w, pane.top), 1f)
    val dash = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
    for ((k, gv) in out.guides.withIndex()) {
        val yy = y(gv)
        drawLine(Brand.Grid, Offset(0f, yy), Offset(g.pw, yy), 1f, pathEffect = dash)
        val lb = out.guideLabels.getOrNull(k)
        if (lb != null) chartText(lb, 6.dp.toPx(), yy - 2.dp.toPx(), Brand.Muted.toArgb(), 9f)
    }
    clipRect(0f, pane.top, g.pw, pane.bottom) {
        if (hist != null) {
            val zero = y(if (out.histMode == 2) 0.0 else lo)
            for (i in max(0, g.firstIdx)..min(hist.size - 1, g.lastIdx)) {
                val v = hist[i]
                if (v.isNaN()) continue
                val x = g.xAt(i.toDouble())
                val isUp = if (out.histMode == 1) cs[i].c >= cs[i].o else v >= 0
                val col = (if (isUp) Brand.Up else Brand.Down).copy(alpha = 0.55f)
                val yy = y(v)
                drawRect(col, Offset(x - g.barW * 0.3f, min(yy, zero)), Size(g.barW * 0.6f, max(1f, abs(zero - yy))))
            }
        }
        for ((j, arr) in out.lines.withIndex()) series(g, arr, { v -> y(v) }, Color(out.colors[j]), 1.5.dp.toPx())
    }
    // title with the last value
    var lastV = Double.NaN
    if (out.lines.isNotEmpty()) {
        val a = out.lines[0]
        for (i in min(a.size - 1, g.lastIdx) downTo 0) if (!a[i].isNaN()) { lastV = a[i]; break }
    } else if (hist != null && hist.isNotEmpty()) lastV = hist[min(hist.size - 1, g.lastIdx)]
    chartText(out.label + (if (lastV.isNaN()) "" else "  " + fp(lastV, 2)), 6.dp.toPx(), pane.top + 13.dp.toPx(), Brand.Text.toArgb(), 10f)
    chartText(fp(hi, 1), g.pw + 6.dp.toPx(), pane.top + 11.dp.toPx(), Brand.Muted.toArgb(), 9f)
    chartText(fp(lo, 1), g.pw + 6.dp.toPx(), pane.bottom - 3.dp.toPx(), Brand.Muted.toArgb(), 9f)
}

private fun ribbonEdge(r: RibbonResult, i: Int): Double {
    val a = r.alma[i]
    val d = r.dev[i]
    if (d.isNaN()) return a
    return when (r.trend[i]) {
        1 -> a - d * 0.55
        -1 -> a + d * 0.55
        else -> a
    }
}

/** Draws the whole chart: scales, candles, indicators, levels, alerts, drawings, crosshair. */
fun DrawScope.drawChart(
    g: Geo,
    raw: List<Candle>,
    shown: List<Candle>,
    type: Int,
    dec: Int,
    outs: List<Pair<IndCfg, IndOut>>,
    ribbon: RibbonResult?,
    levels: LevelsResult?,
    showRibbon: Boolean,
    showLevels: Boolean,
    alerts: List<PriceAlert>,
    drawings: List<Drawing>,
    selectedId: String?,
    pending: List<DPoint>,
    pendingKind: String,
    cross: Offset?,
    setups: Map<Int, SetupScan> = emptyMap(),
    alch: List<ExtraEngines.AlchLevel> = emptyList(),
) {
    val muted = Brand.Muted.toArgb()
    // price axis and grid
    for (k in 0..5) {
        val tv = g.lo + (g.hi - g.lo) * k / 5.0
        val y = (g.bottom - (tv - g.lo) / (g.hi - g.lo) * (g.bottom - g.top)).toFloat()
        drawLine(Brand.Grid, Offset(0f, y), Offset(g.pw, y), 1f)
        val label = if (g.scaleType == 2) fp(tv, 2) + "%" else fp(g.inv(tv), dec)
        chartText(label, g.pw + 6.dp.toPx(), y + 4.dp.toPx(), muted, 10f)
    }
    // time axis
    val spacing = g.step
    for (k in 0..3) {
        val i = g.firstIdx + (g.lastIdx - g.firstIdx) * k / 3
        if (i < 0 || i >= raw.size) continue
        val text = (if (spacing >= 86400L) DM else HM).format(Date(raw[i].t * 1000L))
        chartText(text, g.xAt(i.toDouble()), g.h - 6.dp.toPx(), muted, 10f, right = k == 3)
    }

    clipRect(0f, g.top, g.pw, g.bottom) {
        // key levels
        if (showLevels && levels != null) {
            for (lv in levels.levels) {
                val y = g.yAt(lv.price)
                drawLine(Brand.Muted.copy(alpha = 0.55f), Offset(0f, y), Offset(g.pw, y), 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 8f)))
                chartText("x" + lv.touches, 6.dp.toPx(), y - 3.dp.toPx(), muted, 9f)
            }
        }
        // drawings that sit behind the candles
        for (d in drawings) drawDrawing(d, g, d.id == selectedId, dec)
        candles(g, shown, type)
        for ((cfg, out) in outs) if (IndSpecs.spec(cfg.type).overlay) overlay(g, out)
        // trend ribbon
        if (showRibbon && ribbon != null) {
            val from = max(1, g.firstIdx)
            val to = min(g.lastIdx, ribbon.alma.size - 1)
            for (i in from..to) {
                val a0 = ribbon.alma[i - 1]
                val a1 = ribbon.alma[i]
                if (a0.isNaN() || a1.isNaN()) continue
                val tr = ribbon.trend[i]
                val col = if (tr == 1) Brand.Up else if (tr == -1) Brand.Down else Brand.Muted
                drawLine(col.copy(alpha = 0.9f), Offset(g.xAt((i - 1).toDouble()), g.yAt(ribbonEdge(ribbon, i - 1))), Offset(g.xAt(i.toDouble()), g.yAt(ribbonEdge(ribbon, i))), 3f)
                drawLine(Brand.Muted, Offset(g.xAt((i - 1).toDouble()), g.yAt(a0)), Offset(g.xAt(i.toDouble()), g.yAt(a1)), 1.2f)
            }
            val pos = ribbon.pos
            if (pos != null) {
                val x0 = g.xAt(pos.entryIdx.toDouble())
                val x1 = if (pos.stopped) g.xAt(pos.stopIdx.toDouble()) else if (pos.endIdx >= 0) g.xAt(pos.endIdx.toDouble()) else g.pw
                val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
                drawLine(Brand.Text, Offset(x0, g.yAt(pos.entry)), Offset(x1, g.yAt(pos.entry)), 2f, pathEffect = dash)
                drawLine(Brand.Danger, Offset(x0, g.yAt(pos.stop)), Offset(x1, g.yAt(pos.stop)), 2f, pathEffect = dash)
                for (k in pos.targets.indices) drawLine(Brand.Up.copy(alpha = if (k < pos.hits) 0.4f else 0.9f), Offset(x0, g.yAt(pos.targets[k])), Offset(x1, g.yAt(pos.targets[k])), 2f, pathEffect = dash)
            }
        }
        // alert lines
        for (a in alerts) {
            val y = g.yAt(a.level)
            drawLine(Brand.Alert, Offset(0f, y), Offset(g.pw, y), 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(16f, 10f)))
        }
        if (alch.isNotEmpty()) drawAlchLevels(g, alch, dec)
        // setup finder, drawn like an indicator
        for ((i, sc) in setups) if (Store.setupIsOn(i)) drawSetups(g, sc, dec, SETUP_SHORT[i.coerceIn(0, 8)])
        // drawing in progress
        if (pending.isNotEmpty()) {
            val pts = pending.map { Draw.scr(g, it) }
            for (p in pts) drawCircle(Brand.Alert, 6.dp.toPx(), p)
            for (i in 0 until pts.size - 1) drawLine(Brand.Alert, pts[i], pts[i + 1], 1.5.dp.toPx())
            if (pendingKind == "brush" || pendingKind == "highlighter") {
                val path = Path()
                path.moveTo(pts[0].x, pts[0].y)
                for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
                drawPath(path, Brand.Alert, style = Stroke(width = 2.dp.toPx()))
            }
        }
        // last price line
        if (raw.isNotEmpty()) {
            val y = g.yAt(raw[raw.size - 1].c)
            drawLine(Brand.Muted.copy(alpha = 0.7f), Offset(0f, y), Offset(g.pw, y), 1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 8f)))
        }
        // crosshair
        if (cross != null) {
            drawLine(Brand.Muted, Offset(cross.x, g.top), Offset(cross.x, g.h - g.botH), 1f)
            drawLine(Brand.Muted, Offset(0f, cross.y), Offset(g.pw, cross.y), 1f)
        }
    }

    // indicator panes
    var k = 0
    for ((cfg, out) in outs) {
        if (IndSpecs.spec(cfg.type).overlay) continue
        k += 1
        if (k >= g.panes.size) break
        subPane(g, g.panes[k], out, raw)
    }

    // axis tags: alert prices, last price, crosshair price
    for (a in alerts) {
        val y = g.yAt(a.level)
        if (y < g.top || y > g.bottom) continue
        val text = fp(a.level, dec)
        drawRect(Brand.Alert, Offset(g.pw, y - 9.dp.toPx()), Size(g.axisW, 18.dp.toPx()))
        chartText(text, g.pw + 4.dp.toPx(), y + 4.dp.toPx(), 0xFF000000.toInt(), 10f, bold = true)
    }
    if (raw.isNotEmpty()) {
        val c = raw[raw.size - 1]
        val y = g.yAt(c.c)
        if (y >= g.top && y <= g.bottom) {
            val bg = if (c.c >= c.o) Brand.Up else Brand.Down
            // time left in the forming candle, shown under the price like on TradingView
            val left = c.t + Store.chartTf - System.currentTimeMillis() / 1000L
            val cd = if (left > 0L && left <= 90000L) countdown(left) else ""
            val th = if (cd.isEmpty()) 18.dp.toPx() else 30.dp.toPx()
            drawRoundRect(bg, Offset(g.pw, y - 9.dp.toPx()), Size(g.axisW, th), CornerRadius(2.dp.toPx()))
            val fg = if (bg.red * 0.299f + bg.green * 0.587f + bg.blue * 0.114f > 0.55f) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            chartText(fp(c.c, dec), g.pw + 4.dp.toPx(), y + 4.dp.toPx(), fg, 10f, bold = true)
            if (cd.isNotEmpty()) chartText(cd, g.pw + 4.dp.toPx(), y + 18.dp.toPx(), fg, 9f)
        }
    }
    if (cross != null && cross.y >= g.top && cross.y <= g.bottom) {
        drawRect(Brand.Text, Offset(g.pw, cross.y - 9.dp.toPx()), Size(g.axisW, 18.dp.toPx()))
        chartText(fp(g.priceAtY(cross.y), dec), g.pw + 4.dp.toPx(), cross.y + 4.dp.toPx(), Brand.Bg.toArgb(), 10f, bold = true)
    }

    // legend: open, high, low, close of the crosshair candle or the last candle
    if (raw.isNotEmpty()) {
        var i = raw.size - 1
        if (cross != null) i = Math.round(g.idxAtX(cross.x)).toInt().coerceIn(0, raw.size - 1)
        val c = raw[i]
        val txt = "O " + fp(c.o, dec) + "  H " + fp(c.h, dec) + "  L " + fp(c.l, dec) + "  C " + fp(c.c, dec)
        chartText(txt, 6.dp.toPx(), g.top + 14.dp.toPx(), Brand.Text.toArgb(), 10f)
        var ly = g.top + 28.dp.toPx()
        for ((cfg, out) in outs) {
            if (!IndSpecs.spec(cfg.type).overlay || out.lines.isEmpty()) continue
            chartText(out.label, 6.dp.toPx(), ly, Color(out.colors[0]).toArgb(), 10f)
            ly += 13.dp.toPx()
        }
    }
}

private fun countdown(sec: Long): String {
    val h = sec / 3600L
    val m = (sec % 3600L) / 60L
    val s = sec % 60L
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
}
