package online.wickwatch.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Wickwatch's own line icons, drawn in code on a 24 x 24 grid with round caps (no emoji, no icon library).
 * [filled] only changes the star.
 */
@Composable
fun WIcon(kind: String, modifier: Modifier = Modifier, size: Dp = 22.dp, tint: Color = Brand.Text, filled: Boolean = false) {
    Canvas(modifier.size(size)) {
        val u = this.size.minDimension / 24f
        val w = 1.8f * u
        val st = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun pt(x: Float, y: Float) = Offset(x * u, y * u)
        fun ln(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(tint, pt(x1, y1), pt(x2, y2), w, StrokeCap.Round)
        fun dot(x: Float, y: Float, r: Float = 1.9f) = drawCircle(tint, r * u, pt(x, y))
        fun ring(x: Float, y: Float, r: Float) = drawCircle(tint, r * u, pt(x, y), style = st)
        fun poly(vararg v: Float, close: Boolean = false) {
            val p = Path()
            var i = 0
            while (i + 1 < v.size) {
                if (i == 0) p.moveTo(v[i] * u, v[i + 1] * u) else p.lineTo(v[i] * u, v[i + 1] * u)
                i += 2
            }
            if (close) p.close()
            drawPath(p, tint, style = st)
        }
        fun box(x: Float, y: Float, bw: Float, bh: Float, r: Float = 1.5f) =
            drawRoundRect(tint, pt(x, y), Size(bw * u, bh * u), CornerRadius(r * u), style = st)

        when (kind) {
            "chart" -> { poly(3f, 17f, 9f, 11f, 13f, 15f, 21f, 6f); poly(16f, 6f, 21f, 6f, 21f, 11f) }
            "line" -> poly(3f, 17f, 9f, 10f, 14f, 14f, 21f, 6f)
            "area" -> {
                val p = Path()
                p.moveTo(3 * u, 20 * u); p.lineTo(3 * u, 15 * u); p.lineTo(9 * u, 9 * u); p.lineTo(14 * u, 13 * u); p.lineTo(21 * u, 6 * u); p.lineTo(21 * u, 20 * u); p.close()
                drawPath(p, tint.copy(alpha = 0.25f), style = Fill)
                poly(3f, 15f, 9f, 9f, 14f, 13f, 21f, 6f)
            }
            "candles" -> {
                ln(8f, 3f, 8f, 21f); box(5.5f, 8f, 5f, 8f, 1f)
                ln(17f, 5f, 17f, 19f); box(14.5f, 10f, 5f, 5f, 1f)
            }
            "bars" -> {
                ln(8f, 4f, 8f, 20f); ln(4.5f, 8f, 8f, 8f); ln(8f, 15f, 11.5f, 15f)
                ln(17f, 4f, 17f, 20f); ln(13.5f, 11f, 17f, 11f); ln(17f, 7f, 20.5f, 7f)
            }
            "watch" -> {
                val p = Path()
                p.moveTo(2.5f * u, 12f * u)
                p.cubicTo(6f * u, 6f * u, 18f * u, 6f * u, 21.5f * u, 12f * u)
                p.cubicTo(18f * u, 18f * u, 6f * u, 18f * u, 2.5f * u, 12f * u)
                drawPath(p, tint, style = st)
                ring(12f, 12f, 3f)
            }
            "bell" -> {
                val p = Path()
                p.moveTo(6f * u, 17f * u); p.lineTo(6f * u, 11f * u)
                p.cubicTo(6f * u, 4f * u, 18f * u, 4f * u, 18f * u, 11f * u)
                p.lineTo(18f * u, 17f * u)
                drawPath(p, tint, style = st)
                ln(4f, 17f, 20f, 17f); ln(10f, 20.5f, 14f, 20.5f)
            }
            "alarm" -> {
                ring(12f, 13f, 7.5f); poly(12f, 9f, 12f, 13f, 15f, 15f)
                ln(3.5f, 6f, 7f, 3f); ln(20.5f, 6f, 17f, 3f)
            }
            "more" -> { dot(5f, 12f); dot(12f, 12f); dot(19f, 12f) }
            "grip" -> { dot(9f, 6f, 1.5f); dot(15f, 6f, 1.5f); dot(9f, 12f, 1.5f); dot(15f, 12f, 1.5f); dot(9f, 18f, 1.5f); dot(15f, 18f, 1.5f) }
            "search" -> { ring(10.5f, 10.5f, 6f); ln(15f, 15f, 20f, 20f) }
            "close" -> { ln(5f, 5f, 19f, 19f); ln(19f, 5f, 5f, 19f) }
            "plus" -> { ln(12f, 5f, 12f, 19f); ln(5f, 12f, 19f, 12f) }
            "check" -> poly(5f, 12.5f, 10f, 17f, 19f, 7f)
            "down" -> poly(6f, 9f, 12f, 15f, 18f, 9f)
            "right" -> poly(9f, 6f, 15f, 12f, 9f, 18f)
            "left" -> poly(15f, 6f, 9f, 12f, 15f, 18f)
            "trash" -> { ln(4f, 7f, 20f, 7f); ln(10f, 4f, 14f, 4f); poly(6f, 7f, 7f, 20f, 17f, 20f, 18f, 7f) }
            "copy" -> { box(9f, 9f, 11f, 11f, 2f); poly(15f, 5f, 15f, 4f, 5f, 4f, 4f, 5f, 4f, 15f, 5f, 15f, 9f, 15f) }
            "lock" -> {
                box(5f, 11f, 14f, 10f, 2f)
                val p = Path(); p.moveTo(8f * u, 11f * u); p.lineTo(8f * u, 8f * u); p.cubicTo(8f * u, 2f * u, 16f * u, 2f * u, 16f * u, 8f * u); p.lineTo(16f * u, 11f * u)
                drawPath(p, tint, style = st)
            }
            "unlock" -> {
                box(5f, 11f, 14f, 10f, 2f)
                val p = Path(); p.moveTo(8f * u, 11f * u); p.lineTo(8f * u, 8f * u); p.cubicTo(8f * u, 2f * u, 16f * u, 2f * u, 16f * u, 6f * u)
                drawPath(p, tint, style = st)
            }
            "pencil" -> { poly(4f, 20f, 5f, 15f, 16f, 4f, 20f, 8f, 9f, 19f, close = true); ln(13.5f, 6.5f, 17.5f, 10.5f) }
            "star" -> {
                val p = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 9.5f else 4.2f
                    val a = -PI / 2.0 + i * PI / 5.0
                    val x = (12f + r * cos(a).toFloat()) * u
                    val y = (12.8f + r * sin(a).toFloat()) * u
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                if (filled) drawPath(p, tint, style = Fill) else drawPath(p, tint, style = st)
            }
            "indicators" -> {
                val p = Path()
                p.moveTo(2f * u, 15f * u)
                p.cubicTo(5f * u, 5f * u, 8f * u, 5f * u, 11f * u, 12f * u)
                p.cubicTo(14f * u, 19f * u, 17f * u, 19f * u, 22f * u, 8f * u)
                drawPath(p, tint, style = st)
                ln(3f, 21f, 21f, 21f)
            }
            "layers" -> { poly(12f, 3f, 21f, 8f, 12f, 13f, 3f, 8f, close = true); poly(3f, 12.5f, 12f, 17.5f, 21f, 12.5f); poly(3f, 16.8f, 12f, 21.5f, 21f, 16.8f) }
            "cursor" -> poly(6f, 3f, 6f, 19f, 10.5f, 15f, 14f, 21f, 16.5f, 19.5f, 13f, 14f, 19f, 14f, close = true)
            "sliders" -> {
                ln(4f, 7f, 20f, 7f); ln(4f, 17f, 20f, 17f)
                ring(9f, 7f, 2.6f); ring(15f, 17f, 2.6f)
            }
            "info" -> { ring(12f, 12f, 9f); ln(12f, 11f, 12f, 16.5f); dot(12f, 7.6f, 1.2f) }
            "undo" -> { poly(9f, 5f, 4f, 10f, 9f, 15f); poly(4f, 10f, 14f, 10f); val p = Path(); p.moveTo(14f * u, 10f * u); p.cubicTo(20f * u, 10f * u, 20f * u, 19f * u, 14f * u, 19f * u); p.lineTo(9f * u, 19f * u); drawPath(p, tint, style = st) }
            "cloudoff" -> {
                val p = Path()
                p.moveTo(7f * u, 18f * u); p.cubicTo(2f * u, 18f * u, 2f * u, 11f * u, 7f * u, 11f * u)
                p.cubicTo(7f * u, 6f * u, 16f * u, 6f * u, 16.5f * u, 11f * u); p.cubicTo(21f * u, 11f * u, 21f * u, 18f * u, 16.5f * u, 18f * u); p.close()
                drawPath(p, tint, style = st)
                ln(4f, 4f, 20f, 20f)
            }
            "camera" -> {
                val p = Path()
                p.moveTo(3f * u, 8f * u); p.lineTo(7f * u, 8f * u); p.lineTo(9f * u, 5f * u); p.lineTo(15f * u, 5f * u); p.lineTo(17f * u, 8f * u); p.lineTo(21f * u, 8f * u)
                p.lineTo(21f * u, 19f * u); p.lineTo(3f * u, 19f * u); p.close()
                drawPath(p, tint, style = st)
                ring(12f, 13f, 3.6f)
            }
            "dash" -> { ln(3f, 12f, 7f, 12f); ln(10f, 12f, 14f, 12f); ln(17f, 12f, 21f, 12f) }
            // ---- drawing tool glyphs
            "t_trend" -> { ln(7f, 17f, 17f, 7f); ring(5.5f, 18.5f, 2f); ring(18.5f, 5.5f, 2f) }
            "t_hline" -> { ln(3f, 12f, 21f, 12f); ring(12f, 12f, 2.4f) }
            "t_vline" -> { ln(12f, 3f, 12f, 21f); ring(12f, 12f, 2.4f) }
            "t_cross" -> { ln(12f, 3f, 12f, 21f); ln(3f, 12f, 21f, 12f) }
            "t_chan" -> { ln(4f, 13f, 16f, 3f); ln(8f, 21f, 20f, 11f) }
            "t_fork" -> { ln(4f, 20f, 12f, 12f); ln(12f, 12f, 20f, 4f); ln(12f, 12f, 20f, 12f); ln(12f, 12f, 12f, 4f) }
            "t_fib" -> { ln(3f, 5f, 21f, 5f); ln(3f, 10f, 21f, 10f); ln(3f, 15f, 21f, 15f); ln(3f, 20f, 21f, 20f) }
            "t_zig" -> poly(3f, 18f, 8f, 7f, 13f, 15f, 21f, 5f)
            "t_box" -> { box(4f, 5f, 16f, 14f, 1.5f); ln(4f, 12f, 20f, 12f) }
            "t_text" -> { ln(6f, 5f, 18f, 5f); ln(12f, 5f, 12f, 19f); ln(9f, 19f, 15f, 19f) }
            "t_rect" -> box(4f, 6f, 16f, 12f, 1.5f)
            "t_circle" -> ring(12f, 12f, 8f)
            "t_tri" -> poly(12f, 4f, 21f, 19f, 3f, 19f, close = true)
            else -> ring(12f, 12f, 8f)
        }
    }
}

/** Which icon shows for a drawing tool, from the way it is drawn. */
fun toolIcon(kind: String): String = when (kind) {
    "seg", "ray", "ext", "info", "arrow", "arrowm" -> "t_trend"
    "hline", "hray" -> "t_hline"
    "vline" -> "t_vline"
    "cross" -> "t_cross"
    "pchan", "flat", "disjoint", "fibchan" -> "t_chan"
    "pitchfork" -> "t_fork"
    "fib", "fibext", "fibtime", "cyclic" -> "t_fib"
    "poly", "polyline", "path", "ellipse" -> "t_zig"
    "long", "short", "prange", "drange", "pdrange" -> "t_box"
    "brush", "highlighter" -> "pencil"
    "text", "note", "pnote", "callout", "comment", "plabel", "emoji", "marker" -> "t_text"
    "rect" -> "t_rect"
    "circle" -> "t_circle"
    "tri" -> "t_tri"
    else -> "t_trend"
}

/** A square icon button. Selected = filled with the theme's main colour. */
@Composable
fun IconBtn(kind: String, selected: Boolean = false, size: Dp = 40.dp, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(10.dp))
            .background(if (selected) Brand.Primary else Color.Transparent)
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        WIcon(kind, size = 22.dp, tint = if (selected) Brand.Bg else Brand.Text, modifier = Modifier.alpha(if (enabled) 1f else 0.35f))
    }
}

/** A bottom sheet in the app's colours. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Sheet(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = state,
        containerColor = Brand.Panel,
        contentColor = Brand.Text,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
    ) {
        androidx.compose.foundation.layout.Column(
            Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 16.dp).padding(bottom = 16.dp),
            content = content,
        )
    }
}

@Composable
fun HubLabel(text: String) {
    Text(text, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Brand.Muted, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
}

@Composable
fun HubRow(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

/** A big rounded tile with an icon and a label, like the tiles in a TradingView menu. [active] marks a switched-on option. */
@Composable
fun HubTile(icon: String, label: String, modifier: Modifier = Modifier, enabled: Boolean = true, active: Boolean = false, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(if (active) Brand.Primary else Brand.Elevated)
            .border(1.dp, if (active) Brand.Primary else Brand.Border, RoundedCornerShape(14.dp))
            .clickable(enabled = enabled) { onClick() }
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        WIcon(icon, size = 26.dp, tint = if (active) Brand.Bg else if (enabled) Brand.Text else Brand.Muted)
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = if (active) Brand.Bg else if (enabled) Brand.Text else Brand.Muted)
    }
}
