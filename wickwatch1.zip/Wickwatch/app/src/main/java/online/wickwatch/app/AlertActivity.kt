package online.wickwatch.app

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.Text
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** A full-screen alert for urgent alerts: shows over the lock screen with the phone woken up. Uses the chosen theme. */
class AlertActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.init(this)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        val title = intent.getStringExtra("title") ?: "Alert"
        val text = intent.getStringExtra("text") ?: ""
        setContent {
            AppTheme {
                Column(
                    Modifier.fillMaxSize().background(Brand.Bg).systemBarsPadding().padding(28.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Pill("URGENT ALERT", Brand.Danger)
                    Text(
                        title, color = Brand.Text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 18.dp),
                    )
                    Text(text, color = Brand.Muted, fontSize = 17.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 18.dp))
                    PrimaryButton("Dismiss", Modifier.fillMaxWidth()) { finish() }
                    SecondaryButton("Open the app", Modifier.fillMaxWidth().padding(top = 10.dp)) {
                        startActivity(Intent(this@AlertActivity, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
                        finish()
                    }
                }
            }
        }
    }
}
