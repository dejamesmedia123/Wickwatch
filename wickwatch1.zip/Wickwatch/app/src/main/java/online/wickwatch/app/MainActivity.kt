package online.wickwatch.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.init(this)
        Store.ensureDefaultIndicators()
        Alerts.ensureChannels(this)
        setContent {
            AppTheme { Root() }
        }
    }

    override fun onResume() {
        super.onResume()
        // if the watcher should be on (for example after the app was closed), make sure it is running
        if (Store.watching && Watcher.hasWork() && !WatchService.running) WatchService.start(this)
    }
}

/** The Material colours follow the chosen Wickwatch theme (black and white, white, or navy and teal). */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (Brand.dark) {
        darkColorScheme(
            primary = Brand.Primary, onPrimary = Brand.Bg,
            background = Brand.Bg, onBackground = Brand.Text,
            surface = Brand.Bg, onSurface = Brand.Text,
            surfaceVariant = Brand.Elevated, onSurfaceVariant = Brand.Muted,
            secondaryContainer = Brand.Elevated, onSecondaryContainer = Brand.Text,
            outline = Brand.Border, outlineVariant = Brand.Border,
            error = Brand.Danger,
        )
    } else {
        lightColorScheme(
            primary = Brand.Primary, onPrimary = Brand.Bg,
            background = Brand.Bg, onBackground = Brand.Text,
            surface = Brand.Bg, onSurface = Brand.Text,
            surfaceVariant = Brand.Elevated, onSurfaceVariant = Brand.Muted,
            secondaryContainer = Brand.Elevated, onSecondaryContainer = Brand.Text,
            outline = Brand.Border, outlineVariant = Brand.Border,
            error = Brand.Danger,
        )
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.setBackgroundDrawable(ColorDrawable(Brand.Bg.toArgb()))
            val ctl = WindowCompat.getInsetsController(window, view)
            ctl.isAppearanceLightStatusBars = !Brand.dark
            ctl.isAppearanceLightNavigationBars = !Brand.dark
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
private fun Root() {
    if (!Store.onboarded) {
        Onboarding(onDone = { })
        return
    }
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    val names = listOf("Chart", "Watchlist", "Alerts", "More")
    val marks = listOf("📈", "👁", "🔔", "⋯")
    fun openChart(key: String) {
        Store.chartKey = key
        Store.save()
        tab = 0
    }
    Scaffold(
        containerColor = Brand.Bg,
        contentColor = Brand.Text,
        bottomBar = {
            NavigationBar(containerColor = Brand.Panel, contentColor = Brand.Text) {
                names.forEachIndexed { i, n ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(marks[i]) },
                        label = { Text(n) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Brand.Text, selectedTextColor = Brand.Text,
                            unselectedIconColor = Brand.Muted, unselectedTextColor = Brand.Muted,
                            indicatorColor = Brand.Elevated,
                        ),
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                0 -> ChartScreen()
                1 -> WatchlistScreen(onOpenChart = { openChart(it) })
                2 -> AlertsScreen(onOpenChart = { openChart(it) })
                else -> MoreScreen()
            }
        }
    }
}
