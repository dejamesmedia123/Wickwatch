package online.wickwatch.app

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.init(this)
        Store.ensureDefaultIndicators()
        Alerts.ensureChannels(this)
        setContent {
            AppTheme { Root() }
        }
    }

    override fun onResume() {
        super.onResume()
        Expiry.check(this, force = true)
        // if the watcher should be on (for example after the app was closed), make sure it is running
        if (Store.watching && Watcher.hasWork() && !WatchService.running) WatchService.start(this)
    }
}

/** The Material colours follow the chosen Wickwatch theme (black and white, white, or navy and teal). */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (Brand.dark) {
        darkColorScheme(
            primary = Brand.Primary, onPrimary = Brand.Bg,
            background = Brand.Bg, onBackground = Brand.Text,
            surface = Brand.Bg, onSurface = Brand.Text,
            surfaceVariant = Brand.Elevated, onSurfaceVariant = Brand.Muted,
            secondaryContainer = Brand.Elevated, onSecondaryContainer = Brand.Text,
            outline = Brand.Border, outlineVariant = Brand.Border,
            error = Brand.Danger,
        )
    } else {
        lightColorScheme(
            primary = Brand.Primary, onPrimary = Brand.Bg,
            background = Brand.Bg, onBackground = Brand.Text,
            surface = Brand.Bg, onSurface = Brand.Text,
            surfaceVariant = Brand.Elevated, onSurfaceVariant = Brand.Muted,
            secondaryContainer = Brand.Elevated, onSecondaryContainer = Brand.Text,
            outline = Brand.Border, outlineVariant = Brand.Border,
            error = Brand.Danger,
        )
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.setBackgroundDrawable(ColorDrawable(Brand.Bg.toArgb()))
            val ctl = WindowCompat.getInsetsController(window, view)
            ctl.isAppearanceLightStatusBars = !Brand.dark
            ctl.isAppearanceLightNavigationBars = !Brand.dark
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
private fun Root() {
    val ctx = LocalContext.current
    // re-check now and then while the app stays open
    LaunchedEffect(Unit) {
        while (true) {
            Expiry.check(ctx)
            kotlinx.coroutines.delay(30_000L)
        }
    }
    val expired = Expiry.locked
    if (!Store.onboarded) {
        if (expired) {
            // setup was never finished and this version has run out: nothing to view, only the way to a new version
            Column(Modifier.fillMaxSize().background(Brand.Bg)) { ExpiredBanner() }
        } else {
            Onboarding(onDone = { })
        }
        return
    }
    var tab by rememberSaveable { mutableIntStateOf(1) }   // 0 Watchlist, 1 Chart, 2 Alerts, 3 More
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    val names = listOf("Watchlist", "Chart", "Alerts", "More")
    val icons = listOf("watch", "chart", "bell", "more")
    fun openChart(key: String) {
        Store.chartKey = key
        Store.save()
        tab = 1
    }
    Scaffold(
        containerColor = Brand.Bg,
        contentColor = Brand.Text,
        bottomBar = {
            Column(Modifier.background(Brand.Bg)) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(Brand.Border))
                Row(Modifier.fillMaxWidth().navigationBarsPadding().height(58.dp)) {
                    names.forEachIndexed { i, n ->
                        val on = tab == i
                        Column(
                            Modifier.weight(1f).fillMaxHeight().clickable { tab = i },
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                        ) {
                            Box(Modifier.padding(bottom = 2.dp)) { WIcon(icons[i], size = 24.dp, tint = if (on) Brand.Text else Brand.Muted) }
                            Text(n, fontSize = 11.sp, color = if (on) Brand.Text else Brand.Muted, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }
            }
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            if (expired) ExpiredBanner()
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    0 -> Box(if (expired) Modifier.blockTaps() else Modifier) { WatchlistScreen(onOpenChart = { openChart(it) }) }
                    1 -> ChartScreen()
                    2 -> Box(if (expired) Modifier.blockTaps() else Modifier) { AlertsScreen(onOpenChart = { openChart(it) }) }
                    else -> MoreScreen()
                }
            }
        }
    }
}
