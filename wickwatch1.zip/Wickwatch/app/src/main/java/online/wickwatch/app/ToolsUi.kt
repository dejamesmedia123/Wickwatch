package online.wickwatch.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.height
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign

/**
 * The drawing tool picker: search, category tabs and a grid. A star adds a tool to the favourites bar on the chart.
 * [onPick] is null when the dialog is only used to choose favourites.
 */
@Composable
fun ToolsDialog(onPick: ((String) -> Unit)?, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("Favorites") }
    val cats = listOf("Favorites") + Tools.CATS
    val list = Tools.ALL.filter { t ->
        (if (query.isNotBlank()) t.name.contains(query, ignoreCase = true) else if (cat == "Favorites") t.id in Store.favTools else t.cat == cat)
    }
    Sheet(onDismiss) {
        Text(if (onPick == null) "Choose your favourite tools" else "Drawings", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Text)
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Search") },
            leadingIcon = { WIcon("search", size = 20.dp, tint = Brand.Muted) },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        )
        // category tabs with an underline on the open one
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            for (c in cats) {
                val on = cat == c && query.isBlank()
                Column(Modifier.clickable { cat = c; query = "" }.padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(c, fontSize = 14.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, color = if (on) Brand.Text else Brand.Muted)
                    Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(2.dp).background(if (on) Brand.Alert else Color.Transparent))
                }
            }
        }
        if (list.isEmpty()) Muted(if (cat == "Favorites") "No favourites yet. Open a category and tap the star on a tool." else "No tool found.", 13)
        LazyVerticalGrid(
            columns = GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.heightIn(max = 420.dp).padding(top = 10.dp),
        ) {
            items(list) { t ->
                val fav = t.id in Store.favTools
                Box(
                    Modifier.fillMaxWidth().heightIn(min = 88.dp).background(Brand.Elevated, RoundedCornerShape(14.dp))
                        .clickable(enabled = t.ready) {
                            if (onPick != null) onPick(t.id)
                            else {
                                Store.favTools = if (fav) Store.favTools - t.id else Store.favTools + t.id
                                Store.save()
                            }
                        }
                        .padding(8.dp),
                ) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        WIcon(toolIcon(t.kind), size = 26.dp, tint = if (t.ready) Brand.Text else Brand.Muted)
                        Text(t.name, fontSize = 12.sp, color = if (t.ready) Brand.Text else Brand.Muted, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, maxLines = 2)
                        if (!t.ready) Muted("soon", 10)
                    }
                    if (t.ready) {
                        Box(
                            Modifier.align(Alignment.TopEnd).clickable {
                                Store.favTools = if (fav) Store.favTools - t.id else Store.favTools + t.id
                                Store.save()
                            },
                        ) { WIcon("star", size = 18.dp, tint = if (fav) Brand.Alert else Brand.Muted, filled = fav) }
                    }
                }
            }
        }
    }
}

private val EMOJIS = listOf("\uD83D\uDE00", "\uD83D\uDE0E", "\uD83D\uDD25", "\uD83D\uDE80", "\uD83D\uDCC8", "\uD83D\uDCC9", "\uD83D\uDCB0", "\u26A0\uFE0F", "\u2705", "\u274C", "\uD83D\uDC40", "\uD83C\uDFAF", "\uD83D\uDC51", "\uD83D\uDCA1", "\u2B50", "\uD83D\uDED1")

/** Asks for the text of a note, label or similar. For the emoji tool it shows emojis to pick from. */
@Composable
fun TextInputDialog(kind: String, initial: String, onOk: (String) -> Unit, onCancel: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = Brand.Elevated,
        title = { Text(if (kind == "emoji") "Pick an emoji" else "Text", color = Brand.Text) },
        text = {
            if (kind == "emoji") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (row in EMOJIS.chunked(4)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (e in row) Text(e, fontSize = 30.sp, modifier = Modifier.clickable { onOk(e) }.padding(6.dp))
                        }
                    }
                }
            } else {
                OutlinedTextField(value = text, onValueChange = { text = it.take(60) }, label = { Text("Your text") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { if (kind != "emoji") TextButton(onClick = { onOk(text) }) { Text("Add", color = Brand.Text) } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Brand.Muted) } },
    )
}
