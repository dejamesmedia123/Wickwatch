package online.wickwatch.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The drawing tool picker: search, category tabs and a grid. A star adds a tool to the favourites bar on the chart.
 * [onPick] is null when the dialog is only used to choose favourites.
 */
@Composable
fun ToolsDialog(onPick: ((String) -> Unit)?, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("Favorites") }
    val cats = listOf("Favorites") + Tools.CATS
    val list = Tools.ALL.filter { t ->
        (if (query.isNotBlank()) t.name.contains(query, ignoreCase = true) else if (cat == "Favorites") t.id in Store.favTools else t.cat == cat)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Elevated,
        title = { Text(if (onPick == null) "Choose your favourite tools" else "Drawings", color = Brand.Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (c in cats) FilterChip(selected = cat == c && query.isBlank(), onClick = { cat = c; query = "" }, label = { Text(c) })
                }
                if (list.isEmpty()) Muted(if (cat == "Favorites") "No favourites yet. Open a category and tap the star on a tool." else "No tool found.", 13)
                LazyVerticalGrid(columns = GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 380.dp)) {
                    items(list) { t ->
                        val fav = t.id in Store.favTools
                        Box(
                            Modifier.fillMaxWidth().heightIn(min = 76.dp).background(Brand.Panel, RoundedCornerShape(12.dp))
                                .clickable(enabled = t.ready) {
                                    if (onPick != null) onPick(t.id)
                                    else {
                                        Store.favTools = if (fav) Store.favTools - t.id else Store.favTools + t.id
                                        Store.save()
                                    }
                                }
                                .padding(8.dp),
                        ) {
                            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(t.name, fontSize = 12.sp, color = if (t.ready) Brand.Text else Brand.Muted, fontWeight = FontWeight.Medium)
                                if (!t.ready) Muted("soon", 10)
                            }
                            if (t.ready) {
                                Text(
                                    if (fav) "\u2605" else "\u2606", color = if (fav) Brand.Alert else Brand.Muted, fontSize = 18.sp,
                                    modifier = Modifier.align(Alignment.TopEnd).clickable {
                                        Store.favTools = if (fav) Store.favTools - t.id else Store.favTools + t.id
                                        Store.save()
                                    },
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done", color = Brand.Text) } },
    )
}

private val EMOJIS = listOf("\uD83D\uDE00", "\uD83D\uDE0E", "\uD83D\uDD25", "\uD83D\uDE80", "\uD83D\uDCC8", "\uD83D\uDCC9", "\uD83D\uDCB0", "\u26A0\uFE0F", "\u2705", "\u274C", "\uD83D\uDC40", "\uD83C\uDFAF", "\uD83D\uDC51", "\uD83D\uDCA1", "\u2B50", "\uD83D\uDED1")

/** Asks for the text of a note, label or similar. For the emoji tool it shows emojis to pick from. */
@Composable
fun TextInputDialog(kind: String, initial: String, onOk: (String) -> Unit, onCancel: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = Brand.Elevated,
        title = { Text(if (kind == "emoji") "Pick an emoji" else "Text", color = Brand.Text) },
        text = {
            if (kind == "emoji") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (row in EMOJIS.chunked(4)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (e in row) Text(e, fontSize = 30.sp, modifier = Modifier.clickable { onOk(e) }.padding(6.dp))
                        }
                    }
                }
            } else {
                OutlinedTextField(value = text, onValueChange = { text = it.take(60) }, label = { Text("Your text") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { if (kind != "emoji") TextButton(onClick = { onOk(text) }) { Text("Add", color = Brand.Text) } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel", color = Brand.Muted) } },
    )
}
