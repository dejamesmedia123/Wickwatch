package online.wickwatch.app

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp

const val BK_OB = 0   // order block
const val BK_BB = 1   // breaker block
const val BK_MB = 2   // mitigation block

/**
 * One block (a zone on the chart). No trade, stop, target or reward to risk: it only marks where price may react.
 * [dir] 1 = bullish (support), -1 = bearish (resistance). [startIdx] is the candle the block is made from, [formIdx] the candle
 * that confirmed it. [endIdx] is the candle that closed through it (-1 = still standing). [tests] = times price came back into it.
 */
class Block(
    val kind: Int, val dir: Int, val startIdx: Int, val formIdx: Int,
    val top: Double, val bot: Double, var endIdx: Int = -1, var tests: Int = 0,
) {
    /** The candle the box starts at: a breaker starts when the order block failed. */
    val fromIdx: Int get() = if (kind == BK_BB) formIdx else startIdx
    val live: Boolean get() = endIdx < 0
    val name: String get() = if (kind == BK_OB) "OB" else if (kind == BK_BB) "BB" else "MB"
}

/**
 * Order blocks, breaker blocks and mitigation blocks, found on closed candles.
 *
 * - A swing high / low is confirmed [strength] candles after it.
 * - Bullish break: a close above the last unbroken swing high, with a move of at least [minDispAtr] ATR up from the low of the leg.
 *   The block is the last bearish candle at that low (up to 5 candles back). Bearish break is the mirror.
 * - Order block (OB): the leg's low (high) took out the swing low (high) before it, so liquidity was taken, then price reversed.
 * - Mitigation block (MB): the leg's low (high) did NOT take out the earlier swing: price failed to make a new low (high) and turned.
 * - A block stays until a candle closes through its far side. An OB that is closed through becomes a breaker (BB) of the opposite
 *   direction, and stays until a candle closes back through it.
 */
object BlockEngine {
    fun scan(cs: List<Candle>, strength: Int = 3, minDispAtr: Double = 1.5): List<Block> {
        val n = cs.size
        if (n < 30) return emptyList()
        val atr = Ind.atr(cs, 14)
        val k = strength.coerceIn(2, 10)
        val raw = ArrayList<Block>()
        val seen = HashSet<Long>()
        // confirmed swing points, in order
        val hiIdx = ArrayList<Int>()
        val loIdx = ArrayList<Int>()
        var hiBroken = true   // the last confirmed swing high has been closed above
        var loBroken = true
        for (i in 0 until n) {
            // confirm the pivot k candles back
            val p = i - k
            if (p >= k) {
                var isHi = true
                var isLo = true
                for (j in p - k..p + k) {
                    if (j == p) continue
                    if (cs[j].h >= cs[p].h) isHi = false
                    if (cs[j].l <= cs[p].l) isLo = false
                }
                if (isHi) { hiIdx.add(p); hiBroken = false }
                if (isLo) { loIdx.add(p); loBroken = false }
            }
            val a = atr[i]
            if (a.isNaN() || a <= 0.0) continue
            // bullish break of structure
            if (!hiBroken && hiIdx.isNotEmpty() && cs[i].c > cs[hiIdx[hiIdx.size - 1]].h) {
                hiBroken = true
                val h0 = hiIdx[hiIdx.size - 1]
                var j = h0
                for (q in h0..i) if (cs[q].l < cs[j].l) j = q
                if (cs[i].c - cs[j].l >= minDispAtr * a) {
                    var prevLow = Double.NaN
                    for (q in loIdx.indices.reversed()) if (loIdx[q] < j) { prevLow = cs[loIdx[q]].l; break }
                    val swept = prevLow.isNaN() || cs[j].l < prevLow
                    var o = j
                    for (q in j downTo maxOf(0, j - 5)) if (cs[q].c < cs[q].o) { o = q; break }
                    val key = o * 2L
                    if (seen.add(key)) raw.add(Block(if (swept) BK_OB else BK_MB, 1, o, i, cs[o].h, cs[o].l))
                }
            }
            // bearish break of structure
            if (!loBroken && loIdx.isNotEmpty() && cs[i].c < cs[loIdx[loIdx.size - 1]].l) {
                loBroken = true
                val l0 = loIdx[loIdx.size - 1]
                var j = l0
                for (q in l0..i) if (cs[q].h > cs[j].h) j = q
                if (cs[j].h - cs[i].c >= minDispAtr * a) {
                    var prevHigh = Double.NaN
                    for (q in hiIdx.indices.reversed()) if (hiIdx[q] < j) { prevHigh = cs[hiIdx[q]].h; break }
                    val swept = prevHigh.isNaN() || cs[j].h > prevHigh
                    var o = j
                    for (q in j downTo maxOf(0, j - 5)) if (cs[q].c > cs[q].o) { o = q; break }
                    val key = o * 2L + 1L
                    if (seen.add(key)) raw.add(Block(if (swept) BK_OB else BK_MB, -1, o, i, cs[o].h, cs[o].l))
                }
            }
        }
        // life of each block, and the breaker an order block turns into when it fails
        val out = ArrayList<Block>()
        for (b in raw) {
            var inside = false
            var endAt = -1
            for (i in b.formIdx + 1 until n) {
                val c = cs[i]
                val failed = if (b.dir == 1) c.c < b.bot else c.c > b.top
                if (failed) { endAt = i; break }
                val touch = if (b.dir == 1) c.l <= b.top else c.h >= b.bot
                if (touch && !inside) b.tests++
                inside = touch
            }
            b.endIdx = endAt
            out.add(b)
            if (b.kind == BK_OB && endAt >= 0) {
                val br = Block(BK_BB, -b.dir, b.startIdx, endAt, b.top, b.bot)
                var ins = false
                var brEnd = -1
                for (i in endAt + 1 until n) {
                    val c = cs[i]
                    val failed = if (br.dir == 1) c.c < br.bot else c.c > br.top
                    if (failed) { brEnd = i; break }
                    val touch = if (br.dir == 1) c.l <= br.top else c.h >= br.bot
                    if (touch && !ins) br.tests++
                    ins = touch
                }
                br.endIdx = brEnd
                out.add(br)
            }
        }
        return out
    }
}

/**
 * Draws blocks for the visible part of the chart. Standing blocks reach to the right edge; finished ones stop where price closed
 * through them and are drawn fainter. Blocks completely above or below the price pane are skipped, and the number drawn is capped
 * so the chart stays readable. [kinds] is a bit mask: 1 = OB, 2 = BB, 4 = MB.
 */
fun DrawScope.drawBlocks(g: Geo, blocks: List<Block>, kinds: Int) {
    val vis = blocks.filter {
        (kinds and (1 shl it.kind)) != 0 &&
            it.fromIdx <= g.lastIdx && (it.endIdx < 0 || it.endIdx >= g.firstIdx) &&
            g.yAt(it.bot) >= g.top && g.yAt(it.top) <= g.bottom
    }
    val liveOnes = vis.filter { it.live }.sortedByDescending { it.fromIdx }.take(8)
    val doneOnes = vis.filter { !it.live }.sortedByDescending { it.fromIdx }.take(30)
    val green = Color(0xFF22C55E)
    val red = Color(0xFFF2495C)
    val amber = Color(0xFFFFB020)
    for (b in doneOnes + liveOnes) {
        val col = if (b.kind == BK_MB) amber else if (b.dir == 1) green else red
        val x0 = g.xAt(b.fromIdx.toDouble()).coerceAtLeast(0f)
        val x1 = if (b.live) g.pw else g.xAt(b.endIdx.toDouble())
        if (x1 <= x0) continue
        val yT = g.yAt(b.top)
        val yB = g.yAt(b.bot)
        val h = Math.max(yB - yT, 2f)
        val a = if (b.live) 1f else 0.45f
        drawRect(col.copy(alpha = 0.16f * a), Offset(x0, yT), Size(x1 - x0, h))
        val eff = if (b.kind == BK_BB) PathEffect.dashPathEffect(floatArrayOf(10f, 8f)) else if (b.kind == BK_MB) PathEffect.dashPathEffect(floatArrayOf(3f, 6f)) else null
        drawRect(col.copy(alpha = 0.85f * a), Offset(x0, yT), Size(x1 - x0, h), style = Stroke(width = 1.2.dp.toPx(), pathEffect = eff))
        val tag = b.name + (if (b.dir == 1) " ▲" else " ▼") + (if (b.tests > 0) " x" + b.tests else "")
        val ty = (yT + 12.dp.toPx()).coerceIn(g.top + 12.dp.toPx(), g.bottom - 4.dp.toPx())
        chartText(tag, x0 + 4.dp.toPx(), ty, col.copy(alpha = Math.max(a, 0.7f)).toArgb(), 10f, bold = true)
    }
}
