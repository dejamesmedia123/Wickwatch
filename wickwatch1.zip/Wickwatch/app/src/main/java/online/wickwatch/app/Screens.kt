package online.wickwatch.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun Title(text: String, sub: String = "") {
    Column(Modifier.padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(text, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = Brand.Text)
        if (sub.isNotEmpty()) Muted(sub)
    }
}

// ============================== ALERTS ==============================

@Composable
fun AlertsScreen(onOpenChart: (String) -> Unit) {
    val ctx = LocalContext.current
    val running = WatchService.running
    val fmt = remember { SimpleDateFormat("d MMM HH:mm", Locale.getDefault()) }
    val work = Watcher.hasWork()
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Title("Alerts", "Your chart alerts and what the watcher has sent you.") }
        item {
            PCard(border = if (running) Brand.Good else Brand.Border) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (running) "Watching" else "Not watching", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    if (running) Pill("ON", Brand.Good) else Pill("OFF", Brand.Muted)
                }
                val activeAlerts = Store.priceAlerts.count { it.active }
                Muted(
                    if (running) WatchService.status.ifBlank { "Watching " + Store.watch.size + " markets" }
                    else if (!work) "Add a market on the Watchlist tab, or set an alert on the chart."
                    else Store.watch.size.toString() + " markets and " + activeAlerts + " chart alerts are set up. Tap Start to be alerted.",
                    13,
                )
                if (running) {
                    DangerButton("Stop watching", Modifier.fillMaxWidth()) { WatchService.stop(ctx) }
                } else {
                    PrimaryButton("Start watching", Modifier.fillMaxWidth(), enabled = work) {
                        Store.watching = true
                        Store.save()
                        WatchService.start(ctx)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryButton("Test alert", Modifier.weight(1f)) { Alerts.test(ctx, false) }
                SecondaryButton("Test urgent", Modifier.weight(1f)) { Alerts.test(ctx, true) }
            }
        }

        item { H("Your chart alerts") }
        if (Store.priceAlerts.isEmpty()) {
            item { Muted("None yet. On the chart, long-press a price, or select a line, rectangle or position and tap Alert.", 13) }
        }
        items(Store.priceAlerts, key = { it.id }) { a ->
            val m = marketByKey(a.key)
            val dec = m?.dec ?: 2
            PCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text((m?.name ?: a.key), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Muted(
                            (if (a.above) "When price crosses above " else "When price crosses below ") +
                                (if (a.drawingId.isEmpty()) fp(a.level, dec) else "a drawn line (follows the line)"),
                            13,
                        )
                        if (a.note.isNotBlank()) Muted(a.note)
                    }
                    if (a.active) Pill("ACTIVE", Brand.Good) else Pill("OFF", Brand.Muted)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    ChoiceChip("Normal", a.mode == 1) { setAlertMode(a.id, 1) }
                    ChoiceChip("Urgent", a.mode == 2) { setAlertMode(a.id, 2) }
                    ChoiceChip(if (a.once) "Once" else "Every time", false) { setAlertOnce(a.id, !a.once) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SecondaryButton(if (a.active) "Turn off" else "Turn on", Modifier.weight(1f)) {
                        Store.setAlertActive(a.id, !a.active)
                        Watcher.refresh()
                    }
                    SecondaryButton("Show on chart", Modifier.weight(1f)) { onOpenChart(a.key) }
                    TextButton(onClick = {
                        Store.removePriceAlert(a.id)
                        Watcher.refresh()
                        if (!Watcher.hasWork() && WatchService.running) WatchService.stop(ctx)
                    }) { Text("Delete", color = Brand.Danger) }
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                H("Recent alerts")
                Text("", Modifier.weight(1f))
                if (Store.history.isNotEmpty()) TextButton(onClick = { Store.clearHistory() }) { Text("Clear", color = Brand.Text) }
            }
        }
        if (Store.history.isEmpty()) {
            item { Muted("No alerts yet. They appear here as they arrive.", 13) }
        }
        items(Store.history) { r ->
            PCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(r.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    if (r.mode == 2) Pill("URGENT", Brand.Danger)
                    if (r.silent) Pill("QUIET", Brand.Alert, androidx.compose.ui.graphics.Color.Black)
                }
                Text(r.text, fontSize = 13.sp)
                Muted(fmt.format(Date(r.time)))
            }
        }
        item { Text("", Modifier.padding(bottom = 12.dp)) }
    }
}

private fun setAlertMode(id: String, mode: Int) {
    Store.priceAlerts = Store.priceAlerts.map { if (it.id == id) it.copy(mode = mode) else it }
    Store.save()
}

private fun setAlertOnce(id: String, once: Boolean) {
    Store.priceAlerts = Store.priceAlerts.map { if (it.id == id) it.copy(once = once) else it }
    Store.save()
}

// ============================== WATCHLIST ==============================

@Composable
fun WatchlistScreen(onOpenChart: (String) -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("Watchlist", "The markets the background watcher follows. Each one is checked for Trend Target Ribbon signals, Isotropic channels and key levels.")

        if (Store.watch.isEmpty()) Muted("Nothing yet. Add a market below.", 13)
        for (w in Store.watch) {
            val m = marketByKey(w.key)
            PCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text((m?.name ?: w.key) + "  " + tfLabel(w.tf), fontWeight = FontWeight.Bold)
                        Muted(if (m?.src == 'b') "Binance" else "Deriv")
                    }
                    TextButton(onClick = {
                        Store.chartTf = w.tf
                        onOpenChart(w.key)
                    }) { Text("Chart", color = Brand.Text) }
                    TextButton(onClick = {
                        Store.watch = Store.watch.filter { it.id != w.id }
                        Store.save()
                        Watcher.refresh()
                        if (!Watcher.hasWork() && WatchService.running) WatchService.stop(ctx)
                    }) { Text("Remove", color = Brand.Danger) }
                }
            }
        }
        if (Store.watch.isNotEmpty() && !WatchService.running) {
            PrimaryButton("Start watching", Modifier.fillMaxWidth()) {
                Store.watching = true
                Store.save()
                WatchService.start(ctx)
            }
        }

        H("Add markets")
        PCard { MarketChooser() }
        Muted("Alerts for closed candles need the candle to finish, so on 1h a signal can take up to an hour to appear. Use 5m or 15m for faster alerts. Changes apply to a running watcher straight away.", 12)
        Text("", Modifier.padding(bottom = 12.dp))
    }
}

// ============================== MORE ==============================

private class MoreRow(val id: String, val title: String, val sub: String)

private val MORE_ROWS = listOf(
    MoreRow("look", "Appearance", "Theme and candle colours"),
    MoreRow("chart", "Chart defaults", "Chart type, price scale, timeframe, magnet"),
    MoreRow("tools", "Favourite drawing tools", "The bar of tools on top of the chart"),
    MoreRow("alerts", "Alert types", "Off, normal or urgent for each alert"),
    MoreRow("dist", "Distances and quiet hours", "How close is \"near\", and when to stay quiet"),
    MoreRow("perm", "Permissions", "What Android must allow so alerts reach you"),
    MoreRow("about", "About", "Licences and notes"),
)

@Composable
fun MoreScreen() {
    var page by rememberSaveable { mutableStateOf("") }
    BackHandler(enabled = page != "") { page = "" }
    if (page == "") {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Title("More")
            for (r in MORE_ROWS) {
                PCard(Modifier.clickable { page = r.id }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                            Muted(r.sub)
                        }
                        Text("›", fontSize = 22.sp, color = Brand.Muted)
                    }
                }
            }
            PCard(Modifier.clickable { if (!Expiry.locked) { Store.onboarded = false; Store.save() } }) {
                Text("Run the setup again", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Muted("Walks through theme, candles, markets, tools and alerts. Nothing you drew or set is deleted.")
            }
            Text("", Modifier.padding(bottom = 12.dp))
        }
        return
    }
    val row = MORE_ROWS.firstOrNull { it.id == page }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
            TextButton(onClick = { page = "" }) { Text("‹ Back", color = Brand.Text, fontSize = 15.sp) }
            Text(row?.title ?: "", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = Brand.Text)
        }
        Column(if (Expiry.locked && page != "about") Modifier.blockTaps() else Modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        when (page) {
            "look" -> {
                H("Theme")
                ThemePicker()
                H("Candles")
                CandlePicker()
            }
            "chart" -> {
                PCard { ChartDefaultsPicker() }
                Muted("Indicators are added from the chart itself (the indicators button).", 12)
            }
            "tools" -> PCard { FavToolsPicker() }
            "alerts" -> {
                Muted("Off = nothing. Normal = a notification. Urgent = alarm sound, full screen, ignores Do Not Disturb.")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for ((name, _, idx) in ALERT_PROFILES) ChoiceChip("All: $name", false) { applyAlertProfile(idx) }
                }
                AlertTypesEditor()
            }
            "dist" -> DistancesPage()
            "perm" -> PermissionsPanel()
            else -> AboutPage()
        }
        }
        Text("", Modifier.padding(bottom = 12.dp))
    }
}

@Composable
private fun DistancesPage() {
    PCard {
        DecField("Near a target: within this many R", Store.nearTargetR, Modifier.fillMaxWidth()) { Store.nearTargetR = it.coerceIn(0.05, 5.0); Store.save() }
        DecField("Near the trend line: within this many ATR", Store.nearLineAtr, Modifier.fillMaxWidth()) { Store.nearLineAtr = it.coerceIn(0.05, 5.0); Store.save() }
        DecField("Near the channel edge: within this many ATR", Store.nearEdgeAtr, Modifier.fillMaxWidth()) { Store.nearEdgeAtr = it.coerceIn(0.05, 5.0); Store.save() }
        DecField("Near a key level: within this many ATR", Store.nearLevelAtr, Modifier.fillMaxWidth()) { Store.nearLevelAtr = it.coerceIn(0.05, 5.0); Store.save() }
        IntField("Minutes between repeated \"near\" alerts", Store.cooldownMin, Modifier.fillMaxWidth()) { Store.cooldownMin = it.coerceIn(0, 1440); Store.save() }
        IntField("Isotropic block period", Store.isoPeriod, Modifier.fillMaxWidth()) { Store.isoPeriod = it.coerceIn(5, 100); Store.save() }
        Muted("R = the distance from entry to stop. ATR = the average candle range. Distances apply straight away; the Isotropic period applies the next time the watcher starts.")
    }
    H("Quiet hours")
    PCard {
        SwitchRow("No sound during quiet hours", Store.quietOn) { Store.quietOn = it; Store.save() }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IntField("From (hour 0-23)", Store.quietFrom, Modifier.weight(1f)) { Store.quietFrom = it.coerceIn(0, 23); Store.save() }
            IntField("Until (hour 0-23)", Store.quietTo, Modifier.weight(1f)) { Store.quietTo = it.coerceIn(0, 23); Store.save() }
        }
        Muted("Normal alerts are held back and only listed in the Alerts tab. Urgent alerts still come through.")
    }
}

@Composable
private fun AboutPage() {
    PCard {
        Muted("Trend Target Ribbon is a Kotlin port of the Pine Script indicator \"Trend Target Ribbon [BOSWaves]\" by BOSWaves, used under the Mozilla Public License 2.0 (mozilla.org/MPL/2.0).", 12)
        Muted("Isotropic Trend Lines is an approximation written from the description of the \"Smart Trader, Episode 06\" script, so it can differ from the TradingView version.", 12)
        Muted("Key levels were written for Wickwatch: swing highs and lows that sit at nearly the same price are grouped, and a group with enough swings becomes a level. It shows where price reacted before. It does not predict.", 12)
        Muted("Prices come from the public Deriv and Binance APIs.", 12)
        Muted("Alerts are for information only. They are not trading advice and the app does not place trades.", 12)
    }
}
