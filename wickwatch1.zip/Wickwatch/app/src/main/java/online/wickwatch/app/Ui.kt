package online.wickwatch.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The look of the app. It starts black and white. The person can pick another theme and their own candle colours.
 * mode: 0 black, 1 white, 2 navy and teal.
 */
object Brand {
    var mode by mutableStateOf(0)
    var candleUp by mutableStateOf(0L)        // 0 = the theme's own colour
    var candleDown by mutableStateOf(0L)
    var hollowUp by mutableStateOf(false)

    val dark: Boolean get() = mode != 1
    val Bg: Color get() = when (mode) { 1 -> Color(0xFFFFFFFF); 2 -> Color(0xFF0B1220); else -> Color(0xFF000000) }
    val Panel: Color get() = when (mode) { 1 -> Color(0xFFF5F5F5); 2 -> Color(0xFF121B2D); else -> Color(0xFF0D0D0D) }
    val Elevated: Color get() = when (mode) { 1 -> Color(0xFFEDEDED); 2 -> Color(0xFF172238); else -> Color(0xFF161616) }
    val Grid: Color get() = when (mode) { 1 -> Color(0xFFE5E5E5); 2 -> Color(0xFF1B2640); else -> Color(0xFF1A1A1A) }
    val Border: Color get() = when (mode) { 1 -> Color(0xFFDADADA); 2 -> Color(0xFF1F2A44); else -> Color(0xFF262626) }
    val Text: Color get() = when (mode) { 1 -> Color(0xFF000000); 2 -> Color(0xFFE6EDF7); else -> Color(0xFFFFFFFF) }
    val Muted: Color get() = when (mode) { 1 -> Color(0xFF6B6B6B); 2 -> Color(0xFF8A98B3); else -> Color(0xFF9A9A9A) }
    val Primary: Color get() = when (mode) { 1 -> Color(0xFF000000); 2 -> Color(0xFF14B8A6); else -> Color(0xFFFFFFFF) }
    val Alert: Color get() = if (mode == 1) Color(0xFFE69500) else Color(0xFFFFB020)
    val Good: Color get() = if (mode == 1) Color(0xFF15803D) else Color(0xFF22C55E)
    val Danger: Color get() = if (mode == 1) Color(0xFFDC2638) else Color(0xFFF2495C)

    private val defUp: Color get() = when (mode) { 1 -> Color(0xFF000000); 2 -> Color(0xFF22C55E); else -> Color(0xFFFFFFFF) }
    private val defDown: Color get() = when (mode) { 1 -> Color(0xFF000000); 2 -> Color(0xFFF2495C); else -> Color(0xFF7A7A7A) }
    val Up: Color get() = if (candleUp != 0L) Color(candleUp) else defUp
    val Down: Color get() = if (candleDown != 0L) Color(candleDown) else defDown
    val HollowUp: Boolean get() = if (candleUp != 0L) hollowUp else mode == 1
}

fun colorLong(c: Color): Long = c.toArgb().toLong() and 0xFFFFFFFFL

class CandlePreset(val name: String, val up: Long, val down: Long, val hollow: Boolean)

val CANDLE_PRESETS: List<CandlePreset> = listOf(
    CandlePreset("Mono", 0L, 0L, false),
    CandlePreset("Classic", 0xFF22C55E, 0xFFF2495C, false),
    CandlePreset("Hollow green", 0xFF22C55E, 0xFFF2495C, true),
    CandlePreset("Blue and orange", 0xFF2962FF, 0xFFFF9800, false),
    CandlePreset("Teal and pink", 0xFF14B8A6, 0xFFF472B6, false),
    CandlePreset("Yellow and purple", 0xFFFACC15, 0xFF8B5CF6, false),
)

val SWATCHES: List<Long> = listOf(
    0xFFFFFFFF, 0xFFBDBDBD, 0xFF7A7A7A, 0xFF000000, 0xFF22C55E, 0xFF16A34A, 0xFFF2495C, 0xFFDC2638,
    0xFF2962FF, 0xFF38BDF8, 0xFF14B8A6, 0xFFFFB020, 0xFFFF9800, 0xFF8B5CF6, 0xFFF472B6, 0xFFFACC15,
)

@Composable
fun PCard(modifier: Modifier = Modifier, border: Color = Brand.Border, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Brand.Panel, contentColor = Brand.Text),
        border = BorderStroke(1.dp, border),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
fun H(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Brand.Text, modifier = Modifier.padding(top = 6.dp))
}

@Composable
fun Muted(text: String, size: Int = 12) {
    Text(text, color = Brand.Muted, fontSize = size.sp)
}

@Composable
fun Mono(text: String, size: Int = 14, color: Color = Brand.Text, bold: Boolean = false) {
    Text(text, color = color, fontSize = size.sp, fontFamily = FontFamily.Monospace, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
}

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, modifier = modifier, shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Brand.Primary, contentColor = Brand.Bg, disabledContainerColor = Brand.Border, disabledContentColor = Brand.Muted),
    ) { Text(text, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun SecondaryButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick, enabled = enabled, modifier = modifier, shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Brand.Border),
    ) { Text(text, color = if (enabled) Brand.Text else Brand.Muted, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun DangerButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick, modifier = modifier, shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Brand.Danger, contentColor = Color.White),
    ) { Text(text, fontWeight = FontWeight.SemiBold) }
}

/** A number box that accepts decimals. */
@Composable
fun DecField(label: String, value: Double, modifier: Modifier = Modifier, onChange: (Double) -> Unit) {
    var text by remember { mutableStateOf(if (value % 1.0 == 0.0) value.toInt().toString() else value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { t ->
            val clean = t.replace(',', '.').filter { it.isDigit() || it == '.' }.take(10)
            text = clean
            clean.toDoubleOrNull()?.let(onChange)
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier,
    )
}

@Composable
fun IntField(label: String, value: Int, modifier: Modifier = Modifier, onChange: (Int) -> Unit) {
    var text by remember { mutableStateOf(value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { t ->
            val clean = t.filter { it.isDigit() }.take(4)
            text = clean
            clean.toIntOrNull()?.let(onChange)
        },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier,
    )
}

/** Rows of colour dots to pick from. [selected] is an ARGB long, 0 for none. */
@Composable
fun SwatchRow(selected: Long, onPick: (Long) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (row in SWATCHES.chunked(8)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (c in row) {
                    Box(
                        Modifier.size(32.dp).clip(CircleShape).background(Color(c))
                            .border(if (selected == c) 3.dp else 1.dp, if (selected == c) Brand.Alert else Brand.Border, CircleShape)
                            .clickable { onPick(c) },
                    )
                }
            }
        }
    }
}

private val GROUP_ORDER = listOf("Forex", "Metals", "Crypto", "Stock indices", "Synthetic indices")

/** A list of every market, grouped, to pick one from. */
@Composable
fun MarketPicker(onPick: (Market) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Elevated,
        title = { Text("Choose a market", color = Brand.Text) },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                for (g in GROUP_ORDER) {
                    val list = MARKETS.filter { it.grp == g }
                    if (list.isEmpty()) continue
                    item {
                        Text(g, fontWeight = FontWeight.Bold, color = Brand.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 2.dp))
                    }
                    items(list) { m ->
                        Text(
                            m.name + (if (m.src == 'b') "  \u00B7 Binance" else "  \u00B7 Deriv"),
                            color = Brand.Text,
                            modifier = Modifier.fillMaxWidth().clickable { onPick(m) }.padding(vertical = 10.dp),
                            fontSize = 15.sp,
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Brand.Text) } },
    )
}
