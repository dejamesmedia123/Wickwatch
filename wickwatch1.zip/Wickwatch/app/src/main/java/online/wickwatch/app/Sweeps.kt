package online.wickwatch.app

import kotlin.math.abs
import kotlin.math.max

/*
 * Sweep engine. Port of tools/sweep/sweep.py (same rules, tested there).
 *
 *   A marked level: a swing high/low (body edge), or a broken swing that has flipped.
 *   Price comes at it from one side, a wick pokes THROUGH it, then a candle closes back on the side price came from.
 *   The wick decides the side: wick above = SELL, wick below = BUY.
 *   The way back to the level must be calmer than the move that left it (no fast knife into the level).
 *   Stop just beyond the wick tip. Target = a major swing on the other side, at least minRR.
 *   Closed candles only; buys are the same code on mirrored prices.
 *   entryMode 0: limit at the level (needs price to return, otherwise "not taken"). entryMode 1: enter at the close back through the level.
 */
private class Lv(val level: Double, val kind: String, val born: Int, val dep: Int, val origin: Int) {
    var state = 0          // 0 armed, 1 poking, 2 dead
    var ps = 0
    var ph = 0.0
}

object SweepEngine {
    internal fun atrWilder(cs: List<Candle>, n: Int): DoubleArray {
        val out = DoubleArray(cs.size)
        var prev = Double.NaN
        for (i in cs.indices) {
            val tr = if (i == 0) cs[i].h - cs[i].l else max(cs[i].h - cs[i].l, max(abs(cs[i].h - cs[i - 1].c), abs(cs[i].l - cs[i - 1].c)))
            prev = if (prev.isNaN()) tr else (prev * (n - 1) + tr) / n
            out[i] = prev
        }
        return out
    }

    fun scan(cs: List<Candle>, p: SetupParams = SetupParams()): SetupScan {
        val n = cs.size
        val atr = atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 60) return SetupScan(emptyList(), n, last)
        val all = ArrayList<Setup>()
        if (p.dirMask and 1 != 0) all.addAll(scanDir(cs, atr, p, true))
        if (p.dirMask and 2 != 0) all.addAll(scanDir(cs, atr, p, false))
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    private fun scanDir(cs: List<Candle>, a: DoubleArray, p: SetupParams, short: Boolean): List<Setup> {
        val n = cs.size
        // a buy is a sell on mirrored prices
        val o = DoubleArray(n) { if (short) cs[it].o else -cs[it].o }
        val h = DoubleArray(n) { if (short) cs[it].h else -cs[it].l }
        val l = DoubleArray(n) { if (short) cs[it].l else -cs[it].h }
        val c = DoubleArray(n) { if (short) cs[it].c else -cs[it].c }
        val body = DoubleArray(n) { abs(c[it] - o[it]) }
        val ema = DoubleArray(n)
        val ek = 2.0 / (p.trendLen + 1)
        ema[0] = c[0]
        for (q in 1 until n) ema[q] = ema[q - 1] + ek * (c[q] - ema[q - 1])
        fun px(x: Double): Double = if (short) x else -x

        val levels = ArrayList<Lv>()
        val pend = ArrayList<DoubleArray>()          // [pivot idx, level] of swing lows waiting to be broken
        val tgtIdx = ArrayList<Int>()
        val tgtVal = ArrayList<Double>()
        val out = ArrayList<Setup>()
        val span = p.pivotSpan

        fun calmReturn(lv: Lv, i: Int): Boolean {
            val d0 = lv.dep
            if (i - 1 <= d0) return false
            var ext = d0
            for (q in d0 until i) if (l[q] < l[ext]) ext = q
            if (ext <= d0 || ext >= i - p.minPullBars) return false
            if (lv.level - l[ext] < p.minLegAtr * a[ext]) return false
            var s1 = 0.0
            for (q in d0..ext) s1 += body[q]
            val dep = s1 / (ext - d0 + 1)
            var s2 = 0.0
            for (q in ext + 1 until i) s2 += body[q]
            val app = s2 / max(1, i - ext - 1)
            return app <= p.pullRatio * dep
        }

        fun finish(lv: Lv, i: Int) {
            val stop = lv.ph + p.sweepStopBufAtr * a[i]
            val entry = if (p.entryMode == 0) lv.level else c[i]
            val risk = stop - entry
            if (risk <= 0) return
            var best = Double.NaN
            for (q in tgtIdx.indices) {
                val v = tgtVal[q]
                if (i - tgtIdx[q] > 400 || v >= entry) continue
                if ((entry - v) / risk >= p.minRR && (best.isNaN() || v > best)) best = v
            }
            if (best.isNaN()) return
            val s = Setup(if (short) 1 else -1, lv.origin, cs[lv.origin].t)
            s.kind = lv.kind
            s.valid = true
            s.proximal = px(lv.level)
            s.distal = px(lv.ph)
            s.entry = px(entry)
            s.stop = px(stop)
            s.target = px(best)
            s.risk = risk
            s.rr = (entry - best) / risk
            s.lockIdx = i
            s.lockT = cs[i].t
            s.touchIdx = lv.ps
            var k0 = i + 1
            if (p.entryMode == 0) {
                var fill = -1
                var k = i + 1
                while (k < n && k <= i + p.waitBars) {
                    if (l[k] <= best) break
                    if (h[k] >= entry) { fill = k; break }
                    k += 1
                }
                if (fill < 0) {
                    if (i + p.waitBars < n) { s.state = ST_DEAD; s.why = "price never returned to the level"; s.endIdx = i + p.waitBars; s.endT = cs[s.endIdx].t }
                    else s.state = ST_WAITING
                    out.add(s)
                    return
                }
                s.fillIdx = fill
                s.fillT = cs[fill].t
                if (h[fill] >= stop) {
                    s.state = ST_LOSS; s.endIdx = fill; s.endT = cs[fill].t; s.result = -1.0
                    out.add(s)
                    return
                }
                k0 = fill + 1
            } else {
                s.fillIdx = i
                s.fillT = cs[i].t
            }
            s.state = ST_ACTIVE
            var k = k0
            while (k < n) {
                if (h[k] >= stop) { s.state = ST_LOSS; s.endIdx = k; s.endT = cs[k].t; s.result = -1.0; break }
                if (l[k] <= best) { s.state = ST_WIN; s.endIdx = k; s.endT = cs[k].t; s.result = s.rr; break }
                if (k - k0 > p.maxActiveBars) { s.state = ST_FLAT; s.endIdx = k; s.endT = cs[k].t; s.result = (entry - c[k]) / risk; break }
                k += 1
            }
            out.add(s)
        }

        for (i in 0 until n) {
            for (lv in levels) {
                if (lv.state == 2) continue
                if (i - lv.born > p.lookback) { lv.state = 2; continue }
                if (lv.state == 0) {
                    if (h[i] > lv.level + p.pokeMinAtr * a[i]) {
                        if (c[i - 1] >= lv.level || !calmReturn(lv, i)) { lv.state = 2; continue }
                        lv.state = 1
                        lv.ps = i
                        lv.ph = h[i]
                    } else continue
                }
                if (lv.state == 1) {
                    lv.ph = max(lv.ph, h[i])
                    if (lv.ph - lv.level > p.maxPokeAtr * a[i] || i - lv.ps + 1 > p.maxPokeBars) { lv.state = 2; continue }
                    if (c[i] < lv.level) {
                        lv.state = 2
                        val withTrend = !p.trendFilter || (i >= p.trendSlopeBars && ema[i] < ema[i - p.trendSlopeBars] && c[i] < ema[i] + p.trendTolAtr * a[i])
                        if (withTrend) finish(lv, i)
                    }
                }
            }
            levels.removeAll { it.state == 2 }

            val j = i - span
            if (j - span >= 0) {
                var isH = true
                var isL = true
                for (q in j - span until j) { if (h[q] >= h[j]) isH = false; if (l[q] <= l[j]) isL = false }
                for (q in j + 1..j + span) { if (h[q] > h[j]) isH = false; if (l[q] < l[j]) isL = false }
                if (isH) levels.add(Lv(max(o[j], c[j]), "sweep", i, j + 1, j))
                if (isL) pend.add(doubleArrayOf(j.toDouble(), minOf(o[j], c[j])))
            }
            val jt = i - p.tgtSpan
            if (jt - p.tgtSpan >= 0) {
                var ok = true
                for (q in jt - p.tgtSpan until jt) if (l[q] <= l[jt]) ok = false
                for (q in jt + 1..jt + p.tgtSpan) if (l[q] < l[jt]) ok = false
                if (ok) { tgtIdx.add(jt); tgtVal.add(l[jt]) }
            }
            val pit = pend.iterator()
            while (pit.hasNext()) {
                val pv = pit.next()
                val jj = pv[0].toInt()
                if (i - jj > p.lookback) { pit.remove(); continue }
                if (i > jj + span && c[i] < pv[1] - 0.2 * a[i]) {
                    pit.remove()
                    levels.add(Lv(pv[1], "flip", i, i, jj))
                }
            }
        }
        return out
    }
}
