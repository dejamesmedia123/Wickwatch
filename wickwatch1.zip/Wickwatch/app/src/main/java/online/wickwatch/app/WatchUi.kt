package online.wickwatch.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.roundToInt

private val SORTS = listOf("Manual", "% high to low", "% low to high", "A to Z")

/** The small price line in a Watchlist row. */
@Composable
private fun Spark(values: FloatArray, up: Boolean, modifier: Modifier = Modifier) {
    val col = if (up) Brand.Good else Brand.Danger
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        var lo = values[0]
        var hi = values[0]
        for (v in values) {
            if (v < lo) lo = v
            if (v > hi) hi = v
        }
        val span = if (hi - lo < 1e-9f) 1f else hi - lo
        val path = Path()
        for (i in values.indices) {
            val x = size.width * i / (values.size - 1)
            val y = size.height - (values[i] - lo) / span * size.height
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, col, style = Stroke(width = 1.6.dp.toPx()))
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onOk: (String) -> Unit, onCancel: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = Brand.Elevated,
        title = { Text(title, color = Brand.Text) },
        text = { OutlinedTextField(value = text, onValueChange = { if (it.length <= 24) text = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { if (text.isNotBlank()) onOk(text.trim()) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}

private fun removeItem(ctx: android.content.Context, w: WatchItem) {
    Store.watch = Store.watch.filter { it.id != w.id }
    Store.save()
    Watcher.refresh()
    if (!Watcher.hasWork() && WatchService.running) WatchService.stop(ctx)
}

@Composable
fun WatchlistScreen(onOpenChart: (String) -> Unit) {
    val ctx = LocalContext.current
    var sort by remember { mutableStateOf(0) }
    var editing by remember { mutableStateOf(false) }
    var newList by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val saved = remember { mutableStateMapOf<String, Quote>() }
    val items = Store.watch

    // last known prices from the saved candles, for markets the watcher is not following
    LaunchedEffect(Store.lists) {
        for (w in Store.allWatch()) {
            val k = Quotes.key(w.key, w.tf)
            if (saved.containsKey(k)) continue
            val m = marketByKey(w.key) ?: continue
            val q = withContext(Dispatchers.IO) { Quotes.fromSaved(m, w.tf) }
            if (q != null) saved[k] = q
        }
    }

    fun quoteOf(w: WatchItem): Quote? = Quotes.live[Quotes.key(w.key, w.tf)] ?: saved[Quotes.key(w.key, w.tf)]

    val shown = when (sort) {
        1 -> items.sortedByDescending { quoteOf(it)?.pct ?: -1e9 }
        2 -> items.sortedBy { quoteOf(it)?.pct ?: 1e9 }
        3 -> items.sortedBy { marketByKey(it.key)?.name ?: it.key }
        else -> items
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("Watchlist", "The markets the background watcher follows. Swipe a row to the left to remove it.")

        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Store.lists.forEachIndexed { i, l ->
                ChoiceChip(l.name, i == Store.activeList) {
                    Store.activeList = i
                    Store.save()
                    editing = false
                }
            }
            IconBtn("plus", size = 36.dp) { if (Store.lists.size < 8) newList = true }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            SORTS.forEachIndexed { i, n -> ChoiceChip(n, sort == i) { sort = i; if (i != 0) editing = false } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (sort == 0 && items.size > 1) SecondaryButton(if (editing) "Done" else "Reorder", Modifier) { editing = !editing }
            SecondaryButton("Rename list", Modifier) { rename = true }
            if (Store.lists.size > 1) SecondaryButton("Delete list", Modifier) { confirmDelete = true }
        }

        if (items.isEmpty()) Muted("Nothing in this list yet. Add a market below.", 13)
        Column {
            for (w in shown) {
                val m = marketByKey(w.key)
                val q = quoteOf(w)
                var dx by remember(w.id) { mutableStateOf(0f) }
                Box(Modifier.fillMaxWidth()) {
                    Box(Modifier.matchParentSize().background(Brand.Danger), contentAlignment = Alignment.CenterEnd) {
                        Box(Modifier.padding(end = 18.dp)) { WIcon("trash", size = 22.dp, tint = androidx.compose.ui.graphics.Color.White) }
                    }
                    Row(
                        Modifier.fillMaxWidth()
                            .offset { IntOffset(dx.roundToInt(), 0) }
                            .background(Brand.Bg)
                            .pointerInput(w.id, editing) {
                                if (editing || Expiry.locked) return@pointerInput
                                detectHorizontalDragGestures(
                                    onDragEnd = {
                                        if (dx < -size.width * 0.35f) removeItem(ctx, w) else dx = 0f
                                    },
                                    onDragCancel = { dx = 0f },
                                ) { _, d -> dx = (dx + d).coerceIn(-size.width.toFloat(), 0f) }
                            }
                            .clickable(enabled = !editing) {
                                Store.chartTf = w.tf
                                onOpenChart(w.key)
                            }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(40.dp).clip(CircleShape).background(Brand.Elevated).border(1.dp, Brand.Border, CircleShape), contentAlignment = Alignment.Center) {
                            Text((m?.name ?: w.key).take(2).uppercase(), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Text)
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(m?.name ?: w.key, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Brand.Text, maxLines = 1)
                            Muted(tfLabel(w.tf) + "  \u00B7  " + (if (m?.src == 'b') "Binance" else "Deriv"), 12)
                        }
                        if (q != null && q.spark.size > 1) Spark(q.spark, q.change >= 0, Modifier.width(60.dp).height(26.dp))
                        Column(Modifier.padding(start = 10.dp), horizontalAlignment = Alignment.End) {
                            if (q != null && m != null) {
                                Mono(fp(q.price, m.dec), 16, Brand.Text, true)
                                Mono((if (q.pct >= 0) "+" else "") + fp(q.pct, 2) + "%", 12, if (q.change >= 0) Brand.Good else Brand.Danger)
                            } else {
                                Muted("-", 14)
                            }
                        }
                        if (editing) {
                            val idx = items.indexOfFirst { it.id == w.id }
                            Column {
                                IconBtn("down", size = 30.dp, enabled = idx < items.size - 1) { moveItem(idx, idx + 1) }
                                IconBtn("down", size = 30.dp, enabled = idx > 0) { moveItem(idx, idx - 1) }
                            }
                        }
                    }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Brand.Border))
            }
        }
        if (Store.allWatch().isNotEmpty() && !WatchService.running) {
            PrimaryButton("Start watching", Modifier.fillMaxWidth()) {
                Store.watching = true
                Store.save()
                WatchService.start(ctx)
            }
        }

        H("Add markets")
        PCard { MarketChooser() }
        Muted("Alerts for closed candles need the candle to finish, so on 1h a signal can take up to an hour to appear. Use 5m or 15m for faster alerts. Changes apply to a running watcher straight away.", 12)
        Text("", Modifier.padding(bottom = 12.dp))
    }

    if (newList) NameDialog("New list", "", { n ->
        Store.lists = Store.lists + WatchList(UUID.randomUUID().toString(), n, emptyList())
        Store.activeList = Store.lists.size - 1
        Store.save()
        newList = false
    }, { newList = false })
    if (rename) NameDialog("Rename list", Store.lists.getOrNull(Store.activeList)?.name ?: "", { n ->
        Store.lists = Store.lists.mapIndexed { i, l -> if (i == Store.activeList) l.copy(name = n) else l }
        Store.save()
        rename = false
    }, { rename = false })
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        containerColor = Brand.Elevated,
        title = { Text("Delete this list?", color = Brand.Text) },
        text = { Text("The markets in it stop being watched unless they are in another list.", color = Brand.Muted) },
        confirmButton = {
            TextButton(onClick = {
                Store.lists = Store.lists.filterIndexed { i, _ -> i != Store.activeList }
                Store.activeList = 0
                Store.save()
                Watcher.refresh()
                if (!Watcher.hasWork() && WatchService.running) WatchService.stop(ctx)
                confirmDelete = false
            }) { Text("Delete") }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
    )
}

private fun moveItem(from: Int, to: Int) {
    val l = Store.watch.toMutableList()
    if (from !in l.indices || to !in l.indices) return
    val x = l.removeAt(from)
    l.add(to, x)
    Store.watch = l
    Store.save()
}
