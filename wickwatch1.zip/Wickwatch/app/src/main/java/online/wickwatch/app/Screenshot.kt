package online.wickwatch.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.ui.graphics.toArgb
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Puts the "by Wickwatch" marks, the chart title and a footer on a rendered chart picture. [chartH] is the height of the chart part. */
fun stampScreenshot(bmp: Bitmap, chartH: Int, title: String, priceLine: String, up: Boolean, density: Float) {
    val c = android.graphics.Canvas(bmp)
    val w = bmp.width.toFloat()
    val h = chartH.toFloat()
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    // chart title, top left
    p.typeface = Typeface.DEFAULT_BOLD
    p.color = Brand.Text.toArgb()
    p.textSize = 14f * density
    c.drawText(title, 10f * density, 22f * density, p)
    p.typeface = Typeface.DEFAULT
    p.textSize = 12f * density
    p.color = (if (up) Brand.Up else Brand.Down).toArgb()
    c.drawText(priceLine, 10f * density, 40f * density, p)
    // big faint mark across the middle
    p.typeface = Typeface.DEFAULT_BOLD
    p.textAlign = Paint.Align.CENTER
    p.color = android.graphics.Color.argb(34, 128, 128, 128)
    p.textSize = w * 0.15f
    c.save()
    c.rotate(-25f, w / 2f, h / 2f)
    c.drawText("Wickwatch", w / 2f, h / 2f, p)
    c.restore()
    // footer: who made it and when
    p.textAlign = Paint.Align.LEFT
    p.color = Brand.Text.toArgb()
    p.textSize = 16f * density
    c.drawText("by Wickwatch", 12f * density, h + 24f * density, p)
    p.typeface = Typeface.DEFAULT
    p.textAlign = Paint.Align.RIGHT
    p.color = Brand.Muted.toArgb()
    p.textSize = 11f * density
    val df = SimpleDateFormat("MMM d, yyyy HH:mm", Locale.US)
    df.timeZone = TimeZone.getTimeZone("UTC")
    c.drawText(df.format(Date()) + " UTC", w - 12f * density, h + 23f * density, p)
}

/** Saves the picture to Pictures/Wickwatch in the gallery. Returns where it went, or null when it could not be saved. */
fun saveScreenshot(ctx: Context, bmp: Bitmap, name: String): Uri? {
    return try {
        val v = ContentValues()
        v.put(MediaStore.Images.Media.DISPLAY_NAME, name)
        v.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        if (Build.VERSION.SDK_INT >= 29) {
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Wickwatch")
            v.put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
        ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        if (Build.VERSION.SDK_INT >= 29) {
            val done = ContentValues()
            done.put(MediaStore.Images.Media.IS_PENDING, 0)
            ctx.contentResolver.update(uri, done, null, null)
        }
        uri
    } catch (e: Exception) {
        null
    }
}

fun shareScreenshot(ctx: Context, uri: Uri) {
    try {
        val send = Intent(Intent.ACTION_SEND)
        send.type = "image/png"
        send.putExtra(Intent.EXTRA_STREAM, uri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Share chart"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not open sharing", Toast.LENGTH_SHORT).show()
    }
}

fun toast(ctx: Context, text: String) {
    Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()
}
