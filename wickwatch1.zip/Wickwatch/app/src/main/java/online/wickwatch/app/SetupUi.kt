package online.wickwatch.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val STAMP = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())

private fun stamp(t: Long): String = if (t <= 0L) "-" else STAMP.format(Date(t * 1000L))

private fun entryHeader(si: Int): String {
    if (!SetupEngine.usesLimit(si, Store.setupMode)) return "close of the signal candle"
    if (Store.setupReverse) return "stop order at the same price (reversed)"
    return when (si) { 8 -> "limit at the open and close level"; 3 -> "limit at the order block"; 5 -> "limit at the middle of the block"; else -> "limit at the level" }
}

private fun entryModeName(m: Int): String = if (m == 0) "limit at the level" else "close back through the level"

val SETUP_SHORT = listOf("Sweep", "Trend break", "Sweep + trend", "Ascendis", "Ribbon MSNR", "Order block", "CRT", "Alchemist MSNR", "OML")
/** The order they are listed in. */
val SETUP_ORDER = listOf(0, 2, 1, 3, 4, 5, 6, 7, 8)

private val STRATEGY_NAMES = listOf("Sweep (against the move)", "Trend break", "Sweep with trend", "Ascendis (order block)", "Ribbon MSNR (flip levels with the trend)", "Order block with the trend", "CRT (sweep of the last big candle)", "Alchemist MSNR (dynamic target)", "OML (open and close level)")

private val CSV_TIME = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }

/** Candles as CSV (UTC time, open, high, low, close) so they can be pasted into a chat or a script. */
fun candlesCsv(cs: List<Candle>): String {
    val sb = StringBuilder("time,open,high,low,close\n")
    for (c in cs) sb.append(CSV_TIME.format(Date(c.t * 1000L))).append(',').append(c.o).append(',').append(c.h).append(',').append(c.l).append(',').append(c.c).append('\n')
    return sb.toString()
}

/** What the finder produced, one line per setup, to compare with the trades you took. */
fun setupsCsv(sc: SetupScan): String {
    val sb = StringBuilder("signal_time_utc,side,kind,entry,stop,target,rr,outcome,result_R\n")
    for (s in sc.setups) {
        val out = when (s.state) { ST_WIN -> "WIN"; ST_LOSS -> "LOSS"; ST_FLAT -> "FLAT"; ST_DEAD -> "NOTFILLED"; ST_WAITING -> "WAITING"; else -> "OPEN" }
        sb.append(CSV_TIME.format(Date(s.lockT * 1000L))).append(',').append(s.side).append(',').append(s.kind).append(',').append(s.entry).append(',').append(s.stop)
            .append(',').append(s.target).append(',').append(fp(s.rr, 2)).append(',').append(out).append(',').append(fp(s.result, 2)).append('\n')
    }
    return sb.toString()
}

private fun signedR(r: Double): String = (if (r >= 0) "+" else "") + fp(r, 1) + "R"

/** The small card on the chart: last 10 result and win rate. Tap it to open the full dashboard. */
@Composable
fun SetupChip(sc: SetupScan, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val st = sc.statsLast(10)
    val waiting = sc.waiting().size
    val text = if (st.total == 0) "SETUPS  none finished yet" else "SETUPS  " + st.wins + "W " + st.losses + "L  " + fp(st.winRate, 0) + "%"
    Row(
        modifier.clip(RoundedCornerShape(10.dp)).background(Brand.Elevated.copy(alpha = 0.95f)).border(1.dp, Brand.Border, RoundedCornerShape(10.dp))
            .clickable { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(text, color = Brand.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        if (waiting > 0) Text(waiting.toString() + " waiting", color = Brand.Alert, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** The dashboard: win rate of the last 10 finished setups, what is open now, and the list. */
@Composable
fun SetupBoardSheet(sc: SetupScan?, market: Market, tf: Int, candles: List<Candle>, backfillMsg: String, onBackfill: () -> Unit, onDismiss: () -> Unit) {
    val clip = LocalClipboardManager.current
    var copied by remember { mutableStateOf("") }
    var cmp by remember { mutableStateOf<List<SetupStats>>(emptyList()) }
    // the same candles, every strategy, so you can see which one pays most
    LaunchedEffect(candles.size, Store.setupReverse, Store.setupRR, Store.setupCost, Store.setupMode, Store.setupImpulse, Store.setupDirs, Store.setupBias) {
        cmp = withContext(Dispatchers.Default) {
            (0..8).map { i ->
                val r = try { SetupEngine.scan(candles, Store.setupParams(i)) } catch (e: Exception) { null }
                if (r == null) SetupStats(0, 0, 0.0) else r.stats(r.setups)
            }
        }
    }
    Sheet(onDismiss = onDismiss) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Setup finder", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Text)
            Muted("build 3c  |  " + market.name + " " + tfLabel(tf) + "  |  " + STRATEGY_NAMES[Store.setupStrategy.coerceIn(0, 8)] + "  |  entry: " + entryHeader(Store.setupStrategy) + "  |  min " + fp(Store.setupRR, 1) + "R", 12)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ChoiceChip("Sweep", Store.setupStrategy == 0) { Store.setupStrategy = 0; Store.save() }
                ChoiceChip("Sweep + trend", Store.setupStrategy == 2) { Store.setupStrategy = 2; Store.save() }
                ChoiceChip("Trend break", Store.setupStrategy == 1) { Store.setupStrategy = 1; Store.save() }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ChoiceChip("Ascendis (order block)", Store.setupStrategy == 3) { Store.setupStrategy = 3; Store.save() }
                ChoiceChip("CRT", Store.setupStrategy == 6) { Store.setupStrategy = 6; Store.save() }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ChoiceChip("Ribbon MSNR", Store.setupStrategy == 4) { Store.setupStrategy = 4; Store.save() }
                ChoiceChip("Order block", Store.setupStrategy == 5) { Store.setupStrategy = 5; Store.save() }
                ChoiceChip("Alchemist", Store.setupStrategy == 7) { Store.setupStrategy = 7; Store.save() }
            ChoiceChip("OML", Store.setupStrategy == 8) { Store.setupStrategy = 8; Store.save() }
                ChoiceChip("OML", Store.setupStrategy == 8) { Store.setupStrategy = 8; Store.save() }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                ChoiceChip(if (Store.setupReverse) "REVERSED: opposite trades" else "Reverse (do the opposite)", Store.setupReverse) { Store.setupReverse = !Store.setupReverse; Store.save() }
            }
            if (Store.setupReverse) Muted("Every setup is flipped: same entry price, the other way, with the same stop size and the same target size (a 5R buy with a 1R stop becomes a 5R sell with a 1R stop). Each reversed trade is played again on the candles, so its win or loss is its own. Where the original was a limit order the reversed trade is a stop order at the same price.", 12)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryButton("Copy candles CSV") { clip.setText(AnnotatedString(candlesCsv(candles.takeLast(1500)))); copied = "Copied the last " + Math.min(1500, candles.size) + " candles" }
                SecondaryButton("Copy setups") { if (sc != null) { clip.setText(AnnotatedString(setupsCsv(sc))); copied = "Copied " + sc.setups.size + " setups" } }
            }
            SecondaryButton("Load older candles (more history)") { onBackfill() }
            if (copied.isNotEmpty()) Muted(copied, 12)
            if (backfillMsg.isNotEmpty()) Muted(backfillMsg, 12)
            if (sc == null) {
                Muted("Still loading candles.", 13)
                return@Column
            }
            val last = sc.lastResolved(10)
            val st = sc.stats(last)
            val all = sc.stats(sc.setups)

            PCard {
                Text("LAST " + last.size + " FINISHED SETUPS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Brand.Muted)
                if (last.isEmpty()) {
                    Text("No finished setup in the saved candles yet.", color = Brand.Text, fontSize = 14.sp)
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Mono(fp(st.winRate, 0) + "%", 30, if (st.avgR >= 0) Brand.Good else Brand.Text, true)
                            Muted("win rate (green only if the average trade makes money)", 12)
                        }
                        Column {
                            Mono(st.wins.toString() + "W  " + st.losses + "L", 18, Brand.Text, true)
                            Muted("wins / losses", 12)
                        }
                        Column {
                            Mono(signedR(st.avgR), 18, if (st.avgR >= 0) Brand.Good else Brand.Danger, true)
                            Muted("average per trade", 12)
                        }
                    }
                    // one small box per result, oldest to newest
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (s in last.reversed()) {
                            val win = s.state == ST_WIN
                            Text(
                                if (win) "W" else "L", color = Brand.Bg, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(if (win) Brand.Good else Brand.Danger).padding(horizontal = 8.dp, vertical = 3.dp),
                            )
                        }
                    }
                }
                if (all.total < 10) Muted("Only " + all.total + " finished setups so far. Tap Load older candles to go further back.", 12)
                Muted("All " + all.total + " finished setups in " + sc.n + " saved candles: " + all.wins + "W " + all.losses + "L" + (if (all.total > 0) " (" + fp(all.winRate, 0) + "%, avg " + signedR(all.avgR) + ")" else ""), 12)
                val avgRr = sc.avgRR(sc.setups)
                if (avgRr > 0) Muted("At an average of " + fp(avgRr, 1) + "R you need " + fp(100.0 / (1.0 + avgRr), 0) + "% wins just to break even, a little more once costs are counted.", 12)
                if (all.flats > 0) Muted(all.flats.toString() + " trades ran too long and were closed at the last price. They are counted in the average.", 12)
                val one = sc.statsSerial(sc.setups)
                if (one.trades > 0) Muted("One trade at a time (a setup that starts while another trade is open is skipped): " + one.wins + "W " + one.losses + "L, total " + signedR(one.sumR) + ", avg " + signedR(one.avgR) + ".", 12)
            }

            PCard {
                Text("WHICH PAYS MOST (all " + sc.n + " saved candles)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Brand.Muted)
                if (cmp.isEmpty()) Muted("Working it out...", 12)
                val best = cmp.indices.filter { cmp[it].total >= 10 }.maxByOrNull { cmp[it].sumR }
                for (i in cmp.indices) {
                    val x = cmp[i]
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(STRATEGY_NAMES[i] + (if (i == best && x.total > 0) "  (best)" else ""), color = if (i == best && x.total > 0) Brand.Good else Brand.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Mono(x.wins.toString() + "W " + x.losses + "L  " + fp(x.winRate, 0) + "%   total " + signedR(x.sumR) + "   avg " + signedR(x.avgR), 12, if (x.sumR >= 0) Brand.Good else Brand.Danger)
                }
                Muted("Total R is what each strategy would have made on these candles, in units of risk, after the trading cost. Only strategies with 10 or more finished trades can be marked best. This is a ranking of the PAST: the best of 9 is partly luck, so trust it only with 30+ trades and check it on newer candles. Setups can overlap here, see the one-trade-at-a-time line above for the single-account view.", 11)
            }

            val open = sc.setups.filter { it.state == ST_WAITING || it.state == ST_ACTIVE }.sortedByDescending { it.originIdx }
            PCard {
                Text("OPEN NOW", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Brand.Muted)
                if (open.isEmpty()) Text("No setup is waiting or running.", color = Brand.Text, fontSize = 14.sp)
                for (s in open) SetupLine(s, market.dec)
            }

            PCard {
                Text("HISTORY (NEWEST FIRST)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Brand.Muted)
                if (last.isEmpty()) Text("Nothing yet.", color = Brand.Text, fontSize = 14.sp)
                for (s in last) SetupLine(s, market.dec)
            }

            Muted(
                "A setup is listed when a wick pokes through a marked level (a swing high or low, or a broken swing now acting the other way) and a candle then closes back on the side price came from. " +
                    "A wick above gives a SELL, a wick below gives a BUY. The way back to the level must be calmer than the move that left it. The stop is just beyond the wick tip; " +
                    "the target is a major swing on the other side, at least " + fp(Store.setupRR, 1) + "R away. Results use closed candles. If one candle touches both the stop and the target, the stop is counted first. " +
                    "Trend break (with the trend): in a downtrend, after a lower high, a close below the last swing low is a SELL (an uptrend gives BUYs); the stop is just above the lower high, at most " + fp(3.0, 1) + " ATR away, and the target is " + fp(Store.setupRR, 1) + " times the risk. " +
                    "Spread and fees are not included. This is a record of what the rules would have done, not advice and not a promise.", 11,
            )
        }
    }
}

@Composable
private fun SetupLine(s: Setup, dec: Int) {
    val col = if (s.isLong) Brand.Good else Brand.Danger
    val status = when (s.state) {
        ST_WAITING -> "waiting for price to return"
        ST_ACTIVE -> "running"
        ST_WIN -> "target hit " + signedR(s.result)
        ST_LOSS -> "stopped -1R"
        ST_FLAT -> "closed after a long time"
        else -> "not taken (" + s.why + ")"
    }
    val statusCol = when (s.state) {
        ST_WIN -> Brand.Good
        ST_LOSS -> Brand.Danger
        ST_WAITING, ST_ACTIVE -> Brand.Alert
        else -> Brand.Muted
    }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(s.side, color = col, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(s.kind, color = Brand.Text, fontSize = 13.sp)
            Text(fp(s.rr, 1) + "R plan", color = Brand.Muted, fontSize = 13.sp)
            Text(stamp(if (s.fillT > 0L) s.fillT else s.lockT), color = Brand.Muted, fontSize = 12.sp)
        }
        Mono("entry " + fp(s.entry, dec) + "   stop " + fp(s.stop, dec) + "   target " + fp(s.target, dec), 12, Brand.Text)
        Text(status, color = statusCol, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Settings page for the setup finder. */
@Composable
fun SetupSettingsPage() {
    Muted(
        "The setup finder looks for a wick that pokes through a marked level and a candle that closes back. A wick above gives a SELL, a wick below a BUY. " +
            "The stop sits just beyond the wick tip and the target is a major swing on the other side. Turn it on from the chart's Analysis hub (Setup finder).", 12,
    )
    PCard {
        Text("Strategy", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Brand.Text)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip("Sweep", Store.setupStrategy == 0) { Store.setupStrategy = 0; Store.save() }
            ChoiceChip("Sweep + trend", Store.setupStrategy == 2) { Store.setupStrategy = 2; Store.save() }
            ChoiceChip("Trend break", Store.setupStrategy == 1) { Store.setupStrategy = 1; Store.save() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip("Ascendis (order block)", Store.setupStrategy == 3) { Store.setupStrategy = 3; Store.save() }
            ChoiceChip("CRT", Store.setupStrategy == 6) { Store.setupStrategy = 6; Store.save() }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip("Ribbon MSNR", Store.setupStrategy == 4) { Store.setupStrategy = 4; Store.save() }
            ChoiceChip("Order block", Store.setupStrategy == 5) { Store.setupStrategy = 5; Store.save() }
            ChoiceChip("Alchemist", Store.setupStrategy == 7) { Store.setupStrategy = 7; Store.save() }
        }
        Text("Trend for Ribbon MSNR and Order block", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Brand.Text)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip("Trend Ribbon", Store.setupTrendSrc == 1) { Store.setupTrendSrc = 1; Store.save() }
            ChoiceChip("200 EMA", Store.setupTrendSrc == 0) { Store.setupTrendSrc = 0; Store.save() }
        }
        IntField("CRT: big candle = this many chart candles", Store.setupCrtMult, Modifier.fillMaxWidth()) { Store.setupCrtMult = it.coerceIn(2, 60); Store.save() }
        Muted("Ribbon MSNR: levels are the peaks and valleys of the closing line. In a downtrend a fresh peak, or a valley that price closed through (RBS / SBR), is a sell zone; the first touch with a rejection candle is the entry, the stop is tight and the target is the minimum reward to risk. Order block: in a downtrend the last up candle before a strong drop that closes below the recent lows; limit sell at the middle of it, stop above it. Alchemist MSNR: marks A and V levels on closes (a bullish candle then a bearish one, and the reverse) plus RBS / SBR flips. In a downtrend (ribbon or 200 EMA) price touches a fresh A level without closing through it, then a bearish engulfing candle within 5 candles is the entry at its close; stop above the highest high since the touch (+0.1 ATR). The target is dynamic: the nearest fresh V level below that still pays at least the minimum reward to risk, so it is as high as the chart allows. CRT: the next big candle sweeps the high of the one before and closes back inside it; target the low of that candle (at least 1.5R). Buys are the mirror image.", 11)
        IntField("Ascendis bias multiple (0 = auto: 5, 9, 16, 40)", Store.setupBias, Modifier.fillMaxWidth()) { Store.setupBias = if (it < 2) 0 else it.coerceIn(2, 60); Store.save() }
        Muted("Sweep: a wick through a level, traded back the other way (against the move). Sweep + trend: the same, but sells only in a downtrend and buys only in an uptrend. Trend break: in a downtrend wait for a lower high, then sell when price closes below the last swing low (buys in an uptrend); stop just above the lower high, target the Minimum reward to risk below. Ascendis: the bias timeframe (chart x the number above) breaks structure, price returns into the order block that swept a high (a low for buys), then the chart timeframe breaks its last swing; entry is a limit at the small order block, stop just beyond the high made inside the zone, target the previous swing. The dashboard compares all four.", 11)
        Text("Entry style", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Brand.Text)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip("Close back through", Store.setupMode != 0) { Store.setupMode = 1; Store.save() }
            ChoiceChip("Limit at the level", Store.setupMode == 0) { Store.setupMode = 0; Store.save() }
        }
        Muted("This choice only changes Sweep and Sweep + trend. Close back through: enter at the close of the candle that comes back through the level (counts every setup). Limit at the level: enter only if price returns to the level; if it never does the setup is not taken. The other strategies always use their own entry: Ascendis and Order block use a limit order, Trend break, Ribbon MSNR, CRT and Alchemist enter at the close of the signal candle.", 11)
        Text("OML: the entry candle must be one of candles 4 to ...", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Brand.Text)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (m in listOf(6, 7, 8)) ChoiceChip("up to " + m, Store.omlMaxFill == m) { Store.omlMaxFill = m; Store.save() }
        }
        Text("OML: lower timeframe for the tight stop", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Brand.Text)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip("Off", Store.omlLtf == 0) { Store.omlLtf = 0; Store.save() }
            for ((sec, name) in TIMEFRAMES) {
                if (sec >= Store.chartTf) continue
                ChoiceChip(name, Store.omlLtf == sec) { Store.omlLtf = sec; Store.save() }
            }
        }
        Muted("With a lower timeframe chosen, the stop goes just above the first small candle that reaches the level, and the next level is measured from that tight stop (so the reward to risk is much bigger). Small candles only reach back a few days or weeks, so older OML setups on the chart keep the stop above candle 1. The background watcher and its alerts do not use the lower timeframe yet.", 11)
        Muted("OML: candle 1 is the liquidity candle and candle 2 opens where candle 1 closed (the open and close level, OML). Candle 3 must stay away. The first of candles 4 to the number above that comes back to the level fills the limit entry there; the stop is above candle 1's high. If it never comes back in time there is no trade. Buys are the mirror image.", 11)
        Text("Directions", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Brand.Text)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip("Both", Store.setupDirs == 3) { Store.setupDirs = 3; Store.save() }
            ChoiceChip("Shorts only", Store.setupDirs == 1) { Store.setupDirs = 1; Store.save() }
            ChoiceChip("Longs only", Store.setupDirs == 2) { Store.setupDirs = 2; Store.save() }
        }
    }
    PCard {
        DecField("Minimum reward to risk (R)", Store.setupRR, Modifier.fillMaxWidth()) { Store.setupRR = it.coerceIn(1.0, 30.0); Store.save() }
        DecField("Trading cost per trade (ATR): spread + slippage", Store.setupCost, Modifier.fillMaxWidth()) { Store.setupCost = it.coerceIn(0.0, 2.0); Store.save() }
        Muted("Taken off every finished trade, so wins pay a little less and losses cost a little more. Entering at the close of a candle is never exactly at that price, and tight stops make this matter. Use 0 to see the raw numbers.", 11)
        DecField("Minimum move away from the level (ATR)", Store.setupImpulse, Modifier.fillMaxWidth()) { Store.setupImpulse = it.coerceIn(1.0, 15.0); Store.save() }
        DecField("Price back near the entry: within this many ATR", Store.setupNearAtr, Modifier.fillMaxWidth()) { Store.setupNearAtr = it.coerceIn(0.05, 5.0); Store.save() }
        Muted("A bigger move and a higher reward to risk give fewer but cleaner setups. Alerts for this are switched on or off under Alert types > Setup finder. The chart and the dashboard update at once; the background watcher uses the new values from its next candle.", 11)
    }
}

/**
 * Draws the setups on the chart like the position tool. Whatever part of the history is on screen shows its trades: the newest live
 * setup gets the full box with three labels, every other trade is drawn fainter with one small result label (labels that would
 * overlap are skipped), so the chart stays readable both at the latest candles and when scrolled back.
 */
fun DrawScope.drawSetups(g: Geo, sc: SetupScan, dec: Int, label: String = "", lastPrice: Double = Double.NaN) {
    // only the setups that overlap the part of the chart on screen, so scrolling back shows the older trades too
    fun startOf(s: Setup): Int = if (s.fillIdx >= 0) s.fillIdx else s.lockIdx
    val vis = sc.setups.filter { (it.live || it.state == ST_WIN || it.state == ST_LOSS || it.state == ST_FLAT) && startOf(it) <= g.lastIdx && (it.live || it.endIdx < 0 || it.endIdx >= g.firstIdx) }
    // a live setup is drawn as the full labelled box only when it is the newest one; the rest are drawn small
    val newestLive = vis.filter { it.live }.maxByOrNull { it.lockIdx }
    val shown = vis.sortedBy { it.lockIdx }.takeLast(60)
    var lastPillX = -1000f
    var lastPillY = -1000f
    val minDx = 40.dp.toPx()
    val minDy = 20.dp.toPx()
    for (s in shown) {
        val isLive = s.live
        val big = s === newestLive
        val reversed = s.kind.startsWith("reverse ")
        val col = if (s.isLong) Brand.Good else Brand.Danger
        val xOrigin = g.xAt(s.originIdx.toDouble())
        // a live trade's box ends a few candles after the latest one, not at the edge of the screen
        val xEnd = if (isLive || s.endIdx < 0) Math.min(g.pw, g.xAt((g.n - 1 + 6).toDouble())) else g.xAt(s.endIdx.toDouble())
        val xStart = g.xAt(startOf(s).toDouble())
        val dim = if (isLive) 1f else 0.6f

        // the zone the setup came from (neutral for a reversed setup: the trade goes against it), for the newest live one only
        if (big && xEnd > xOrigin) {
            val zTop: Float = g.yAt(Math.max(s.distal, s.proximal))
            val zBot: Float = g.yAt(Math.min(s.distal, s.proximal))
            drawRect((if (reversed) Brand.Muted else col).copy(alpha = 0.14f), Offset(xOrigin, zTop), Size(xEnd - xOrigin, Math.max(zBot - zTop, 2f)))
        }
        if (xEnd <= xStart) continue

        val yE = g.yAt(s.entry)
        // OML: the "$" liquidity line (the third candle's extreme), from that candle to where the trade is taken
        if (big && !s.liq.isNaN() && s.liqIdx >= 0) {
            val yL = g.yAt(s.liq)
            val xL = g.xAt(s.liqIdx.toDouble())
            if (yL >= g.top && yL <= g.bottom && xStart > xL) {
                drawLine(Brand.Muted, Offset(xL, yL), Offset(xStart, yL), 1.2.dp.toPx(), pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(8f, 6f)))
                chartText("$", xL + 3.dp.toPx(), yL - 3.dp.toPx(), Brand.Muted.toArgb(), 10f, bold = true)
            }
        }
        // how the trade has gone: filled to the exit price when finished, to the latest price while running
        val sgn = if (s.isLong) 1.0 else -1.0
        val rk = Math.abs(s.entry - s.stop)
        val prog: Double = when (s.state) {
            ST_WIN -> s.target
            ST_LOSS -> s.stop
            ST_FLAT -> s.entry + sgn * s.result * rk
            ST_ACTIVE -> lastPrice
            else -> Double.NaN
        }
        val pnl: Double = if (prog.isNaN() || rk <= 0.0) Double.NaN else if (s.state == ST_WIN || s.state == ST_LOSS || s.state == ST_FLAT) s.result else (prog - s.entry) * sgn / rk
        if (big) {
            val headline = (if (label.isNotEmpty()) label + " " else "") + s.side + " " + s.kind + "  " + fp(s.rr, 1) + "R" +
                (if (s.state == ST_WAITING) "  waiting" else if (s.state == ST_ACTIVE) "  running" else "")
            drawTradeBox(g, xStart, xEnd, s.entry, s.stop, s.target, dec, headline, dim, true, Brand.Text, "", "", prog, pnl)
        } else {
            // small version: faint boxes, no long labels
            drawTradeBox(g, xStart, xEnd, s.entry, s.stop, s.target, dec, "", dim * 0.7f, false, Brand.Text, "", "", prog, pnl)
            val exitPrice = when (s.state) {
                ST_WIN -> s.target
                ST_LOSS -> s.stop
                else -> s.entry
            }
            val yX = g.yAt(exitPrice)
            if (!isLive && yX >= g.top && yX <= g.bottom) {
                val text = when (s.state) {
                    ST_WIN -> "+" + fp(Math.abs(s.result), 1) + "R"
                    ST_LOSS -> "-" + fp(Math.abs(s.result), 1) + "R"
                    else -> signedR(s.result)
                }
                val px = xEnd - 36.dp.toPx()
                if (Math.abs(px - lastPillX) > minDx || Math.abs(yX - lastPillY) > minDy) {
                    val bg = if (s.state == ST_WIN) Color(0xFF22C55E) else if (s.state == ST_LOSS) Color(0xFFF2495C) else Brand.Elevated
                    val fg = if (s.state == ST_WIN) 0xFF000000.toInt() else if (s.state == ST_LOSS) 0xFFFFFFFF.toInt() else Brand.Text.toArgb()
                    resultPill(g, text, px, yX, bg.copy(alpha = 0.9f), fg)
                    lastPillX = px
                    lastPillY = yX
                }
            }
        }

        // arrow head where the trade is taken: tip on the entry price, pointing the way the trade goes (up for a buy, down for a sell)
        if (yE >= g.top && yE <= g.bottom) {
            val sc2 = if (big) 1f else 0.7f
            val aw = 7.dp.toPx() * sc2
            val ah = 11.dp.toPx() * sc2
            val ax = xStart
            val arrow = androidx.compose.ui.graphics.Path()
            if (s.isLong) {
                arrow.moveTo(ax, yE)
                arrow.lineTo(ax - aw, yE + ah)
                arrow.lineTo(ax + aw, yE + ah)
            } else {
                arrow.moveTo(ax, yE)
                arrow.lineTo(ax - aw, yE - ah)
                arrow.lineTo(ax + aw, yE - ah)
            }
            arrow.close()
            drawPath(arrow, col.copy(alpha = dim))
        }
    }
}
