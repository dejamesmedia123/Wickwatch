package online.wickwatch.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val STAMP = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())

private fun stamp(t: Long): String = if (t <= 0L) "-" else STAMP.format(Date(t * 1000L))

private fun entryModeName(m: Int): String = if (m == 0) "limit at the level" else "close back through the level"

private val CSV_TIME = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }

/** Candles as CSV (UTC time, open, high, low, close) so they can be pasted into a chat or a script. */
fun candlesCsv(cs: List<Candle>): String {
    val sb = StringBuilder("time,open,high,low,close\n")
    for (c in cs) sb.append(CSV_TIME.format(Date(c.t * 1000L))).append(',').append(c.o).append(',').append(c.h).append(',').append(c.l).append(',').append(c.c).append('\n')
    return sb.toString()
}

/** What the finder produced, one line per setup, to compare with the trades you took. */
fun setupsCsv(sc: SetupScan): String {
    val sb = StringBuilder("signal_time_utc,side,kind,entry,stop,target,rr,outcome,result_R\n")
    for (s in sc.setups) {
        val out = when (s.state) { ST_WIN -> "WIN"; ST_LOSS -> "LOSS"; ST_FLAT -> "FLAT"; ST_DEAD -> "NOTFILLED"; ST_WAITING -> "WAITING"; else -> "OPEN" }
        sb.append(CSV_TIME.format(Date(s.lockT * 1000L))).append(',').append(s.side).append(',').append(s.kind).append(',').append(s.entry).append(',').append(s.stop)
            .append(',').append(s.target).append(',').append(fp(s.rr, 2)).append(',').append(out).append(',').append(fp(s.result, 2)).append('\n')
    }
    return sb.toString()
}

private fun signedR(r: Double): String = (if (r >= 0) "+" else "") + fp(r, 1) + "R"

/** The small card on the chart: last 10 result and win rate. Tap it to open the full dashboard. */
@Composable
fun SetupChip(sc: SetupScan, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val st = sc.statsLast(10)
    val waiting = sc.waiting().size
    val text = if (st.total == 0) "SETUPS  none finished yet" else "SETUPS  " + st.wins + "W " + st.losses + "L  " + fp(st.winRate, 0) + "%"
    Row(
        modifier.clip(RoundedCornerShape(10.dp)).background(Brand.Elevated.copy(alpha = 0.95f)).border(1.dp, Brand.Border, RoundedCornerShape(10.dp))
            .clickable { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(text, color = Brand.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        if (waiting > 0) Text(waiting.toString() + " waiting", color = Brand.Alert, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** The dashboard: win rate of the last 10 finished setups, what is open now, and the list. */
@Composable
fun SetupBoardSheet(sc: SetupScan?, market: Market, tf: Int, candles: List<Candle>, backfillMsg: String, onBackfill: () -> Unit, onDismiss: () -> Unit) {
    val clip = LocalClipboardManager.current
    var copied by remember { mutableStateOf("") }
    Sheet(onDismiss = onDismiss) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Setup finder", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Text)
            Muted(market.name + " " + tfLabel(tf) + "  |  entry: " + entryModeName(Store.setupMode) + "  |  min " + fp(Store.setupRR, 1) + "R", 12)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryButton("Copy candles CSV") { clip.setText(AnnotatedString(candlesCsv(candles.takeLast(1500)))); copied = "Copied the last " + Math.min(1500, candles.size) + " candles" }
                SecondaryButton("Copy setups") { if (sc != null) { clip.setText(AnnotatedString(setupsCsv(sc))); copied = "Copied " + sc.setups.size + " setups" } }
            }
            SecondaryButton("Load older candles (more history)") { onBackfill() }
            if (copied.isNotEmpty()) Muted(copied, 12)
            if (backfillMsg.isNotEmpty()) Muted(backfillMsg, 12)
            if (sc == null) {
                Muted("Still loading candles.", 13)
                return@Column
            }
            val last = sc.lastResolved(10)
            val st = sc.stats(last)
            val all = sc.stats(sc.setups)

            PCard {
                Text("LAST " + last.size + " FINISHED SETUPS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Brand.Muted)
                if (last.isEmpty()) {
                    Text("No finished setup in the saved candles yet.", color = Brand.Text, fontSize = 14.sp)
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Mono(fp(st.winRate, 0) + "%", 30, if (st.winRate >= 50) Brand.Good else Brand.Text, true)
                            Muted("win rate", 12)
                        }
                        Column {
                            Mono(st.wins.toString() + "W  " + st.losses + "L", 18, Brand.Text, true)
                            Muted("wins / losses", 12)
                        }
                        Column {
                            Mono(signedR(st.avgR), 18, if (st.avgR >= 0) Brand.Good else Brand.Danger, true)
                            Muted("average per trade", 12)
                        }
                    }
                    // one small box per result, oldest to newest
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (s in last.reversed()) {
                            val win = s.state == ST_WIN
                            Text(
                                if (win) "W" else "L", color = Brand.Bg, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(if (win) Brand.Good else Brand.Danger).padding(horizontal = 8.dp, vertical = 3.dp),
                            )
                        }
                    }
                }
                if (all.total < 10) Muted("Only " + all.total + " finished setups so far. Tap Load older candles to go further back.", 12)
                Muted("All " + all.total + " finished setups in " + sc.n + " saved candles: " + all.wins + "W " + all.losses + "L" + (if (all.total > 0) " (" + fp(all.winRate, 0) + "%, avg " + signedR(all.avgR) + ")" else ""), 12)
            }

            val open = sc.setups.filter { it.state == ST_WAITING || it.state == ST_ACTIVE }.sortedByDescending { it.originIdx }
            PCard {
                Text("OPEN NOW", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Brand.Muted)
                if (open.isEmpty()) Text("No setup is waiting or running.", color = Brand.Text, fontSize = 14.sp)
                for (s in open) SetupLine(s, market.dec)
            }

            PCard {
                Text("HISTORY (NEWEST FIRST)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Brand.Muted)
                if (last.isEmpty()) Text("Nothing yet.", color = Brand.Text, fontSize = 14.sp)
                for (s in last) SetupLine(s, market.dec)
            }

            Muted(
                "A setup is listed when a wick pokes through a marked level (a swing high or low, or a broken swing now acting the other way) and a candle then closes back on the side price came from. " +
                    "A wick above gives a SELL, a wick below gives a BUY. The way back to the level must be calmer than the move that left it. The stop is just beyond the wick tip; " +
                    "the target is a major swing on the other side, at least " + fp(Store.setupRR, 1) + "R away. Results use closed candles. If one candle touches both the stop and the target, the stop is counted first. " +
                    "Spread and fees are not included. This is a record of what the rules would have done, not advice and not a promise.", 11,
            )
        }
    }
}

@Composable
private fun SetupLine(s: Setup, dec: Int) {
    val col = if (s.isLong) Brand.Good else Brand.Danger
    val status = when (s.state) {
        ST_WAITING -> "waiting for price to return"
        ST_ACTIVE -> "running"
        ST_WIN -> "target hit " + signedR(s.result)
        ST_LOSS -> "stopped -1R"
        ST_FLAT -> "closed after a long time"
        else -> "not taken (" + s.why + ")"
    }
    val statusCol = when (s.state) {
        ST_WIN -> Brand.Good
        ST_LOSS -> Brand.Danger
        ST_WAITING, ST_ACTIVE -> Brand.Alert
        else -> Brand.Muted
    }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(s.side, color = col, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text((if (s.kind == "flip") "retest" else "sweep"), color = Brand.Text, fontSize = 13.sp)
            Text(fp(s.rr, 1) + "R plan", color = Brand.Muted, fontSize = 13.sp)
            Text(stamp(if (s.fillT > 0L) s.fillT else s.lockT), color = Brand.Muted, fontSize = 12.sp)
        }
        Mono("entry " + fp(s.entry, dec) + "   stop " + fp(s.stop, dec) + "   target " + fp(s.target, dec), 12, Brand.Text)
        Text(status, color = statusCol, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Settings page for the setup finder. */
@Composable
fun SetupSettingsPage() {
    Muted(
        "The setup finder looks for a wick that pokes through a marked level and a candle that closes back. A wick above gives a SELL, a wick below a BUY. " +
            "The stop sits just beyond the wick tip and the target is a major swing on the other side. Turn it on from the chart's Analysis hub (Setup finder).", 12,
    )
    PCard {
        Text("Entry style", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Brand.Text)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip("Close back through", Store.setupMode != 0) { Store.setupMode = 1; Store.save() }
            ChoiceChip("Limit at the level", Store.setupMode == 0) { Store.setupMode = 0; Store.save() }
        }
        Muted("Close back through: enter at the close of the candle that comes back through the level (counts every setup). Limit at the level: enter only if price returns to the level; if it never does the setup is not taken.", 11)
        Text("Directions", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Brand.Text)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ChoiceChip("Both", Store.setupDirs == 3) { Store.setupDirs = 3; Store.save() }
            ChoiceChip("Shorts only", Store.setupDirs == 1) { Store.setupDirs = 1; Store.save() }
            ChoiceChip("Longs only", Store.setupDirs == 2) { Store.setupDirs = 2; Store.save() }
        }
    }
    PCard {
        DecField("Minimum reward to risk (R)", Store.setupRR, Modifier.fillMaxWidth()) { Store.setupRR = it.coerceIn(1.0, 30.0); Store.save() }
        DecField("Minimum move away from the level (ATR)", Store.setupImpulse, Modifier.fillMaxWidth()) { Store.setupImpulse = it.coerceIn(1.0, 15.0); Store.save() }
        DecField("Price back near the entry: within this many ATR", Store.setupNearAtr, Modifier.fillMaxWidth()) { Store.setupNearAtr = it.coerceIn(0.05, 5.0); Store.save() }
        Muted("A bigger move and a higher reward to risk give fewer but cleaner setups. Alerts for this are switched on or off under Alert types > Setup finder. The chart and the dashboard update at once; the background watcher uses the new values from its next candle.", 11)
    }
}

/** Draws the newest setups on the chart: zone, entry, stop, target and the result. */
fun DrawScope.drawSetups(g: Geo, sc: SetupScan, dec: Int) {
    val shown = sc.setups.filter { it.endIdx < 0 || it.endIdx >= g.firstIdx }.sortedByDescending { it.originIdx }.take(6)
    val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
    for (s in shown) {
        val col = if (s.isLong) Brand.Good else Brand.Danger
        val xOrigin = g.xAt(s.originIdx.toDouble())
        val running = s.state == ST_WAITING || s.state == ST_ACTIVE
        val xEnd = if (running || s.endIdx < 0) g.pw else g.xAt(s.endIdx.toDouble())
        val xStart = g.xAt((if (s.fillIdx >= 0) s.fillIdx else s.lockIdx).toDouble())
        val dim = if (s.resolved || s.state == ST_FLAT || s.state == ST_DEAD) 0.55f else 1f

        // the zone at the origin, extended to the right while it is still in play
        val zTop: Float = g.yAt(Math.max(s.distal, s.proximal))
        val zBot: Float = g.yAt(Math.min(s.distal, s.proximal))
        if (xEnd > xOrigin) drawRect(col.copy(alpha = 0.22f * dim), Offset(xOrigin, zTop), Size(xEnd - xOrigin, Math.max(zBot - zTop, 2f)))

        if (xEnd <= xStart) continue
        val yE = g.yAt(s.entry)
        val yS = g.yAt(s.stop)
        val yT = g.yAt(s.target)
        // like the position tool: green towards the target, red towards the stop
        val boxW: Float = xEnd - xStart
        val rewardH: Float = Math.abs(yT - yE)
        val riskH: Float = Math.max(Math.abs(yS - yE), 2f)
        drawRect(Brand.Good.copy(alpha = 0.08f * dim), Offset(xStart, Math.min(yE, yT)), Size(boxW, rewardH))
        drawRect(Brand.Danger.copy(alpha = 0.14f * dim), Offset(xStart, Math.min(yE, yS)), Size(boxW, riskH))
        drawLine(Brand.Text.copy(alpha = dim), Offset(xStart, yE), Offset(xEnd, yE), 2f, pathEffect = dash)
        drawLine(Brand.Danger.copy(alpha = dim), Offset(xStart, yS), Offset(xEnd, yS), 2f, pathEffect = dash)
        drawLine(Brand.Good.copy(alpha = dim), Offset(xStart, yT), Offset(xEnd, yT), 2f, pathEffect = dash)

        val tag = s.side + " " + s.kind + "  " + fp(s.rr, 1) + "R" + when (s.state) {
            ST_WIN -> "  WIN " + signedR(s.result)
            ST_LOSS -> "  LOSS -1R"
            ST_WAITING -> "  waiting"
            ST_ACTIVE -> "  running"
            else -> ""
        }
        chartText(tag, Math.max(xStart, 4f) + 4f, Math.min(yE, yT) + 14f, col.copy(alpha = dim).toArgb(), 10f, bold = true)
    }
}
