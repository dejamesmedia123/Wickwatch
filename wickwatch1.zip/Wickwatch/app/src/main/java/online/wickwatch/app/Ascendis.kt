package online.wickwatch.app

import kotlin.math.max
import kotlin.math.min

/*
 * Ascendis engine (order block + liquidity, with a bias timeframe). Port of tools/sweep/ascendis.py (same rules, tested there).
 *
 *  1. Bias timeframe = chart timeframe x biasMult (0 = auto: 5, 9, 16 and 40 together). A bias candle CLOSES through the last swing low: break of structure, trend is down.
 *  2. POI = the supply order block that started that leg (last bullish bias candle at/before the leg's highest high).
 *     It must have swept liquidity (its high took out an earlier swing high), unless needLiq is off.
 *  3. Price retraces up into the POI (tap). Dead if the chart closes above the zone or the bias flips.
 *  4. After the tap, a chart candle closes below the last swing low: market structure shift (MSS).
 *  5. Entry: LIMIT at the low edge of the small order block (last bullish candle at/before the high made inside the POI).
 *     Stop just above that high. Target: nearest earlier swing low that gives at least minRR.
 *  Sells only in a downtrend, buys only in an uptrend (the same code on mirrored prices). Closed candles only.
 */
private class Poi(val lo: Double, val hi: Double, val born: Int) {
    var st = 0            // 0 waiting for the tap, 1 tapped (looking for the shift), 2 finished
    var tap = 0
    var peak = 0.0
    var pk = 0
}

object AscendisEngine {
    fun scan(cs: List<Candle>, p: SetupParams = SetupParams()): SetupScan {
        val n = cs.size
        val atr = SweepEngine.atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 80) return SetupScan(emptyList(), n, last)
        var dt = Long.MAX_VALUE
        for (i in 1 until min(n, 200)) {
            val d = cs[i].t - cs[i - 1].t
            if (d > 0 && d < dt) dt = d
        }
        if (dt == Long.MAX_VALUE) dt = 60L
        // the charts use different timeframe pairs (5m/45m, 15m/4H, 3m/2H...), so by default several ratios run together
        val mults = if (p.biasMult >= 2) listOf(p.biasMult) else listOf(5, 9, 16, 40)
        val all = ArrayList<Setup>()
        for (m in mults) {
            val part = ArrayList<Setup>()
            if (p.dirMask and 1 != 0) part.addAll(scanDir(cs, atr, p, true, dt * m))
            if (p.dirMask and 2 != 0) part.addAll(scanDir(cs, atr, p, false, dt * m))
            for (s in part) if (all.none { it.dir == s.dir && Math.abs(it.lockIdx - s.lockIdx) <= 5 && Math.abs(it.entry - s.entry) <= 0.5 * atr[s.lockIdx.coerceIn(0, n - 1)] }) all.add(s)   // same trade found by two ratios
        }
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    private fun scanDir(cs: List<Candle>, a: DoubleArray, p: SetupParams, short: Boolean, blen: Long): List<Setup> {
        val n = cs.size
        val o = DoubleArray(n) { if (short) cs[it].o else -cs[it].o }
        val h = DoubleArray(n) { if (short) cs[it].h else -cs[it].l }
        val l = DoubleArray(n) { if (short) cs[it].l else -cs[it].h }
        val c = DoubleArray(n) { if (short) cs[it].c else -cs[it].c }
        fun px(x: Double): Double = if (short) x else -x

        // bias candles
        val bid = LongArray(n) { cs[it].t / blen }
        val hO = ArrayList<Double>(); val hH = ArrayList<Double>(); val hL = ArrayList<Double>(); val hC = ArrayList<Double>()
        val hid = ArrayList<Long>()
        for (i in 0 until n) {
            if (hid.isEmpty() || hid[hid.size - 1] != bid[i]) {
                hid.add(bid[i]); hO.add(o[i]); hH.add(h[i]); hL.add(l[i]); hC.add(c[i])
            } else {
                val k = hid.size - 1
                hH[k] = max(hH[k], h[i]); hL[k] = min(hL[k], l[i]); hC[k] = c[i]
            }
        }
        val hs = p.hSpan
        val sp = p.pivotSpan
        val hpHi = ArrayList<DoubleArray>()          // [index, value, broken 0/1]
        val hpLo = ArrayList<DoubleArray>()
        val pois = ArrayList<Poi>()
        val ltfLo = ArrayList<Int>()
        val tgt = ArrayList<Double>()
        val out = ArrayList<Setup>()
        var down = false
        var ptr = 0

        fun biasStep(k: Int, i: Int) {
            val j = k - hs
            if (j - hs >= 0) {
                var ph = true
                var pl = true
                for (q in j - hs until j) { if (hH[q] >= hH[j]) ph = false; if (hL[q] <= hL[j]) pl = false }
                for (q in j + 1..j + hs) { if (hH[q] > hH[j]) ph = false; if (hL[q] < hL[j]) pl = false }
                if (ph) hpHi.add(doubleArrayOf(j.toDouble(), hH[j], 0.0))
                if (pl) hpLo.add(doubleArrayOf(j.toDouble(), hL[j], 0.0))
            }
            val up = hpHi.lastOrNull { it[2] == 0.0 }
            if (up != null && hC[k] > up[1]) {            // break of structure the other way
                up[2] = 1.0
                down = false
                for (q in pois) q.st = 2
                return
            }
            val lw = hpLo.lastOrNull { it[2] == 0.0 }
            if (lw != null && hC[k] < lw[1]) {
                lw[2] = 1.0
                down = true
                val s0 = lw[0].toInt()
                if (k <= s0) return
                var jh = s0
                for (q in s0 until k) if (hH[q] > hH[jh]) jh = q
                var ob = jh
                var q = jh
                while (q >= 0 && q > jh - p.pocBack) {
                    if (hC[q] > hO[q]) { ob = q; break }
                    q -= 1
                }
                val lo = min(hO[ob], hC[ob])
                val hi = max(hH[jh], hH[ob])
                var liq = false
                for (x in hpHi) {
                    val xi = x[0].toInt()
                    if (xi < jh && xi >= jh - 30 && hH[jh] > x[1]) liq = true
                }
                if ((p.needLiq && !liq) || c[i] >= lo) return
                pois.add(Poi(lo, hi, i))
            }
        }

        for (i in 0 until n) {
            while (ptr < hid.size && hid[ptr] < bid[i]) { biasStep(ptr, i); ptr += 1 }
            val j = i - sp
            if (j - sp >= 0) {
                var ok = true
                for (q in j - sp until j) if (l[q] <= l[j]) ok = false
                for (q in j + 1..j + sp) if (l[q] < l[j]) ok = false
                if (ok) ltfLo.add(j)
            }
            val jt = i - p.tgtSpan
            if (jt - p.tgtSpan >= 0) {
                var ok = true
                for (q in jt - p.tgtSpan until jt) if (l[q] <= l[jt]) ok = false
                for (q in jt + 1..jt + p.tgtSpan) if (l[q] < l[jt]) ok = false
                if (ok) tgt.add(l[jt])
            }
            for (q in pois) {
                if (q.st == 2) continue
                if (i - q.born > 400 || c[i] > q.hi || !down) { q.st = 2; continue }
                if (q.st == 0) {
                    if (h[i] >= q.lo) { q.st = 1; q.tap = i; q.peak = h[i]; q.pk = i } else continue
                }
                if (h[i] > q.peak) { q.peak = h[i]; q.pk = i }
                if (i - q.pk > p.mssWindow) { q.st = 2; continue }
                if (i <= q.pk) continue
                var jl = -1
                for (x in ltfLo.indices.reversed()) if (ltfLo[x] < q.pk) { jl = ltfLo[x]; break }
                if (jl < 0 || jl < q.tap - 40 || !(c[i] < l[jl])) continue
                q.st = 2
                var ob = -1
                var b = q.pk
                while (b >= 0 && b > q.pk - p.obBack) {
                    if (c[b] > o[b]) { ob = b; break }
                    b -= 1
                }
                if (ob < 0) continue
                val stop = max(q.peak, h[ob]) + p.sweepStopBufAtr * a[i]
                val entry = max(o[ob], c[i])               // limit at the low edge of the order block
                val risk = stop - entry
                if (risk <= 0 || risk > p.maxRiskAtr * a[i]) continue
                var best = Double.NaN
                for (v in tgt) if (v < entry && (entry - v) / risk >= p.minRR && (best.isNaN() || v > best)) best = v
                for (x in hpLo) { val v = x[1]; if (v < entry && (entry - v) / risk >= p.minRR && (best.isNaN() || v > best)) best = v }
                if (best.isNaN()) continue

                val s = Setup(if (short) 1 else -1, q.tap, cs[q.tap].t)
                s.kind = "ascendis"
                s.valid = true
                s.proximal = px(entry)
                s.distal = px(q.peak)
                s.entry = px(entry)
                s.stop = px(stop)
                s.target = px(best)
                s.risk = risk
                s.rr = (entry - best) / risk
                s.lockIdx = i
                s.lockT = cs[i].t
                s.touchIdx = q.tap
                var fill = -1
                var k = i + 1
                val wait = max(p.waitBars, 40)
                while (k < n && k <= i + wait) {
                    if (l[k] <= best) break
                    if (h[k] >= entry) { fill = k; break }
                    k += 1
                }
                if (fill < 0) {
                    if (i + wait < n) { s.state = ST_DEAD; s.why = "price never returned to the order block"; s.endIdx = i + wait; s.endT = cs[s.endIdx].t }
                    else s.state = ST_WAITING
                    out.add(s)
                    continue
                }
                s.fillIdx = fill
                s.fillT = cs[fill].t
                if (h[fill] >= stop) {
                    s.state = ST_LOSS; s.endIdx = fill; s.endT = cs[fill].t; s.result = -1.0
                    out.add(s)
                    continue
                }
                s.state = ST_ACTIVE
                var m = fill + 1
                while (m < n) {
                    if (h[m] >= stop) { s.state = ST_LOSS; s.endIdx = m; s.endT = cs[m].t; s.result = -1.0; break }
                    if (l[m] <= best) { s.state = ST_WIN; s.endIdx = m; s.endT = cs[m].t; s.result = s.rr; break }
                    if (m - fill > p.maxActiveBars) { s.state = ST_FLAT; s.endIdx = m; s.endT = cs[m].t; s.result = (entry - c[m]) / risk; break }
                    m += 1
                }
                out.add(s)
            }
        }
        return out
    }
}
