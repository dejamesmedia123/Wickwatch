package online.wickwatch.app

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/*
 * Isotropic Trend Lines, built from the written description in the header of the "Smart Trader, Episode 06" script
 * (Yang-Zhang volatility, blocks of bars reduced to a geometric mean, the longest rising or falling run of blocks,
 * a channel around that run, six scales, and a breakout / retest state machine).
 *
 * IMPORTANT: this is an approximation written from that description, not a line-by-line port, because the functions
 * of the original script were not available. Its channels and signals can differ from the TradingView version.
 */

/** One scale (one block length) of the analysis. */
class IsoScale(
    val period: Int,
    val dir: Int,                // 1 up, -1 down, 0 range
    val angle: Double,           // degrees, in sigma-normalised space
    val slope: Double,           // price per bar of the channel
    val upper: Double,           // channel ceiling at the last bar
    val lower: Double,           // channel floor at the last bar
    val upperInt: Double,        // line: upper(i) = upperInt + slope * i
    val lowerInt: Double,
    val segStart: Int,           // first bar of the run the channel was fitted on
    val lastIdx: Int,
)

class IsoResult(val primary: IsoScale?, val scales: List<IsoScale?>, val agree: Int, val sigma: Double, val atr: Double)

class IsoState {
    var st = 0                   // 0 inside, 1 breakout up, 2 retest up, -1 breakout down, -2 retest down
    var maxExt = 0.0
    var lastDir = Int.MIN_VALUE
}

class IsoEvent(val kind: AlertKind, val key: String, val text: String)

object Iso {
    val SCALES = listOf(3, 7, 13, 19, 29, 47)

    /** Yang-Zhang volatility per bar over [len] bars ending at [end]. */
    fun yangZhang(cs: List<Candle>, end: Int, len: Int): Double {
        val start = end - len + 1
        if (start < 1 || len < 3) return Double.NaN
        val oRet = DoubleArray(len)
        val cRet = DoubleArray(len)
        var rs = 0.0
        for (k in 0 until len) {
            val i = start + k
            val c = cs[i]
            oRet[k] = ln(c.o / cs[i - 1].c)
            cRet[k] = ln(c.c / c.o)
            rs += ln(c.h / c.c) * ln(c.h / c.o) + ln(c.l / c.c) * ln(c.l / c.o)
        }
        val mo = oRet.average()
        val mc = cRet.average()
        var vo = 0.0
        var vc = 0.0
        for (k in 0 until len) {
            vo += (oRet[k] - mo) * (oRet[k] - mo)
            vc += (cRet[k] - mc) * (cRet[k] - mc)
        }
        vo /= (len - 1)
        vc /= (len - 1)
        val vrs = rs / len
        val k = 0.34 / (1.34 + (len + 1.0) / (len - 1.0))
        val v = vo + k * vc + (1 - k) * vrs
        return sqrt(max(v, 1e-20))
    }

    private fun scale(cs: List<Candle>, p: Int, groups: Int, thresh: Double, sigma: Double): IsoScale? {
        val n = cs.size
        if (n < p * groups + 2 || sigma.isNaN() || sigma <= 0) return null
        val a = n - 1
        val gm = DoubleArray(groups)
        val bStart = IntArray(groups)
        val bEnd = IntArray(groups)
        for (b in 0 until groups) {
            val end = a - (groups - 1 - b) * p
            val st = end - p + 1
            var hi = -Double.MAX_VALUE
            var lo = Double.MAX_VALUE
            for (i in st..end) {
                hi = max(hi, cs[i].h)
                lo = min(lo, cs[i].l)
            }
            gm[b] = exp((ln(hi) + ln(lo)) / 2.0)     // geometric mean of the block's high and low
            bStart[b] = st
            bEnd[b] = end
        }
        // the longest run of blocks whose geometric means keep rising or keep falling (the most recent wins a tie)
        var bestLen = 1
        var bestEnd = groups - 1
        var runStart = 0
        var runDir = 0
        for (b in 1 until groups) {
            val d = if (gm[b] > gm[b - 1]) 1 else if (gm[b] < gm[b - 1]) -1 else 0
            if (d == 0) {
                runStart = b
                runDir = 0
                continue
            }
            if (d != runDir) {
                runStart = b - 1
                runDir = d
            }
            val len = b - runStart + 1
            if (len >= bestLen) {
                bestLen = len
                bestEnd = b
            }
        }
        val startBlock = bestEnd - bestLen + 1
        val segStart = bStart[startBlock]
        val bars = ((bestLen - 1) * p).coerceAtLeast(1)
        val slopeLn = if (bestLen >= 2) (ln(gm[bestEnd]) - ln(gm[startBlock])) / bars else 0.0
        val angle = atan(slopeLn / sigma) * 180.0 / PI      // arctan of the sigma-normalised slope
        val dir = if (abs(angle) < thresh) 0 else if (angle > 0) 1 else -1

        // a channel around every bar of the run, up to the last bar
        val slope = if (dir == 0 || bestLen < 2) 0.0 else (gm[bestEnd] - gm[startBlock]) / bars
        var iu = -Double.MAX_VALUE
        var il = Double.MAX_VALUE
        for (i in segStart..a) {
            iu = max(iu, cs[i].h - slope * i)
            il = min(il, cs[i].l - slope * i)
        }
        return IsoScale(p, dir, angle, slope, iu + slope * a, il + slope * a, iu, il, segStart, a)
    }

    /** Runs the six scales. The scale equal to the primary period uses the user's period; [cs] holds closed candles only. */
    fun analyze(cs: List<Candle>, period: Int, groups: Int, thresh: Double, sigmaLen: Int): IsoResult {
        val sigma = if (cs.size > sigmaLen + 2) yangZhang(cs, cs.size - 1, sigmaLen) else Double.NaN
        val atr = Ind.atr(cs, 14).let { if (it.isEmpty()) Double.NaN else it[it.size - 1] }
        val periods = SCALES.map { if (it == 19) period else it }
        val list = periods.map { scale(cs, it, groups, thresh, sigma) }
        val primary = list[SCALES.indexOf(19)]
        val agree = if (primary == null) 0 else list.count { it != null && it.dir == primary.dir }
        return IsoResult(primary, list, agree, sigma, atr)
    }

    /** Moves the breakout / retest state machine one closed candle forward. */
    fun step(state: IsoState, res: IsoResult, c: Candle, dec: Int): List<IsoEvent> {
        val p = res.primary ?: return emptyList()
        val ev = ArrayList<IsoEvent>()
        val up = p.upper
        val dn = p.lower
        val width = max(up - dn, 1e-12)
        val sig = if (res.sigma.isNaN()) 0.0 else res.sigma * c.c         // sigma in price terms
        val dirText = if (p.dir == 1) "UP" else if (p.dir == -1) "DOWN" else "RANGE"

        if (state.lastDir != Int.MIN_VALUE && state.lastDir != p.dir) {
            ev.add(IsoEvent(AlertKind.ISO_DIRECTION, "dir" + p.dir, "Trend changed to " + dirText + ". " + res.agree + " of 6 scales agree."))
            state.st = 0
        }
        state.lastDir = p.dir

        when (state.st) {
            0 -> {
                if (c.c > up) {
                    state.st = 1
                    state.maxExt = c.h - up
                    ev.add(IsoEvent(AlertKind.ISO_BREAKOUT, "bo_up", "Breakout UP at " + fp(c.c, dec) + ", " + fp((c.c - up) / width * 100, 1) + "% above the ceiling (" + fp(up, dec) + "). Trend " + dirText + ", " + res.agree + " of 6 scales agree."))
                } else if (c.c < dn) {
                    state.st = -1
                    state.maxExt = dn - c.l
                    ev.add(IsoEvent(AlertKind.ISO_BREAKOUT, "bo_dn", "Breakout DOWN at " + fp(c.c, dec) + ", " + fp((dn - c.c) / width * 100, 1) + "% below the floor (" + fp(dn, dec) + "). Trend " + dirText + ", " + res.agree + " of 6 scales agree."))
                }
            }
            1 -> {
                state.maxExt = max(state.maxExt, c.h - up)
                if (c.c <= up) {
                    if (state.maxExt >= sig && c.l <= up) {
                        state.st = 2
                        ev.add(IsoEvent(AlertKind.ISO_RETEST, "rt_up", "Price came back to retest the broken ceiling at " + fp(up, dec) + "."))
                    } else {
                        state.st = 0
                        ev.add(IsoEvent(AlertKind.ISO_FAILED, "fail_up", "Failed breakout up: price is back inside the channel."))
                    }
                } else if (c.c < dn) {
                    state.st = -1
                    state.maxExt = dn - c.l
                }
            }
            2 -> {
                if (c.c >= up + sig) {
                    state.st = 1
                    state.maxExt = c.h - up
                    ev.add(IsoEvent(AlertKind.ISO_RETEST, "rt_up_ok", "Retest confirmed: price bounced from the ceiling (" + fp(up, dec) + ") and is moving up."))
                } else if (c.c < up - sig) {
                    state.st = 0
                    ev.add(IsoEvent(AlertKind.ISO_FAILED, "fail_up2", "Retest failed: price fell back inside the channel."))
                }
            }
            -1 -> {
                state.maxExt = max(state.maxExt, dn - c.l)
                if (c.c >= dn) {
                    if (state.maxExt >= sig && c.h >= dn) {
                        state.st = -2
                        ev.add(IsoEvent(AlertKind.ISO_RETEST, "rt_dn", "Price came back to retest the broken floor at " + fp(dn, dec) + "."))
                    } else {
                        state.st = 0
                        ev.add(IsoEvent(AlertKind.ISO_FAILED, "fail_dn", "Failed breakout down: price is back inside the channel."))
                    }
                } else if (c.c > up) {
                    state.st = 1
                    state.maxExt = c.h - up
                }
            }
            -2 -> {
                if (c.c <= dn - sig) {
                    state.st = -1
                    state.maxExt = dn - c.l
                    ev.add(IsoEvent(AlertKind.ISO_RETEST, "rt_dn_ok", "Retest confirmed: price was rejected at the floor (" + fp(dn, dec) + ") and is moving down."))
                } else if (c.c > dn + sig) {
                    state.st = 0
                    ev.add(IsoEvent(AlertKind.ISO_FAILED, "fail_dn2", "Retest failed: price rose back inside the channel."))
                }
            }
        }
        return ev
    }
}
