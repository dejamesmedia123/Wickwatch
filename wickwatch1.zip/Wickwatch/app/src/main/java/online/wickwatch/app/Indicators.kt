package online.wickwatch.app

/** What an indicator is called, whether it draws on the price chart, and its default settings. */
class IndSpec(val type: String, val name: String, val overlay: Boolean, val d1: Int, val d2: Int, val d3: Int, val labels: List<String>)

object IndSpecs {
    val ALL: List<IndSpec> = listOf(
        IndSpec("SMA", "Simple moving average", true, 20, 0, 0, listOf("Period")),
        IndSpec("EMA", "Exponential moving average", true, 50, 0, 0, listOf("Period")),
        IndSpec("BB", "Bollinger Bands", true, 20, 2, 0, listOf("Period", "Deviations")),
        IndSpec("ST", "Supertrend", true, 10, 3, 0, listOf("ATR period", "Multiplier")),
        IndSpec("VWAP", "VWAP (needs volume)", true, 0, 0, 0, listOf()),
        IndSpec("RSI", "RSI", false, 14, 0, 0, listOf("Period", "Zone labels (1 = on)")),
        IndSpec("MACD", "MACD", false, 12, 26, 9, listOf("Fast", "Slow", "Signal")),
        IndSpec("STOCH", "Stochastic", false, 14, 3, 3, listOf("K period", "K smoothing", "D smoothing")),
        IndSpec("ATR", "ATR", false, 14, 0, 0, listOf("Period")),
        IndSpec("VOL", "Volume (needs volume)", false, 0, 0, 0, listOf()),
    )

    fun spec(type: String): IndSpec = ALL.firstOrNull { it.type == type } ?: ALL[0]
}

/** One indicator the person added. Colours are ARGB. */
data class IndCfg(val id: String, val type: String, val p1: Int, val p2: Int, val p3: Int, val color: Long)

val IND_COLORS: List<Long> = listOf(0xFF14B8A6, 0xFFFFB020, 0xFF8B5CF6, 0xFF38BDF8, 0xFFF472B6, 0xFFA3E635)

/** The numbers to draw for one indicator. */
class IndOut(
    val lines: List<DoubleArray>,
    val colors: List<Long>,
    val hist: DoubleArray?,
    val histMode: Int,            // 0 none, 1 volume (coloured by candle), 2 MACD (coloured by sign)
    val min: Double,              // NaN = fit to the data
    val max: Double,
    val guides: List<Double>,
    val label: String,
    val bandFill: Boolean,
    val guideLabels: List<String> = emptyList(),
)

fun computeInd(cfg: IndCfg, cs: List<Candle>): IndOut {
    val n = cs.size
    val close = DoubleArray(n) { cs[it].c }
    val nan = Double.NaN
    return when (cfg.type) {
        "SMA" -> IndOut(listOf(Ind.sma(close, cfg.p1)), listOf(cfg.color), null, 0, nan, nan, emptyList(), "SMA " + cfg.p1, false)
        "EMA" -> IndOut(listOf(Ind.ema(close, cfg.p1)), listOf(cfg.color), null, 0, nan, nan, emptyList(), "EMA " + cfg.p1, false)
        "BB" -> {
            val mid = Ind.sma(close, cfg.p1)
            val sd = Ind.stdev(close, cfg.p1)
            val up = DoubleArray(n) { mid[it] + cfg.p2 * sd[it] }
            val lo = DoubleArray(n) { mid[it] - cfg.p2 * sd[it] }
            IndOut(listOf(up, mid, lo), listOf(cfg.color, 0xFF8A98B3, cfg.color), null, 0, nan, nan, emptyList(), "BB " + cfg.p1 + " " + cfg.p2, true)
        }
        "ST" -> {
            val st = Ind.supertrend(cs, cfg.p1, cfg.p2.toDouble())
            IndOut(listOf(st[0], st[1]), listOf(0xFF22C55E, 0xFFF2495C), null, 0, nan, nan, emptyList(), "Supertrend " + cfg.p1 + " " + cfg.p2, false)
        }
        "VWAP" -> IndOut(listOf(Ind.vwap(cs)), listOf(cfg.color), null, 0, nan, nan, emptyList(), "VWAP", false)
        "RSI" -> {
            val zones = cfg.p2 == 1
            IndOut(
                listOf(Ind.rsi(close, cfg.p1)), listOf(cfg.color), null, 0, 0.0, 100.0,
                if (zones) listOf(20.0, 30.0, 50.0, 70.0, 80.0) else listOf(30.0, 50.0, 70.0),
                "RSI " + cfg.p1, false,
                if (zones) listOf("strong buy", "buy", "average", "sell", "strong sell") else emptyList(),
            )
        }
        "MACD" -> {
            val fast = Ind.ema(close, cfg.p1)
            val slow = Ind.ema(close, cfg.p2)
            val macd = DoubleArray(n) { fast[it] - slow[it] }
            val sig = Ind.ema(macd, cfg.p3)
            val hist = DoubleArray(n) { macd[it] - sig[it] }
            IndOut(listOf(macd, sig), listOf(cfg.color, 0xFFFFB020), hist, 2, nan, nan, listOf(0.0), "MACD " + cfg.p1 + " " + cfg.p2 + " " + cfg.p3, false)
        }
        "STOCH" -> {
            val k = Ind.sma(Ind.stochRaw(cs, cfg.p1), cfg.p2)
            val d = Ind.sma(k, cfg.p3)
            IndOut(listOf(k, d), listOf(cfg.color, 0xFFFFB020), null, 0, 0.0, 100.0, listOf(20.0, 80.0), "Stoch " + cfg.p1 + " " + cfg.p2 + " " + cfg.p3, false)
        }
        "ATR" -> IndOut(listOf(Ind.atr(cs, cfg.p1)), listOf(cfg.color), null, 0, nan, nan, emptyList(), "ATR " + cfg.p1, false)
        else -> {
            val vol = DoubleArray(n) { cs[it].v }
            IndOut(emptyList(), emptyList(), vol, 1, 0.0, nan, emptyList(), "Volume", false)
        }
    }
}
