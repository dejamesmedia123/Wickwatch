package online.wickwatch.app

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/*
 * Setup finder: looks for the "return to the origin" setup used in the example charts.
 *
 *   1. A swing high (supply) or swing low (demand) is the ORIGIN.
 *   2. Price leaves it with a fast, strong leg (displacement) and breaks the previous swing low (or high): a break of structure.
 *   3. The zone is the wick/top of the origin candle. It must be thin (tight stop) and must not have been touched since.
 *   4. Price comes back to the zone in a corrective way (not one spike candle).
 *   5. Entry at the zone edge (or after a confirmation), stop just beyond the zone, target at the extreme of the leg.
 *   6. The reward-to-risk must be at least [SetupParams.minRR] and the structure score at least [SetupParams.minScore].
 *
 * Everything is decided candle by candle from CLOSED candles only, so a setup never appears or changes in the past:
 * the same code gives the live alerts and the win-rate history. Short and long use the same code on mirrored prices.
 * If one candle touches both the stop and the target, the stop is assumed first (the cautious reading).
 */

const val ST_FORMING = 0
const val ST_WAITING = 1
const val ST_ACTIVE = 2
const val ST_WIN = 3
const val ST_LOSS = 4
const val ST_DEAD = 5     // was valid but never became a trade (expired, spiked into the zone, failed confirmation...)
const val ST_FLAT = 6     // a trade that ran too long; closed at the last price, not counted as a win or a loss

class SetupParams(
    val dirMask: Int = 3,                 // 1 = shorts, 2 = longs, 3 = both
    val pivotSpan: Int = 3,               // bars on each side that make a swing point
    val minImpulseAtr: Double = 5.0,      // the leg away from the origin must be at least this many ATR
    val maxLegBars: Int = 12,             // ... and reach that within this many bars
    val minEfficiency: Double = 0.55,     // leg size / sum of candle ranges on the leg: how "one-directional" it was
    val minZoneAtr: Double = 0.15,
    val maxZoneAtr: Double = 1.5,         // thicker zones are skipped: the point is a tight stop
    val stopBufAtr: Double = 0.10,
    val reboundAtr: Double = 0.5,         // the leg counts as finished once price has bounced this far off its extreme
    val minPullbackBars: Int = 2,         // at least this many candles between the leg extreme and the return to the zone
    val maxWaitBars: Int = 100,
    val minRR: Double = 3.0,
    val minScore: Int = 65,
    val entryMode: Int = 0,               // 0 limit at the zone, 1 candle confirmation, 2 pullback structure break
    val confirmBars: Int = 5,
    val maxActiveBars: Int = 400,
    // sweep engine (Sweeps.kt)
    val minLegAtr: Double = 2.0,          // price must have left the level by this many ATR before coming back
    val maxPokeAtr: Double = 2.0,         // a wick deeper than this is a real break, not a sweep
    val maxPokeBars: Int = 3,
    val sweepStopBufAtr: Double = 0.15,   // stop sits this far beyond the wick tip
    val minPullBars: Int = 2,
    val pullRatio: Double = 0.8,          // the way back must be this much calmer than the move away
    val pokeMinAtr: Double = 0.02,
    val tgtSpan: Int = 8,                 // bigger swings are used as targets
    val lookback: Int = 300,
    val waitBars: Int = 20,               // limit mode: bars to wait for the return to the level
    // strategies: 0 = sweep (fades the level), 1 = trend break (with the trend), 2 = sweep but only with the trend
    val strategy: Int = 0,
    val trendFilter: Boolean = false,     // sweep engine: take sells only in a downtrend, buys only in an uptrend
    val trendLen: Int = 50,               // trend = EMA of this length falling / rising
    val trendSlopeBars: Int = 10,
    val trendTolAtr: Double = 1.0,        // price may sit this far on the wrong side of the EMA (a pullback)
    val maxRiskAtr: Double = 3.0,         // trend engine: tight stop, at most this many ATR from the entry
    // Ascendis engine (Ascendis.kt)
    val reverse: Boolean = false,         // show the OPPOSITE trade of every setup (same entry, stop and target swapped)
    val emaLen: Int = 400,                // the EMA used as the trend line
    val trendSrc: Int = 0,                // new setups: trend from 0 = 200 EMA, 1 = Trend Ribbon
    val crtMult: Int = 4,                 // CRT: big candle = this many chart candles
    val biasMult: Int = 0,                // bias timeframe = chart timeframe x this (0 = auto, several ratios)
    val hSpan: Int = 2,                   // swing width on the bias timeframe
    val needLiq: Boolean = true,          // the order block must have swept an earlier high/low ("POI + liquidity")
    val mssWindow: Int = 40,              // bars allowed between the high made in the zone and the structure shift
    val pocBack: Int = 3,                 // order block search on the bias timeframe
    val obBack: Int = 5,                  // small order block search on the chart timeframe
)

/** A labelled horizontal line a strategy wants drawn (OCL, $, BOS, MS, DL...). toIdx -1 = until the end of the setup. */
class Mark(val label: String, val price: Double, val fromIdx: Int, val toIdx: Int)

class Setup(val dir: Int, val originIdx: Int, val originT: Long) {
    val marks = ArrayList<Mark>()
    /** dir 1 = short from supply, dir -1 = long from demand. All prices below are real prices. */
    var distal = 0.0          // far edge of the zone (the stop goes just beyond it)
    var proximal = 0.0        // near edge of the zone (the limit entry)
    var entry = 0.0
    var stop = 0.0
    var target = 0.0
    var risk = 0.0
    var rr = 0.0
    var score = 0
    var state = ST_FORMING
    var valid = false         // passed the structure rules (only valid setups are ever shown or alerted)
    var lockIdx = -1          // the candle where the setup became known
    var touchIdx = -1
    var fillIdx = -1
    var endIdx = -1
    var lockT = 0L            // candle times (seconds), for the dashboard
    var fillT = 0L
    var endT = 0L
    var result = 0.0          // in R: +reward/risk for a win, -1 for a loss
    var why = ""
    var kind = ""             // "sweep" (wick through a swing) or "flip" (retest of a broken swing)
    val isLong: Boolean get() = dir == -1
    val resolved: Boolean get() = state == ST_WIN || state == ST_LOSS
    val live: Boolean get() = state == ST_WAITING || state == ST_ACTIVE
    val side: String get() = if (dir == 1) "SHORT" else "LONG"
}

class SetupStats(val wins: Int, val losses: Int, val sumR: Double) {
    val total: Int get() = wins + losses
    val winRate: Double get() = if (total == 0) 0.0 else 100.0 * wins / total
    val avgR: Double get() = if (total == 0) 0.0 else sumR / total
}

class SetupScan(val setups: List<Setup>, val n: Int, val atr: Double) {
    /** The newest [k] setups that ended in a win or a loss, newest first. */
    fun lastResolved(k: Int): List<Setup> = setups.filter { it.resolved }.sortedByDescending { it.endIdx }.take(k)
    fun waiting(): List<Setup> = setups.filter { it.state == ST_WAITING }
    fun active(): List<Setup> = setups.filter { it.state == ST_ACTIVE }
    fun stats(list: List<Setup>): SetupStats {
        var w = 0
        var l = 0
        var r = 0.0
        for (s in list) {
            if (s.state == ST_WIN) w += 1 else if (s.state == ST_LOSS) l += 1 else continue
            r += s.result
        }
        return SetupStats(w, l, r)
    }
    fun statsLast(k: Int): SetupStats = stats(lastResolved(k))
}

private class Cand(val s: Setup, val j: Int) {
    var distal = 0.0
    var prox = 0.0
    var refLow = 0.0
    var atr0 = 0.0
    var legLow = 0.0
    var legLowIdx = 0
    var impLow = Double.MAX_VALUE
    var impLowIdx = -1
    var bosIdx = -1
    var bosMargin = 0.0
    var impDisp = 0.0
    var eff = 0.0
    var confl = 0.0
    var entryM = 0.0
    var stopM = 0.0
    var touchBar = -1
}

object SetupEngine {
    /** For tests and debugging: told why a candidate was thrown away. */
    @Volatile var trace: ((String) -> Unit)? = null

    /**
     * The opposite trade of every setup: the same entry, but the other way, with the old target as its stop and the old stop as its target.
     * So an old win is a loss now (-1R) and an old loss is a win worth 1 / (old reward to risk).
     */
    private fun reversed(sc: SetupScan): SetupScan {
        val out = ArrayList<Setup>()
        for (o in sc.setups) {
            val s = Setup(-o.dir, o.originIdx, o.originT)
            s.distal = o.distal
            s.proximal = o.proximal
            s.entry = o.entry
            s.stop = o.target
            s.target = o.stop
            s.risk = Math.abs(o.target - o.entry)
            s.rr = if (o.rr > 0) 1.0 / o.rr else 0.0
            s.score = o.score
            s.valid = o.valid
            s.lockIdx = o.lockIdx
            s.touchIdx = o.touchIdx
            s.fillIdx = o.fillIdx
            s.endIdx = o.endIdx
            s.lockT = o.lockT
            s.fillT = o.fillT
            s.endT = o.endT
            s.why = o.why
            s.kind = "reversed " + o.kind
            s.marks.addAll(o.marks)
            s.state = when (o.state) { ST_WIN -> ST_LOSS; ST_LOSS -> ST_WIN; else -> o.state }
            s.result = if (o.rr > 0) -o.result / o.rr else 0.0
            out.add(s)
        }
        return SetupScan(out, sc.n, sc.atr)
    }

    fun scan(cs: List<Candle>, p: SetupParams = SetupParams()): SetupScan {
        val sc = scanForward(cs, p)
        return if (p.reverse) reversed(sc) else sc
    }

    private fun scanForward(cs: List<Candle>, p: SetupParams): SetupScan =
        when (p.strategy) {
            1 -> TrendEngine.scan(cs, p)
            3 -> AscendisEngine.scan(cs, p)
            4 -> ExtraEngines.msnr(cs, p)
            5 -> ExtraEngines.orderBlock(cs, p)
            6 -> ExtraEngines.crt(cs, p)
            7 -> ExtraEngines.alchemist(cs, p)
            8 -> ExtraEngines.oml(cs, p)
            else -> SweepEngine.scan(cs, p)
        }

    /** The first engine (return to origin). Kept for reference; not used by the app any more. */
    fun scanOld(cs: List<Candle>, p: SetupParams = SetupParams()): SetupScan {
        val n = cs.size
        val atr = Ind.atr(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 60) return SetupScan(emptyList(), n, last)
        val tr = DoubleArray(n)
        for (i in 0 until n) {
            tr[i] = if (i == 0) cs[i].h - cs[i].l else max(cs[i].h - cs[i].l, max(abs(cs[i].h - cs[i - 1].c), abs(cs[i].l - cs[i - 1].c)))
        }
        val all = ArrayList<Setup>()
        if (p.dirMask and 1 != 0) all.addAll(scanDir(cs, 1, p, atr, tr))
        if (p.dirMask and 2 != 0) all.addAll(scanDir(cs, -1, p, atr, tr))
        all.sortBy { it.originIdx }
        return SetupScan(all, n, last)
    }

    private fun lin(x: Double, a: Double, b: Double): Double = if (b <= a) 0.0 else ((x - a) / (b - a)).coerceIn(0.0, 1.0)

    private fun scanDir(cs: List<Candle>, dir: Int, p: SetupParams, atr: DoubleArray, tr: DoubleArray): List<Setup> {
        val n = cs.size
        val short = dir == 1
        // a long setup is a short setup on mirrored prices
        val hi = DoubleArray(n) { if (short) cs[it].h else -cs[it].l }
        val lo = DoubleArray(n) { if (short) cs[it].l else -cs[it].h }
        val op = DoubleArray(n) { if (short) cs[it].o else -cs[it].o }
        val cl = DoubleArray(n) { if (short) cs[it].c else -cs[it].c }
        fun px(x: Double): Double = if (short) x else -x

        val span = p.pivotSpan
        val out = ArrayList<Setup>()
        val live = ArrayList<Cand>()
        val pivLow = ArrayList<Int>()
        val pivHigh = ArrayList<Int>()

        fun sync(c: Cand) {
            val s = c.s
            s.distal = px(c.distal)
            s.proximal = px(c.prox)
            s.entry = px(c.entryM)
            s.stop = px(c.stopM)
            s.target = px(c.legLow)
            s.risk = abs(c.stopM - c.entryM)
            s.rr = if (s.risk > 0) (c.entryM - c.legLow) / s.risk else 0.0
        }

        fun kill(c: Cand, why: String, k: Int) {
            c.s.state = ST_DEAD
            c.s.why = why
            c.s.endIdx = k
            c.s.endT = cs[k].t
            trace?.invoke((if (short) "SHORT" else "LONG") + " origin#" + c.j + " dropped at #" + k + ": " + why)
        }

        fun pullbackQuality(c: Cand, k: Int): Double {
            val tb = if (c.touchBar >= 0) c.touchBar else k
            val pbBars = tb - c.legLowIdx - 1
            if (pbBars < p.minPullbackBars) return 0.0
            var pb = 0.0
            for (q in c.legLowIdx + 1 until tb) pb += abs(cl[q] - op[q])
            pb /= pbBars
            var lg = 0.0
            var cnt = 0
            for (q in c.j + 1..max(c.impLowIdx, c.j + 1)) {
                lg += abs(cl[q] - op[q])
                cnt += 1
            }
            lg = if (cnt > 0) lg / cnt else 0.0
            if (lg <= 0.0) return 0.5
            return if (pb <= 0.8 * lg) 1.0 else if (pb <= 1.2 * lg) 0.5 else 0.2
        }

        fun score(c: Cand, k: Int, withPullback: Boolean): Int {
            val impStr = c.impDisp / c.atr0
            var pts = 0.0
            pts += 20 * (0.5 + 0.5 * lin(impStr, p.minImpulseAtr, p.minImpulseAtr * 2.5))
            pts += 10 * (0.5 + 0.5 * lin(c.eff, p.minEfficiency, 0.85))
            pts += 10 * (0.5 + 0.5 * lin(c.bosMargin, 0.0, 0.5))
            val thick = (c.distal - c.prox) / c.atr0
            pts += 15 * (0.5 + 0.5 * (1.0 - lin(thick, p.minZoneAtr, p.maxZoneAtr)))
            val risk = c.stopM - c.entryM
            val rr = if (risk > 0) (c.entryM - c.legLow) / risk else 0.0
            pts += 15 * (0.5 + 0.5 * lin(rr, p.minRR, p.minRR * 3))
            pts += 15 * c.confl
            if (withPullback) pts += 15 * pullbackQuality(c, k)
            return pts.roundToInt()
        }

        fun fill(c: Cand, k: Int, entry: Double, sameBarStop: Boolean) {
            val s = c.s
            c.entryM = entry
            c.stopM = c.distal + p.stopBufAtr * c.atr0
            sync(c)
            s.state = ST_ACTIVE
            s.fillIdx = k
            s.fillT = cs[k].t
            if (sameBarStop && hi[k] >= c.stopM) {
                s.state = ST_LOSS
                s.endIdx = k
                s.endT = cs[k].t
                s.result = -1.0
            }
        }

        fun advance(c: Cand, k: Int, evaluate: Boolean) {
            val s = c.s
            if (s.state >= ST_WIN) return
            if (s.state == ST_FORMING || s.state == ST_WAITING) {
                if (lo[k] < c.legLow) {
                    c.legLow = lo[k]
                    c.legLowIdx = k
                }
            }
            if (s.state == ST_FORMING) {
                // the candle right after the origin is the start of the move away and may open inside the zone
                if (k >= c.j + 2 && hi[k] >= c.prox) {
                    kill(c, "zone touched before the leg finished", k)
                    return
                }
                if (k - c.j <= p.maxLegBars && lo[k] < c.impLow) {
                    c.impLow = lo[k]
                    c.impLowIdx = k
                }
                if (cl[k] < c.refLow) {
                    if (c.bosIdx < 0) c.bosIdx = k
                    c.bosMargin = max(c.bosMargin, (c.refLow - cl[k]) / c.atr0)
                }
                if (!evaluate) return
                if (k - c.j > p.maxLegBars + 30) {
                    kill(c, "no clean leg", k)
                    return
                }
                if (c.bosIdx < 0 || c.impLowIdx < 0) return
                val disp = c.distal - c.impLow
                if (disp < p.minImpulseAtr * c.atr0) return
                var sumTr = 0.0
                for (q in c.j + 1..c.impLowIdx) sumTr += tr[q]
                val eff = if (sumTr > 0) disp / sumTr else 0.0
                if (eff < p.minEfficiency) return
                val rebounded = cl[k] - c.legLow >= p.reboundAtr * c.atr0
                if (!(rebounded || k - c.j >= p.maxLegBars)) return
                c.impDisp = disp
                c.eff = eff
                c.entryM = c.prox
                c.stopM = c.distal + p.stopBufAtr * c.atr0
                val risk = c.stopM - c.entryM
                val rr = if (risk > 0) (c.entryM - c.legLow) / risk else 0.0
                if (rr < p.minRR) {
                    kill(c, "reward to risk too low", k)
                    return
                }
                val sc = score(c, k, false)
                if (sc + 15 < p.minScore) {
                    kill(c, "structure score too low", k)
                    return
                }
                s.valid = true
                s.state = ST_WAITING
                s.lockIdx = k
                s.lockT = cs[k].t
                s.score = sc
                sync(c)
                out.add(s)
                return
            }
            if (s.state == ST_WAITING) {
                if (!evaluate) return
                if (k - s.lockIdx > p.maxWaitBars) {
                    kill(c, "expired without a return to the zone", k)
                    return
                }
                if (p.entryMode == 0) {
                    c.entryM = c.prox
                    c.stopM = c.distal + p.stopBufAtr * c.atr0
                    if (hi[k] >= c.prox) {
                        s.touchIdx = k
                        if (k - c.legLowIdx - 1 < p.minPullbackBars) {
                            kill(c, "spiked into the zone", k)
                            return
                        }
                        val sc = score(c, k, true)
                        s.score = sc
                        if (sc < p.minScore) {
                            kill(c, "pullback not corrective", k)
                            return
                        }
                        fill(c, k, c.prox, true)
                        return
                    }
                } else {
                    if (c.touchBar < 0 && hi[k] >= c.prox) {
                        c.touchBar = k
                        s.touchIdx = k
                        if (k - c.legLowIdx - 1 < p.minPullbackBars) {
                            kill(c, "spiked into the zone", k)
                            return
                        }
                    }
                    if (c.touchBar >= 0) {
                        if (cl[k] > c.distal) {
                            kill(c, "zone failed", k)
                            return
                        }
                        if (k - c.touchBar > p.confirmBars) {
                            kill(c, "no confirmation", k)
                            return
                        }
                        val range = hi[k] - lo[k]
                        val bearish = cl[k] < op[k]
                        var ok = false
                        if (p.entryMode == 1) {
                            val wick = hi[k] - max(op[k], cl[k])
                            ok = bearish && cl[k] < c.prox && k >= 1 && (cl[k] < lo[k - 1] || (range > 0 && wick >= 0.5 * range))
                        } else if (k >= 3) {
                            ok = bearish && cl[k] < min(lo[k - 1], min(lo[k - 2], lo[k - 3]))
                        }
                        if (ok) {
                            val stopM = c.distal + p.stopBufAtr * c.atr0
                            val risk = stopM - cl[k]
                            val rr = if (risk > 0) (cl[k] - c.legLow) / risk else 0.0
                            if (rr < p.minRR) {
                                kill(c, "reward to risk too low after confirmation", k)
                                return
                            }
                            c.entryM = cl[k]
                            c.stopM = stopM
                            val sc = score(c, k, true)
                            s.score = sc
                            if (sc < p.minScore) {
                                kill(c, "pullback not corrective", k)
                                return
                            }
                            fill(c, k, cl[k], false)
                            return
                        }
                    }
                }
                sync(c)
                return
            }
            if (s.state == ST_ACTIVE && k > s.fillIdx) {
                if (hi[k] >= c.stopM) {
                    s.state = ST_LOSS
                    s.endIdx = k
                    s.endT = cs[k].t
                    s.result = -1.0
                } else if (lo[k] <= c.legLow) {
                    s.state = ST_WIN
                    s.endIdx = k
                    s.endT = cs[k].t
                    s.result = s.rr
                } else if (k - s.fillIdx > p.maxActiveBars) {
                    s.state = ST_FLAT
                    s.endIdx = k
                    s.endT = cs[k].t
                    s.result = if (s.risk > 0) (c.entryM - cl[k]) / s.risk else 0.0
                }
            }
        }

        for (i in 0 until n) {
            var k = 0
            while (k < live.size) {
                val c = live[k]
                advance(c, i, true)
                if (c.s.state >= ST_WIN) live.removeAt(k) else k += 1
            }

            val j = i - span
            if (j - span < 0) continue
            var isH = true
            var isL = true
            for (q in j - span until j) {
                if (hi[q] >= hi[j]) isH = false
                if (lo[q] <= lo[j]) isL = false
            }
            for (q in j + 1..j + span) {
                if (hi[q] > hi[j]) isH = false
                if (lo[q] < lo[j]) isL = false
            }
            if (isL) pivLow.add(j)
            if (isH) {
                val a0 = atr[j]
                var refIdx = -1
                for (q in pivLow.indices.reversed()) {
                    if (pivLow[q] < j) {
                        refIdx = pivLow[q]
                        break
                    }
                }
                if (!a0.isNaN() && a0 > 0 && refIdx >= 0) {
                    val dist = hi[j]
                    var prox = max(op[j], cl[j])
                    if (dist - prox < p.minZoneAtr * a0) prox = dist - p.minZoneAtr * a0
                    var dup = false
                    for (c in live) if (abs(c.distal - dist) <= 0.5 * a0) dup = true
                    if (dist - prox <= p.maxZoneAtr * a0 && !dup) {
                        val s = Setup(dir, j, cs[j].t)
                        val c = Cand(s, j)
                        c.distal = dist
                        c.prox = prox
                        c.refLow = lo[refIdx]
                        c.atr0 = a0
                        c.legLow = Double.MAX_VALUE
                        c.legLowIdx = j
                        var eq = 0
                        for (q in pivHigh) if (q >= j - 300 && abs(hi[q] - dist) <= 0.4 * a0) eq += 1
                        c.confl = if (eq >= 2) 1.0 else if (eq == 1) 0.6 else 0.0
                        // bars after the origin that are already closed: track them quietly, then judge at this bar
                        for (q in j + 1 until i) advance(c, q, false)
                        advance(c, i, true)
                        if (c.s.state < ST_WIN) live.add(c)
                    }
                }
                pivHigh.add(j)
            }
        }
        return out
    }
}
