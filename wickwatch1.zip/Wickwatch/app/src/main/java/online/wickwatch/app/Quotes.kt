package online.wickwatch.app

import androidx.compose.runtime.mutableStateMapOf

/** The latest price of a market and how much it moved over the last day. */
class Quote(val price: Double, val change: Double, val pct: Double, val spark: FloatArray = FloatArray(0))

/**
 * Last prices for the Watchlist rows. The background watcher fills them live; for a market the watcher is not
 * following, the candles saved on the phone give the last known price.
 */
object Quotes {
    val live = mutableStateMapOf<String, Quote>()

    fun key(marketKey: String, tf: Int): String = marketKey + "|" + tf

    fun make(candles: List<Candle>, price: Double): Quote? {
        if (candles.isEmpty() || price.isNaN() || price <= 0.0) return null
        val last = candles[candles.size - 1]
        // the close one day earlier, or the first candle held when there is less than a day of them
        var ref = candles[0].o
        var i = candles.size - 1
        while (i >= 0) {
            if (candles[i].t <= last.t - 86400L) {
                ref = candles[i].c
                break
            }
            i -= 1
        }
        if (ref == 0.0) return null
        // about 32 points from the last 96 closes, for the small line in the Watchlist
        val from = maxOf(0, candles.size - 96)
        val n = candles.size - from
        val step = maxOf(1, n / 32)
        val pts = ArrayList<Float>()
        var k = candles.size - 1
        while (k >= from) {
            pts.add(candles[k].c.toFloat())
            k -= step
        }
        pts.reverse()
        return Quote(price, price - ref, (price / ref - 1.0) * 100.0, pts.toFloatArray())
    }

    fun update(marketKey: String, tf: Int, candles: List<Candle>, price: Double) {
        val q = make(candles, price) ?: return
        live[key(marketKey, tf)] = q
    }

    /** From the saved candles, for a market that has no live quote. */
    fun fromSaved(market: Market, tf: Int): Quote? {
        val list = CandleCache.load(market, tf)
        if (list.isEmpty()) return null
        return make(list, list[list.size - 1].c)
    }
}
