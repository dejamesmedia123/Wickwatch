package online.wickwatch.app

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.min

/** What the watcher remembers about one market + timeframe between candles. */
class SeriesState {
    val startedAt = System.currentTimeMillis()
    var baselineDone = false            // the first analysis only records what is already true, it does not alert
    var lastClosedT = 0L
    var lastNearAt = 0L
    var ribbon: RibbonResult? = null
    var iso: IsoResult? = null
    var levels: LevelsResult? = null
    var setups: Map<Int, SetupScan> = emptyMap()
    val isoState = IsoState()
}

/** One running feed. [strat] false means the feed only exists to price-check your chart alerts. */
private class Slot(val item: WatchItem, val market: Market, var strat: Boolean) {
    val st = SeriesState()
    var feed: SeriesFeed? = null
}

/**
 * Runs one feed per watched market, analyses each new closed candle (Trend Target Ribbon, Isotropic Trend Lines, key levels),
 * checks your chart alerts on every price update, and sends the alerts.
 */
object Watcher {
    private var scope: CoroutineScope? = null
    private val slots = HashMap<String, Slot>()
    private var ctx: Context? = null
    private var statusFn: (String) -> Unit = {}
    @Volatile var lastUpdate = 0L
    @Volatile var count = 0

    // chart alerts: which side of the level the price was on at the last check (-1 below, 1 at or above)
    private val sideOf = HashMap<String, Int>()
    private val alertLock = Any()
    private var drawCache: Pair<Long, Map<String, Map<String, Drawing>>> = Pair(0L, emptyMap())

    /** True when there is something to watch: a market on the watch list or an active chart alert. */
    fun hasWork(): Boolean = !Expiry.locked && (Store.allWatch().isNotEmpty() || Store.priceAlerts.any { it.active } || Store.indAlerts.any { it.active })

    fun running(): Boolean = scope != null

    fun start(context: Context, onStatus: (String) -> Unit) {
        stop()
        ctx = context.applicationContext
        statusFn = onStatus
        scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        // when this version runs out, stop watching
        scope?.launch {
            while (true) {
                delay(60_000L)
                Expiry.refresh()
                if (Expiry.locked) {
                    WatchService.stop(context.applicationContext)
                    break
                }
            }
        }
        reconcile()
    }

    fun stop() {
        synchronized(this) {
            for (s in slots.values) s.feed?.stop()
            slots.clear()
            scope?.cancel()
            scope = null
            count = 0
            synchronized(alertLock) { sideOf.clear() }
        }
    }

    /** Call after the watch list or the chart alerts changed: starts new feeds and stops the ones that are no longer needed. */
    fun refresh() {
        if (scope == null) return
        reconcile()
    }

    @Synchronized
    private fun reconcile() {
        val sc = scope ?: return
        val need = LinkedHashMap<String, Pair<Market, Int>>()
        val strat = HashSet<String>()
        for (w in Store.allWatch()) {
            val m = marketByKey(w.key) ?: continue
            need[w.id] = Pair(m, w.tf)
            strat.add(w.id)
        }
        for (a in Store.indAlerts) {
            if (!a.active) continue
            val m = marketByKey(a.key) ?: continue
            val id = a.key + "|" + a.tf
            if (id !in need) need[id] = Pair(m, a.tf)
        }
        val alertKeys = HashSet<String>()
        for (a in Store.priceAlerts) if (a.active) alertKeys.add(a.key)
        for (k in alertKeys) {
            val m = marketByKey(k) ?: continue
            if (need.keys.none { it.startsWith("$k|") }) need["$k|300"] = Pair(m, 300)
        }
        for (id in slots.keys.toList()) {
            if (id !in need) slots.remove(id)?.feed?.stop()
        }
        for ((id, v) in need) {
            val have = slots[id]
            if (have != null) {
                have.strat = id in strat
                continue
            }
            val (m, tf) = v
            val slot = Slot(WatchItem(m.key, tf), m, id in strat)
            val feed = SeriesFeed(m, tf, sc, { candles, _, price ->
                try {
                    onTick(slot, candles, price)
                    lastUpdate = System.currentTimeMillis()
                } catch (e: Exception) {
                    // one bad candle must not stop the watcher
                }
            }, { s -> statusFn(m.name + " " + tfLabel(tf) + ": " + s) })
            slot.feed = feed
            slots[id] = slot
            feed.start()
        }
        count = slots.size
        statusFn("Watching " + slots.size + (if (slots.size == 1) " market" else " markets"))
    }

    private fun onTick(slot: Slot, candles: List<Candle>, price: Double) {
        val c = ctx ?: return
        if (price.isNaN() || price <= 0.0) return
        Quotes.update(slot.item.key, slot.item.tf, candles, price)
        checkPriceAlerts(c, slot.market, price)
        checkIndAlerts(c, slot, candles)
        if (!slot.strat) return
        synchronized(slot.st) { onSeries(c, slot.item, slot.market, slot.st, candles, price) }
    }

    // ---- your chart alerts ---------------------------------------------------------------------

    /** Drawings by id for each market that has a line alert, re-read at most every 5 seconds. */
    private fun drawingsFor(key: String): Map<String, Drawing> {
        val now = System.currentTimeMillis()
        val cache = drawCache
        if (now - cache.first > 5000) {
            val keys = HashSet<String>()
            for (a in Store.priceAlerts) if (a.active && a.drawingId.isNotEmpty()) keys.add(a.key)
            val m = HashMap<String, Map<String, Drawing>>()
            for (k in keys) m[k] = Store.loadDrawings(k).associateBy { it.id }
            drawCache = Pair(now, m)
        }
        return drawCache.second[key] ?: emptyMap()
    }

    private fun checkPriceAlerts(c: Context, m: Market, price: Double) {
        var changed = false
        synchronized(alertLock) {
            val nowSec = System.currentTimeMillis() / 1000L
            for (a in Store.priceAlerts) {
                if (!a.active || a.key != m.key) continue
                if (a.expires > 0L && System.currentTimeMillis() > a.expires) {
                    Store.setAlertActive(a.id, false)
                    changed = true
                    continue
                }
                var level = a.level
                if (a.drawingId.isNotEmpty()) {
                    val d = drawingsFor(a.key)[a.drawingId]
                    val v = if (d == null) null else lineValueAt(d, nowSec)
                    if (v == null) {
                        // the line was deleted, so the alert can not work any more
                        Store.setAlertActive(a.id, false)
                        changed = true
                        continue
                    }
                    level = v
                }
                val side = if (price >= level) 1 else -1
                val prev = sideOf[a.id]
                sideOf[a.id] = side
                if (prev == null || prev == side) continue
                val crossedUp = prev < 0 && side > 0
                if (crossedUp != a.above) continue
                val what = if (a.note.isNotBlank()) a.note else "Price level"
                val title = m.name + ": price " + (if (crossedUp) "crossed above " else "crossed below ") + fp(level, m.dec)
                val text = what + ". Price is now " + fp(price, m.dec) + "." + (if (a.drawingId.isNotEmpty()) " (Line alert, the level moves with the line.)" else "")
                Alerts.fire(c, AlertKind.PRICE_ALERT, title, text, "PA:" + a.id + ":" + nowSec,
                    cooldownKey = "PA:" + a.id, cooldownMs = 30_000L, modeOverride = a.mode)
                if (a.once) {
                    Store.setAlertActive(a.id, false)
                    changed = true
                }
            }
        }
        if (changed) {
            val sc = scope
            if (!hasWork()) {
                WatchService.stop(c)
            } else sc?.launch { reconcile() }
        }
    }

    // ---- your indicator alerts -----------------------------------------------------------------

    private val indSide = HashMap<String, Int>()
    private val indLastT = HashMap<String, Long>()

    /** Looks at the last closed candle of this market and timeframe once per candle. */
    private fun checkIndAlerts(c: Context, slot: Slot, candles: List<Candle>) {
        val mine = Store.indAlerts.filter { it.active && it.key == slot.item.key && it.tf == slot.item.tf }
        if (mine.isEmpty() || candles.size < 3) return
        val now = System.currentTimeMillis()
        val closed = candles.size - 2          // the last candle is still forming
        val t = candles[closed].t
        var changed = false
        synchronized(alertLock) {
            for (a in mine) {
                if (a.expires > 0L && now > a.expires) {
                    Store.setIndActive(a.id, false)
                    changed = true
                    continue
                }
                if (indLastT[a.id] == t) continue
                indLastT[a.id] = t
                val close = DoubleArray(closed + 1) { candles[it].c }
                val value: Double
                val ref: Double
                when (a.type) {
                    "RSI" -> {
                        val r = Ind.rsi(close, a.period)
                        value = r[closed]
                        ref = a.level
                    }
                    "EMA" -> {
                        value = close[closed]
                        ref = Ind.ema(close, a.period)[closed]
                    }
                    else -> {
                        value = close[closed]
                        ref = Ind.sma(close, a.period)[closed]
                    }
                }
                if (value.isNaN() || ref.isNaN()) continue
                val side = if (value >= ref) 1 else -1
                val prev = indSide[a.id]
                indSide[a.id] = side
                if (prev == null || prev == side) continue
                val up = side > 0
                if (up != a.above) continue
                val name = if (a.type == "RSI") "RSI(" + a.period + ")" else a.type + "(" + a.period + ")"
                val title = slot.market.name + " " + tfLabel(slot.item.tf) + ": " + (if (a.type == "RSI") name + " crossed " + (if (up) "above " else "below ") + fp(a.level, 1) else "price crossed " + (if (up) "above " else "below ") + name)
                val text = "Indicator alert on a closed candle. Close " + fp(close[closed], slot.market.dec) + (if (a.type == "RSI") ", RSI " + fp(value, 1) else ", " + name + " " + fp(ref, slot.market.dec)) + "."
                Alerts.fire(c, AlertKind.INDICATOR_ALERT, title, text, "IA:" + a.id + ":" + t, modeOverride = a.mode)
                if (a.once) {
                    Store.setIndActive(a.id, false)
                    changed = true
                }
            }
        }
        if (changed) {
            if (!hasWork()) WatchService.stop(c) else scope?.launch { reconcile() }
        }
    }

    // ---- the strategies ------------------------------------------------------------------------

    private fun onSeries(c: Context, w: WatchItem, m: Market, st: SeriesState, candles: List<Candle>, price: Double) {
        val closed = candles.dropLast(1)                  // the last candle is still forming
        if (closed.size < 100) return
        val lastT = closed[closed.size - 1].t
        if (st.lastClosedT != lastT) {
            analyse(c, w, m, st, closed, !st.baselineDone)
            st.lastClosedT = lastT
            st.baselineDone = true
        }
        val now = System.currentTimeMillis()
        if (now - st.lastNearAt >= 2000) {
            st.lastNearAt = now
            nearChecks(c, w, m, st, price, now - st.startedAt < 15_000)
        }
    }

    private fun head(m: Market, w: WatchItem): String = m.name + " " + tfLabel(w.tf)

    private fun bucket(price: Double, atr: Double): Long = Math.round(price / (atr * 0.5))

    /** Once per closed candle. */
    private fun analyse(c: Context, w: WatchItem, m: Market, st: SeriesState, closed: List<Candle>, silent: Boolean) {
        val dec = m.dec
        val last = closed[closed.size - 1]
        val prevClose = closed[closed.size - 2].c

        // Trend Target Ribbon
        val rb = Ribbon.analyze(closed)
        st.ribbon = rb
        val pos = rb.pos
        if (pos != null) {
            val base = w.id + ":" + pos.entryT
            val side = if (pos.dir == 1) "LONG" else "SHORT"
            val tps = StringBuilder()
            for (i in pos.targets.indices) tps.append(" T").append(i + 1).append(' ').append(fp(pos.targets[i], dec)).append(if (i < pos.targets.size - 1) "," else "")
            Alerts.fire(c, AlertKind.RIBBON_SIGNAL, head(m, w) + ": " + side + " signal",
                "Entry " + fp(pos.entry, dec) + ". Stop " + fp(pos.stop, dec) + "." + tps, "RS:" + base, silent = silent)
            for (k in 1..pos.hits) {
                Alerts.fire(c, AlertKind.RIBBON_TARGET, head(m, w) + ": target " + k + " reached",
                    side + " from " + fp(pos.entry, dec) + ". T" + k + " at " + fp(pos.targets[k - 1], dec) + " (" + k + "R).", "RT:" + base + ":" + k, silent = silent)
            }
            if (pos.stopped) {
                Alerts.fire(c, AlertKind.RIBBON_STOP, head(m, w) + ": stop level hit",
                    side + " from " + fp(pos.entry, dec) + ". Stop " + fp(pos.stop, dec) + " was touched" + (if (pos.hits > 0) " after T" + pos.hits else "") + ".", "RX:" + base, silent = silent)
            }
        }

        // Isotropic Trend Lines
        val iso = Iso.analyze(closed, Store.isoPeriod, 5, 0.5, 20)
        st.iso = iso
        for (e in Iso.step(st.isoState, iso, last, dec)) {
            Alerts.fire(c, e.kind, head(m, w) + ": " + e.kind.label.lowercase(), e.text, "ISO:" + w.id + ":" + last.t + ":" + e.key, silent = silent)
        }

        // Key levels: a level from the last analysis is "broken" when this candle closed clearly on the other side of it
        val old = st.levels
        if (old != null && old.atr > 0) {
            for (lv in old.levels) {
                val up = prevClose < lv.price && last.c > lv.price && last.c - lv.price >= 0.1 * old.atr
                val dn = prevClose > lv.price && last.c < lv.price && lv.price - last.c >= 0.1 * old.atr
                if (!up && !dn) continue
                Alerts.fire(c, AlertKind.LEVEL_BROKEN, head(m, w) + ": key level broken " + (if (up) "upward" else "downward"),
                    "Level " + fp(lv.price, dec) + " (" + lv.touches + " touches) closed " + (if (up) "above" else "below") + " at " + fp(last.c, dec) + ".",
                    "LB:" + w.id + ":" + last.t + ":" + bucket(lv.price, old.atr), silent = silent)
            }
        }
        st.levels = Levels.analyze(closed)

        // Setup finder: events are judged on closed candles only. Only events from the last few candles are announced,
        // so old history can never fire again; the id keeps each one to a single alert.
        val found = HashMap<Int, SetupScan>()
        val nC = closed.size
        for (si in 0..8) {
        if (!Store.setupIsOn(si)) continue
        val sc = SetupEngine.scan(closed, Store.setupParams(si))
        found[si] = sc
        val sn = SETUP_SHORT[si]
        for (s in sc.setups) {
            val base = w.id + ":" + s.side + ":" + s.originT + ":" + Store.setupMode + ":" + si
            val risk = fp(s.risk, dec)
            if (s.lockIdx >= nC - 3 && s.lockIdx >= 0) {
                Alerts.fire(c, AlertKind.SETUP_FOUND, head(m, w) + ": " + sn + " " + s.side + " " + s.kind + " setup found",
                    (if (si == 3 || si == 8 || (Store.setupMode == 0 && si != 1)) "Place a limit " + s.side + " at the level " else "Entered at the close, " + s.side + " near ") + fp(s.entry, dec) +
                        ". Stop " + fp(s.stop, dec) + " (risk " + risk + "). Target " + fp(s.target, dec) + " (" + fp(s.rr, 1) + "R). Level " + fp(s.proximal, dec) + ", wick tip " + fp(s.distal, dec) + ".",
                    "SF:" + base, silent = silent)
            }
            if (s.fillIdx >= nC - 3 && s.fillIdx >= 0) {
                Alerts.fire(c, AlertKind.SETUP_ENTRY, head(m, w) + ": " + sn + " " + s.side + " entry triggered",
                    "Entry " + fp(s.entry, dec) + ". Stop " + fp(s.stop, dec) + ". Target " + fp(s.target, dec) + " (" + fp(s.rr, 1) + "R).", "SE:" + base, silent = silent)
            }
            if (s.endIdx >= nC - 3 && s.state == ST_WIN) {
                Alerts.fire(c, AlertKind.SETUP_TARGET, head(m, w) + ": " + sn + " " + s.side + " setup hit its target",
                    "Entry " + fp(s.entry, dec) + ", target " + fp(s.target, dec) + " reached (+" + fp(s.result, 1) + "R).", "ST:" + base, silent = silent)
            }
            if (s.endIdx >= nC - 3 && s.state == ST_LOSS) {
                Alerts.fire(c, AlertKind.SETUP_STOP, head(m, w) + ": " + sn + " " + s.side + " setup stopped out",
                    "Entry " + fp(s.entry, dec) + ", stop " + fp(s.stop, dec) + " was touched (-1R).", "SX:" + base, silent = silent)
            }
        }
        }
        st.setups = found
    }

    /** On every price update, at most every 2 seconds. */
    private fun nearChecks(c: Context, w: WatchItem, m: Market, st: SeriesState, price: Double, silent: Boolean) {
        val dec = m.dec
        val cd = Store.cooldownMin * 60_000L
        val lastT = st.lastClosedT

        val rb = st.ribbon
        if (rb != null) {
            val pos = rb.pos
            if (pos != null && pos.active && pos.hits < pos.targets.size && pos.risk > 0) {
                val tp = pos.targets[pos.hits]
                val approaching = if (pos.dir == 1) price < tp else price > tp
                val distR = abs(price - tp) / pos.risk
                if (approaching && distR <= Store.nearTargetR) {
                    val k = pos.hits + 1
                    Alerts.fire(c, AlertKind.RIBBON_NEAR_TARGET, head(m, w) + ": near target " + k,
                        "Price " + fp(price, dec) + " is " + fp(distR, 2) + "R away from T" + k + " (" + fp(tp, dec) + ").", "RNT:" + w.id + ":" + pos.entryT + ":" + k, silent = silent)
                }
            }
            val n = rb.alma.size
            if (n > 0 && rb.trend[n - 1] != 0) {
                val alma = rb.alma[n - 1]
                val atr = rb.atr[n - 1]
                if (!alma.isNaN() && !atr.isNaN() && atr > 0) {
                    val d = abs(price - alma) / atr
                    if (d <= Store.nearLineAtr) {
                        val dir = if (rb.trend[n - 1] == 1) "UP" else "DOWN"
                        Alerts.fire(c, AlertKind.RIBBON_NEAR_LINE, head(m, w) + ": near the trend line",
                            "Trend " + dir + ". Price " + fp(price, dec) + " is " + fp(d, 2) + " ATR from the trend line (" + fp(alma, dec) + ").", "RNL:" + w.id + ":" + lastT,
                            cooldownKey = "RNL:" + w.id, cooldownMs = cd, silent = silent)
                    }
                }
            }
        }

        val iso = st.iso
        val p = iso?.primary
        if (iso != null && p != null && !iso.atr.isNaN() && iso.atr > 0) {
            val dU = abs(price - p.upper) / iso.atr
            val dL = abs(price - p.lower) / iso.atr
            val inside = price <= p.upper + iso.atr * Store.nearEdgeAtr && price >= p.lower - iso.atr * Store.nearEdgeAtr
            if (inside && min(dU, dL) <= Store.nearEdgeAtr) {
                val ceiling = dU <= dL
                Alerts.fire(c, AlertKind.ISO_NEAR_EDGE, head(m, w) + ": near the channel " + (if (ceiling) "ceiling" else "floor"),
                    "Price " + fp(price, dec) + " is " + fp(min(dU, dL), 2) + " ATR from the " + (if (ceiling) "ceiling " + fp(p.upper, dec) else "floor " + fp(p.lower, dec)) + ".",
                    "INE:" + w.id + ":" + lastT + ":" + (if (ceiling) "u" else "l"), cooldownKey = "INE:" + w.id, cooldownMs = cd, silent = silent)
            }
        }

        for ((si, sc) in st.setups) {
        if (!sc.atr.isNaN() && sc.atr > 0) {
            for (s in sc.setups) {
                if (s.state != ST_WAITING) continue
                // distance still to travel up (short) or down (long) to the entry; negative once price is inside the zone
                val toEntry = if (s.isLong) price - s.entry else s.entry - price
                val insideZone = if (s.isLong) price >= s.stop else price <= s.stop
                if (!insideZone || toEntry / sc.atr > Store.setupNearAtr) continue
                Alerts.fire(c, AlertKind.SETUP_NEAR, head(m, w) + ": price is back at the " + SETUP_SHORT[si] + " " + s.side + " setup",
                    "Price " + fp(price, dec) + ". Entry " + fp(s.entry, dec) + ", stop " + fp(s.stop, dec) + ", target " + fp(s.target, dec) + " (" + fp(s.rr, 1) + "R).",
                    "SN:" + w.id + ":" + s.side + ":" + s.originT + ":" + Store.setupMode + ":" + si, silent = silent)
            }
        }
        }

        val lv = st.levels
        if (lv != null && lv.atr > 0) {
            val tol = Store.nearLevelAtr * lv.atr
            for (l in lv.levels) {
                if (abs(price - l.price) > tol) continue
                val b = bucket(l.price, lv.atr)
                val side = if (price >= l.price) "above" else "below"
                Alerts.fire(c, AlertKind.LEVEL_NEAR, head(m, w) + ": near a key level",
                    "Price " + fp(price, dec) + " is just " + side + " the level " + fp(l.price, dec) + " (" + l.touches + " touches).",
                    "LN:" + w.id + ":" + lastT + ":" + b, cooldownKey = "LN:" + w.id + ":" + b, cooldownMs = cd, silent = silent)
            }
        }
    }
}
