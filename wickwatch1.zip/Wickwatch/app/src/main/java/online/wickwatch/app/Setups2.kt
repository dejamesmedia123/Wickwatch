package online.wickwatch.app

/*
 * Three more setups. All of them decide on CLOSED candles only and use the same Setup result, so they are drawn,
 * counted and alerted like the others. Sells are written once; buys run the same code on mirrored prices.
 * If one candle touches both the stop and the target, the stop counts first.
 *
 *  4  Ribbon MSNR      trend from the Trend Ribbon (or the 200 EMA, see the setting). Levels are the peaks and valleys of the CLOSE
 *                      line (MSNR). In a downtrend: a fresh peak level, or a valley level that was closed through (RBS / SBR flip),
 *                      is a sell zone. First touch with a rejection candle = entry at its close, tight stop, big fixed target (min R).
 *  5  Order block      trend from the 200 EMA or the Trend Ribbon. In a downtrend: the last up candle before a strong drop that closes below
 *                      the recent lows is the order block. A limit sell at the middle of the block, stop above it, target min R.
 *  6  CRT              candle range theory on a bigger candle (chart candles x the CRT multiplier): the next big candle sweeps the high of
 *                      the one before and closes back inside its range = sell, target the low of that range (buy is the mirror).
 */

private class Mir(cs: List<Candle>, val short: Boolean) {
    val n = cs.size
    val o = DoubleArray(n) { if (short) cs[it].o else -cs[it].o }
    val h = DoubleArray(n) { if (short) cs[it].h else -cs[it].l }
    val l = DoubleArray(n) { if (short) cs[it].l else -cs[it].h }
    val c = DoubleArray(n) { if (short) cs[it].c else -cs[it].c }
    fun px(x: Double): Double = if (short) x else -x
}

object ExtraEngines {
    /** Per candle: -1 downtrend, 1 uptrend, 0 unknown. Source 0 = 200 EMA (price side and slope), 1 = Trend Ribbon. */
    fun trendDir(cs: List<Candle>, src: Int): IntArray {
        val n = cs.size
        val out = IntArray(n)
        if (src == 1) {
            val r = Ribbon.analyze(cs)
            for (i in 0 until n) out[i] = r.trend[i]
            return out
        }
        val k = 2.0 / 201.0
        var e = cs[0].c
        val ema = DoubleArray(n)
        for (i in 0 until n) {
            e += k * (cs[i].c - e)
            ema[i] = e
        }
        for (i in 200 until n) {
            val up = ema[i] > ema[i - 10]
            val dn = ema[i] < ema[i - 10]
            out[i] = if (cs[i].c > ema[i] && up) 1 else if (cs[i].c < ema[i] && dn) -1 else 0
        }
        return out
    }

    private fun dirs(cs: List<Candle>, p: SetupParams): IntArray = try { trendDir(cs, p.trendSrc) } catch (e: Exception) { IntArray(cs.size) }

    /** Sets the outcome of a trade that is already filled at [from] (mirrored prices: the trade is a sell). */
    private fun resolve(s: Setup, m: Mir, cs: List<Candle>, from: Int, entry: Double, stop: Double, target: Double, p: SetupParams) {
        s.state = ST_ACTIVE
        var k = from + 1
        while (k < m.n) {
            if (m.h[k] >= stop) { s.state = ST_LOSS; s.endIdx = k; s.endT = cs[k].t; s.result = -1.0; return }
            if (m.l[k] <= target) { s.state = ST_WIN; s.endIdx = k; s.endT = cs[k].t; s.result = s.rr; return }
            if (k - from > p.maxActiveBars) { s.state = ST_FLAT; s.endIdx = k; s.endT = cs[k].t; s.result = (entry - m.c[k]) / (stop - entry); return }
            k += 1
        }
    }

    private fun fill(s: Setup, m: Mir, cs: List<Candle>, kind: String, origin: Int, lock: Int, fillIdx: Int, zoneNear: Double, zoneFar: Double, entry: Double, stop: Double, target: Double, rr: Double) {
        s.kind = kind
        s.valid = true
        s.proximal = m.px(zoneNear)
        s.distal = m.px(zoneFar)
        s.entry = m.px(entry)
        s.stop = m.px(stop)
        s.target = m.px(target)
        s.risk = stop - entry
        s.rr = rr
        s.lockIdx = lock
        s.lockT = cs[lock].t
        s.touchIdx = origin
        if (fillIdx >= 0) {
            s.fillIdx = fillIdx
            s.fillT = cs[fillIdx].t
        }
    }

    // ---------------------------------------------------------------- 4: Ribbon MSNR

    private class Lv(val price: Double, val flipped: Boolean, val born: Int)

    fun msnr(cs: List<Candle>, p: SetupParams): SetupScan {
        val n = cs.size
        val atr = SweepEngine.atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 80) return SetupScan(emptyList(), n, last)
        val td = dirs(cs, p)
        val all = ArrayList<Setup>()
        if (p.dirMask and 1 != 0) all.addAll(msnrDir(cs, atr, td, p, true))
        if (p.dirMask and 2 != 0) all.addAll(msnrDir(cs, atr, td, p, false))
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    private fun msnrDir(cs: List<Candle>, a: DoubleArray, td: IntArray, p: SetupParams, short: Boolean): List<Setup> {
        val m = Mir(cs, short)
        val want = if (short) -1 else 1
        val levels = ArrayList<Lv>()
        val valleys = ArrayList<Lv>()      // valley levels not yet closed through (they may flip into resistance)
        val out = ArrayList<Setup>()
        for (i in 2 until m.n) {
            val at = a[i]
            // 1. touches of the levels we hold
            val it = levels.iterator()
            while (it.hasNext()) {
                val lv = it.next()
                if (i - lv.born > p.lookback) { it.remove(); continue }
                if (m.c[i] > lv.price + 0.5 * at) { it.remove(); continue }               // broken the wrong way
                if (m.h[i] >= lv.price - 0.1 * at && i > lv.born) {
                    it.remove()                                                          // only the first touch counts
                    val poke = m.h[i] - lv.price
                    val rejected = m.c[i] < lv.price && m.c[i] < m.o[i] && poke <= p.maxPokeAtr * at
                    if (rejected && td[i] == want) {
                        val entry = m.c[i]
                        val stop = Math.max(m.h[i], lv.price) + p.sweepStopBufAtr * at
                        val risk = stop - entry
                        if (risk >= 0.2 * at && risk <= p.maxRiskAtr * at) {
                            val s = Setup(if (short) 1 else -1, lv.born, cs[lv.born].t)
                            fill(s, m, cs, if (lv.flipped) "RBS flip" else "MSNR", lv.born, i, i, lv.price, stop, entry, stop, entry - p.minRR * risk, p.minRR)
                            resolve(s, m, cs, i, entry, stop, entry - p.minRR * risk, p)
                            out.add(s)
                        }
                    }
                }
            }
            // 2. valley levels that get closed through become flipped resistance (support turned resistance)
            val vt = valleys.iterator()
            while (vt.hasNext()) {
                val v = vt.next()
                if (i - v.born > p.lookback) { vt.remove(); continue }
                if (m.c[i] < v.price - 0.3 * at) {
                    vt.remove()
                    levels.add(Lv(v.price, true, i))
                }
            }
            // 3. new peak and valley levels on the close line, known one candle later
            val j = i - 1
            if (m.c[j] > m.c[j - 1] && m.c[j] > m.c[i]) levels.add(Lv(m.c[j], false, i))
            if (m.c[j] < m.c[j - 1] && m.c[j] < m.c[i]) valleys.add(Lv(m.c[j], false, i))
        }
        return out
    }

    // ---------------------------------------------------------------- 5: order block with the trend

    private class ObCand(val k: Int, val m: Int, val near: Double, val far: Double, val entry: Double, val stop: Double)

    fun orderBlock(cs: List<Candle>, p: SetupParams): SetupScan {
        val n = cs.size
        val atr = SweepEngine.atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 80) return SetupScan(emptyList(), n, last)
        val td = dirs(cs, p)
        val all = ArrayList<Setup>()
        if (p.dirMask and 1 != 0) all.addAll(obDir(cs, atr, td, p, true))
        if (p.dirMask and 2 != 0) all.addAll(obDir(cs, atr, td, p, false))
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    private fun obDir(cs: List<Candle>, a: DoubleArray, td: IntArray, p: SetupParams, short: Boolean): List<Setup> {
        val m = Mir(cs, short)
        val want = if (short) -1 else 1
        val out = ArrayList<Setup>()
        val live = ArrayList<Pair<ObCand, Setup>>()
        var lastOb = -10
        for (i in 12 until m.n) {
            // 1. waiting order blocks
            val it = live.iterator()
            while (it.hasNext()) {
                val (cd, s) = it.next()
                if (i - cd.m > p.maxWaitBars) { s.state = ST_DEAD; s.why = "price did not come back to the block in time"; s.endIdx = i; s.endT = cs[i].t; it.remove(); continue }
                // the limit is checked FIRST: a candle that reaches it and then closes above the block is a trade (probably a loss), not a "failed block"
                if (i > cd.m && m.h[i] >= cd.entry) {
                    it.remove()
                    s.fillIdx = i
                    s.fillT = cs[i].t
                    if (m.h[i] >= cd.stop) { s.state = ST_LOSS; s.endIdx = i; s.endT = cs[i].t; s.result = -1.0 }
                    else resolve(s, m, cs, i, cd.entry, cd.stop, cd.entry - p.minRR * (cd.stop - cd.entry), p)
                    continue
                }
                if (m.c[i] > cd.far) { s.state = ST_DEAD; s.why = "price closed above the block before it filled the limit"; s.endIdx = i; s.endT = cs[i].t; it.remove(); continue }
            }
            // 2. a new order block: the last up candle before a drop that closes below the recent lows
            if (td[i] != want) continue
            var lowBefore = Double.MAX_VALUE
            for (q in i - 10 until i - 3) lowBefore = Math.min(lowBefore, m.l[q])
            if (m.c[i] >= lowBefore) continue                                            // no break of structure
            var k = -1
            for (q in i - 1 downTo i - 4) if (m.c[q] > m.o[q]) { k = q; break }
            if (k < 0 || k - lastOb < 3) continue
            val at = a[i]
            var low = Double.MAX_VALUE
            for (q in k + 1..i) low = Math.min(low, m.l[q])
            if (m.h[k] - low < p.minLegAtr * at) continue                                // the drop must be strong
            val thick = m.h[k] - m.l[k]
            if (thick < 0.15 * at || thick > p.maxZoneAtr * at) continue
            if (m.c[i] > m.l[k]) continue                                                // must close below the block
            val entry = m.l[k] + 0.5 * thick
            val stop = m.h[k] + p.stopBufAtr * at
            val risk = stop - entry
            if (risk <= 0.0) continue
            if (m.h[i] >= entry) continue                                                // already came back
            lastOb = k
            val s = Setup(if (short) 1 else -1, k, cs[k].t)
            fill(s, m, cs, "order block", k, i, -1, m.l[k], m.h[k], entry, stop, entry - p.minRR * risk, p.minRR)
            s.state = ST_WAITING
            live.add(Pair(ObCand(k, i, m.l[k], m.h[k], entry, stop), s))
            out.add(s)
        }
        return out
    }

    // ---------------------------------------------------------------- 6: CRT

    fun crt(cs: List<Candle>, p: SetupParams): SetupScan {
        val n = cs.size
        val atr = SweepEngine.atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 60) return SetupScan(emptyList(), n, last)
        val mult = Math.max(2, p.crtMult)
        val diffs = ArrayList<Long>()
        for (i in 1 until Math.min(n, 200)) diffs.add(cs[i].t - cs[i - 1].t)
        diffs.sort()
        val step = diffs[diffs.size / 2].coerceAtLeast(1L)
        val span = step * mult
        // big candles from the chart candles (every bucket of `mult` candles on the clock)
        class Big(val first: Int, var last: Int, val o: Double, var h: Double, var l: Double, var c: Double)
        val bigs = ArrayList<Big>()
        for (i in 0 until n) {
            val b = Math.floorDiv(cs[i].t, span)
            val lastBig = bigs.lastOrNull()
            if (lastBig != null && Math.floorDiv(cs[lastBig.first].t, span) == b) {
                lastBig.last = i
                lastBig.h = Math.max(lastBig.h, cs[i].h)
                lastBig.l = Math.min(lastBig.l, cs[i].l)
                lastBig.c = cs[i].c
            } else bigs.add(Big(i, i, cs[i].o, cs[i].h, cs[i].l, cs[i].c))
        }
        val all = ArrayList<Setup>()
        for (short in listOf(true, false)) {
            if (p.dirMask and (if (short) 1 else 2) == 0) continue
            val m = Mir(cs, short)
            // a big candle counts as finished once a later chart candle exists in a newer bucket
            for (q in 1 until bigs.size - 1) {
                val A = bigs[q - 1]
                val B = bigs[q]
                val ah = if (short) A.h else -A.l
                val al = if (short) A.l else -A.h
                val bh = if (short) B.h else -B.l
                val bc = if (short) B.c else -B.c
                if (bh <= ah || bc >= ah || bc <= al) continue                        // must sweep the far side and close back inside
                val i = B.last
                val at = atr[i]
                val entry = bc
                val stop = bh + p.sweepStopBufAtr * at
                val risk = stop - entry
                val target = al
                if (risk < 0.2 * at || entry - target < 1.5 * risk) continue
                val rr = (entry - target) / risk
                val s = Setup(if (short) 1 else -1, A.first, cs[A.first].t)
                fill(s, m, cs, "CRT x" + mult, A.first, i, i, ah, bh, entry, stop, target, rr)
                resolve(s, m, cs, i, entry, stop, target, p)
                all.add(s)
            }
        }
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    // ---------------------------------------------------------------- 7: Alchemist MSNR (dynamic target)

    private class AL(val mp: Double, val resLike: Boolean, val born: Int) {
        var dead = -1
    }

    fun alchemist(cs: List<Candle>, p: SetupParams): SetupScan {
        val n = cs.size
        val atr = SweepEngine.atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 80) return SetupScan(emptyList(), n, last)
        val td = dirs(cs, p)
        val all = ArrayList<Setup>()
        if (p.dirMask and 1 != 0) all.addAll(alchDir(cs, atr, td, p, true))
        if (p.dirMask and 2 != 0) all.addAll(alchDir(cs, atr, td, p, false))
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    private fun alchDir(cs: List<Candle>, a: DoubleArray, td: IntArray, p: SetupParams, short: Boolean): List<Setup> {
        val m = Mir(cs, short)
        val n = m.n
        val want = if (short) -1 else 1
        val levels = ArrayList<AL>()
        fun settle(lv: AL) {
            var k = lv.born + 1
            while (k < n) {
                if (if (lv.resLike) m.h[k] >= lv.mp else m.l[k] <= lv.mp) { lv.dead = k; return }
                k += 1
            }
        }
        // A level: a bullish candle then a bearish one, at the close of the first. V level: the reverse. Marked on closes, not wicks.
        for (j in 1 until n - 1) {
            val bull = cs[j].c > cs[j].o
            val bear = cs[j].c < cs[j].o
            val realRes = if (bull && cs[j + 1].c < cs[j + 1].o) true else if (bear && cs[j + 1].c > cs[j + 1].o) false else continue
            val lv = AL(m.px(cs[j].c), if (short) realRes else !realRes, j + 1)
            settle(lv)
            levels.add(lv)
        }
        // a level that price closes through changes role (RBS / SBR) and is fresh again
        val flips = ArrayList<AL>()
        for (lv in levels) {
            var k = lv.born + 1
            while (k < n) {
                val through = if (lv.resLike) m.c[k] > lv.mp + 0.3 * a[k] else m.c[k] < lv.mp - 0.3 * a[k]
                if (through) {
                    val f = AL(lv.mp, !lv.resLike, k)
                    settle(f)
                    flips.add(f)
                    break
                }
                k += 1
            }
        }
        levels.addAll(flips)

        val out = ArrayList<Setup>()
        for (lv in levels) {
            val t = lv.dead
            if (!lv.resLike || t < 1) continue
            if (m.c[t] >= lv.mp) continue                                        // the touching candle closed through: no reaction
            var e = t
            var hi = m.h[t]
            while (e <= t + 5 && e < n) {
                if (m.c[e] >= lv.mp) break
                if (m.h[e] > hi) hi = m.h[e]
                // confirming candle (cheat sheet): engulfing, a strong close below the level, or a rejection wick that closes back under it
                val body = Math.abs(m.o[e] - m.c[e])
                val rng = Math.max(m.h[e] - m.l[e], 1e-12)
                val engulf = m.c[e] < m.o[e] && m.o[e] >= Math.max(m.o[e - 1], m.c[e - 1]) && m.c[e] <= Math.min(m.o[e - 1], m.c[e - 1])
                val strong = m.c[e] < m.o[e] && body >= 0.6 * rng
                val rejWick = m.h[e] > lv.mp && (m.h[e] - Math.max(m.o[e], m.c[e])) >= 2.0 * body && m.c[e] < lv.mp
                if ((engulf || strong || rejWick) && td[e] == want) {
                    val at = a[e]
                    if (hi - lv.mp > p.maxPokeAtr * at) break
                    val entry = m.c[e]
                    val stop = hi + 0.1 * at
                    val risk = stop - entry
                    if (risk < 0.2 * at || risk > p.maxRiskAtr * at) break
                    // dynamic target: the nearest fresh support below that still pays the minimum reward to risk
                    var tg = Double.NaN
                    for (o in levels) {
                        if (o.resLike || o.born > e || (o.dead in 0..e)) continue
                        if (o.mp < entry - p.minRR * risk && (tg.isNaN() || o.mp > tg)) tg = o.mp
                    }
                    if (tg.isNaN()) break
                    val rr = (entry - tg) / risk
                    val s = Setup(if (short) 1 else -1, lv.born, cs[lv.born].t)
                    fill(s, m, cs, "Alchemist", lv.born, e, e, lv.mp, stop, entry, stop, tg, rr)
                    resolve(s, m, cs, e, entry, stop, tg, p)
                    out.add(s)
                    break
                }
                e += 1
            }
        }
        return out
    }
}
