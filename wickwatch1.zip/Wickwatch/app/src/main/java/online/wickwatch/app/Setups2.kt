package online.wickwatch.app

/*
 * Three more setups. All of them decide on CLOSED candles only and use the same Setup result, so they are drawn,
 * counted and alerted like the others. Sells are written once; buys run the same code on mirrored prices.
 * If one candle touches both the stop and the target, the stop counts first.
 *
 *  4  Ribbon MSNR      trend from the Trend Ribbon (or the EMA (400), see the setting). Levels are the peaks and valleys of the CLOSE
 *                      line (MSNR). In a downtrend: a fresh peak level, or a valley level that was closed through (RBS / SBR flip),
 *                      is a sell zone. First touch with a rejection candle = entry at its close, tight stop, big fixed target (min R).
 *  5  Order block      trend from the EMA (400) or the Trend Ribbon. In a downtrend: the last up candle before a strong drop that closes below
 *                      the recent lows is the order block. A limit sell at the middle of the block, stop above it, target min R.
 *  6  CRT              candle range theory on a bigger candle (chart candles x the CRT multiplier): the next big candle sweeps the high of
 *                      the one before and closes back inside its range = sell, target the low of that range (buy is the mirror).
 */

private class Mir(cs: List<Candle>, val short: Boolean) {
    val n = cs.size
    val o = DoubleArray(n) { if (short) cs[it].o else -cs[it].o }
    val h = DoubleArray(n) { if (short) cs[it].h else -cs[it].l }
    val l = DoubleArray(n) { if (short) cs[it].l else -cs[it].h }
    val c = DoubleArray(n) { if (short) cs[it].c else -cs[it].c }
    fun px(x: Double): Double = if (short) x else -x
}

object ExtraEngines {
    /** Per candle: -1 downtrend, 1 uptrend, 0 unknown. Source 0 = the EMA (default 400; price side and slope), 1 = Trend Ribbon. */
    fun trendDir(cs: List<Candle>, src: Int, len: Int = 400): IntArray {
        val n = cs.size
        val out = IntArray(n)
        if (src == 1) {
            val r = Ribbon.analyze(cs)
            for (i in 0 until n) out[i] = r.trend[i]
            return out
        }
        val k = 2.0 / (len + 1.0)
        var e = cs[0].c
        val ema = DoubleArray(n)
        for (i in 0 until n) {
            e += k * (cs[i].c - e)
            ema[i] = e
        }
        for (i in len until n) {
            val up = ema[i] > ema[i - 10]
            val dn = ema[i] < ema[i - 10]
            out[i] = if (cs[i].c > ema[i] && up) 1 else if (cs[i].c < ema[i] && dn) -1 else 0
        }
        return out
    }

    private fun dirs(cs: List<Candle>, p: SetupParams): IntArray = try { trendDir(cs, p.trendSrc, p.emaLen) } catch (e: Exception) { IntArray(cs.size) }

    /** Sets the outcome of a trade that is already filled at [from] (mirrored prices: the trade is a sell). */
    private fun resolve(s: Setup, m: Mir, cs: List<Candle>, from: Int, entry: Double, stop: Double, target: Double, p: SetupParams) {
        s.state = ST_ACTIVE
        var k = from + 1
        while (k < m.n) {
            if (m.h[k] >= stop) { s.state = ST_LOSS; s.endIdx = k; s.endT = cs[k].t; s.result = -1.0; return }
            if (m.l[k] <= target) { s.state = ST_WIN; s.endIdx = k; s.endT = cs[k].t; s.result = s.rr; return }
            if (k - from > p.maxActiveBars) { s.state = ST_FLAT; s.endIdx = k; s.endT = cs[k].t; s.result = (entry - m.c[k]) / (stop - entry); return }
            k += 1
        }
    }

    private fun fill(s: Setup, m: Mir, cs: List<Candle>, kind: String, origin: Int, lock: Int, fillIdx: Int, zoneNear: Double, zoneFar: Double, entry: Double, stop: Double, target: Double, rr: Double) {
        s.kind = kind
        s.valid = true
        s.proximal = m.px(zoneNear)
        s.distal = m.px(zoneFar)
        s.entry = m.px(entry)
        s.stop = m.px(stop)
        s.target = m.px(target)
        s.risk = stop - entry
        s.rr = rr
        s.lockIdx = lock
        s.lockT = cs[lock].t
        s.touchIdx = origin
        if (fillIdx >= 0) {
            s.fillIdx = fillIdx
            s.fillT = cs[fillIdx].t
        }
    }

    // ---------------------------------------------------------------- 4: Ribbon MSNR

    private class Lv(val price: Double, val flipped: Boolean, val born: Int)

    fun msnr(cs: List<Candle>, p: SetupParams): SetupScan {
        val n = cs.size
        val atr = SweepEngine.atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 80) return SetupScan(emptyList(), n, last)
        val td = dirs(cs, p)
        val all = ArrayList<Setup>()
        if (p.dirMask and 1 != 0) all.addAll(msnrDir(cs, atr, td, p, true))
        if (p.dirMask and 2 != 0) all.addAll(msnrDir(cs, atr, td, p, false))
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    private fun msnrDir(cs: List<Candle>, a: DoubleArray, td: IntArray, p: SetupParams, short: Boolean): List<Setup> {
        val m = Mir(cs, short)
        val want = if (short) -1 else 1
        val levels = ArrayList<Lv>()
        val valleys = ArrayList<Lv>()      // valley levels not yet closed through (they may flip into resistance)
        val out = ArrayList<Setup>()
        for (i in 2 until m.n) {
            val at = a[i]
            // 1. touches of the levels we hold
            val it = levels.iterator()
            while (it.hasNext()) {
                val lv = it.next()
                if (i - lv.born > p.lookback) { it.remove(); continue }
                if (m.c[i] > lv.price + 0.5 * at) { it.remove(); continue }               // broken the wrong way
                if (m.h[i] >= lv.price - 0.1 * at && i > lv.born) {
                    it.remove()                                                          // only the first touch counts
                    val poke = m.h[i] - lv.price
                    val rejected = m.c[i] < lv.price && m.c[i] < m.o[i] && poke <= p.maxPokeAtr * at
                    if (rejected && td[i] == want) {
                        val entry = m.c[i]
                        val stop = Math.max(m.h[i], lv.price) + p.sweepStopBufAtr * at
                        val risk = stop - entry
                        if (risk >= 0.2 * at && risk <= p.maxRiskAtr * at) {
                            val s = Setup(if (short) 1 else -1, lv.born, cs[lv.born].t)
                            fill(s, m, cs, if (lv.flipped) "RBS flip" else "MSNR", lv.born, i, i, lv.price, stop, entry, stop, entry - p.minRR * risk, p.minRR)
                            resolve(s, m, cs, i, entry, stop, entry - p.minRR * risk, p)
                            out.add(s)
                        }
                    }
                }
            }
            // 2. valley levels that get closed through become flipped resistance (support turned resistance)
            val vt = valleys.iterator()
            while (vt.hasNext()) {
                val v = vt.next()
                if (i - v.born > p.lookback) { vt.remove(); continue }
                if (m.c[i] < v.price - 0.3 * at) {
                    vt.remove()
                    levels.add(Lv(v.price, true, i))
                }
            }
            // 3. new peak and valley levels on the close line, known one candle later
            val j = i - 1
            if (m.c[j] > m.c[j - 1] && m.c[j] > m.c[i]) levels.add(Lv(m.c[j], false, i))
            if (m.c[j] < m.c[j - 1] && m.c[j] < m.c[i]) valleys.add(Lv(m.c[j], false, i))
        }
        return out
    }

    // ---------------------------------------------------------------- 5: order block with the trend

    private class ObCand(val k: Int, val m: Int, val near: Double, val far: Double, val entry: Double, val stop: Double)

    fun orderBlock(cs: List<Candle>, p: SetupParams): SetupScan {
        val n = cs.size
        val atr = SweepEngine.atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 80) return SetupScan(emptyList(), n, last)
        val td = dirs(cs, p)
        val all = ArrayList<Setup>()
        if (p.dirMask and 1 != 0) all.addAll(obDir(cs, atr, td, p, true))
        if (p.dirMask and 2 != 0) all.addAll(obDir(cs, atr, td, p, false))
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    private fun obDir(cs: List<Candle>, a: DoubleArray, td: IntArray, p: SetupParams, short: Boolean): List<Setup> {
        val m = Mir(cs, short)
        val want = if (short) -1 else 1
        val out = ArrayList<Setup>()
        val live = ArrayList<Pair<ObCand, Setup>>()
        var lastOb = -10
        for (i in 12 until m.n) {
            // 1. waiting order blocks
            val it = live.iterator()
            while (it.hasNext()) {
                val (cd, s) = it.next()
                if (m.c[i] > cd.far) { s.state = ST_DEAD; s.endIdx = i; s.endT = cs[i].t; it.remove(); continue }   // closed above the block: it failed
                if (i - cd.m > p.maxWaitBars) { s.state = ST_DEAD; s.endIdx = i; s.endT = cs[i].t; it.remove(); continue }
                if (i > cd.m && m.h[i] >= cd.entry) {
                    it.remove()
                    s.fillIdx = i
                    s.fillT = cs[i].t
                    if (m.h[i] >= cd.stop) { s.state = ST_LOSS; s.endIdx = i; s.endT = cs[i].t; s.result = -1.0 }
                    else resolve(s, m, cs, i, cd.entry, cd.stop, cd.entry - p.minRR * (cd.stop - cd.entry), p)
                }
            }
            // 2. a new order block: the last up candle before a drop that closes below the recent lows
            if (td[i] != want) continue
            var lowBefore = Double.MAX_VALUE
            for (q in i - 10 until i - 3) lowBefore = Math.min(lowBefore, m.l[q])
            if (m.c[i] >= lowBefore) continue                                            // no break of structure
            var k = -1
            for (q in i - 1 downTo i - 4) if (m.c[q] > m.o[q]) { k = q; break }
            if (k < 0 || k - lastOb < 3) continue
            val at = a[i]
            var low = Double.MAX_VALUE
            for (q in k + 1..i) low = Math.min(low, m.l[q])
            if (m.h[k] - low < p.minLegAtr * at) continue                                // the drop must be strong
            val thick = m.h[k] - m.l[k]
            if (thick < 0.15 * at || thick > p.maxZoneAtr * at) continue
            if (m.c[i] > m.l[k]) continue                                                // must close below the block
            val entry = m.l[k] + 0.5 * thick
            val stop = m.h[k] + p.stopBufAtr * at
            val risk = stop - entry
            if (risk <= 0.0) continue
            if (m.h[i] >= entry) continue                                                // already came back
            lastOb = k
            val s = Setup(if (short) 1 else -1, k, cs[k].t)
            fill(s, m, cs, "order block", k, i, -1, m.l[k], m.h[k], entry, stop, entry - p.minRR * risk, p.minRR)
            s.state = ST_WAITING
            live.add(Pair(ObCand(k, i, m.l[k], m.h[k], entry, stop), s))
            out.add(s)
        }
        return out
    }

    // ---------------------------------------------------------------- 6: CRT

    fun crt(cs: List<Candle>, p: SetupParams): SetupScan {
        val n = cs.size
        val atr = SweepEngine.atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 60) return SetupScan(emptyList(), n, last)
        val mult = Math.max(2, p.crtMult)
        val diffs = ArrayList<Long>()
        for (i in 1 until Math.min(n, 200)) diffs.add(cs[i].t - cs[i - 1].t)
        diffs.sort()
        val step = diffs[diffs.size / 2].coerceAtLeast(1L)
        val span = step * mult
        // big candles from the chart candles (every bucket of `mult` candles on the clock)
        class Big(val first: Int, var last: Int, val o: Double, var h: Double, var l: Double, var c: Double)
        val bigs = ArrayList<Big>()
        for (i in 0 until n) {
            val b = Math.floorDiv(cs[i].t, span)
            val lastBig = bigs.lastOrNull()
            if (lastBig != null && Math.floorDiv(cs[lastBig.first].t, span) == b) {
                lastBig.last = i
                lastBig.h = Math.max(lastBig.h, cs[i].h)
                lastBig.l = Math.min(lastBig.l, cs[i].l)
                lastBig.c = cs[i].c
            } else bigs.add(Big(i, i, cs[i].o, cs[i].h, cs[i].l, cs[i].c))
        }
        val all = ArrayList<Setup>()
        for (short in listOf(true, false)) {
            if (p.dirMask and (if (short) 1 else 2) == 0) continue
            val m = Mir(cs, short)
            // a big candle counts as finished once a later chart candle exists in a newer bucket
            for (q in 1 until bigs.size - 1) {
                val A = bigs[q - 1]
                val B = bigs[q]
                val ah = if (short) A.h else -A.l
                val al = if (short) A.l else -A.h
                val bh = if (short) B.h else -B.l
                val bc = if (short) B.c else -B.c
                if (bh <= ah || bc >= ah || bc <= al) continue                        // must sweep the far side and close back inside
                val i = B.last
                val at = atr[i]
                val entry = bc
                val stop = bh + p.sweepStopBufAtr * at
                val risk = stop - entry
                val target = al
                if (risk < 0.2 * at || entry - target < 1.5 * risk) continue
                val rr = (entry - target) / risk
                val s = Setup(if (short) 1 else -1, A.first, cs[A.first].t)
                fill(s, m, cs, "CRT x" + mult, A.first, i, i, ah, bh, entry, stop, target, rr)
                resolve(s, m, cs, i, entry, stop, target, p)
                all.add(s)
            }
        }
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    // ---------------------------------------------------------------- 7: Alchemist MSNR (dynamic target)

    private class AL(val mp: Double, val resLike: Boolean, val born: Int, val flip: Boolean = false) {
        var dead = -1
    }

    fun alchemist(cs: List<Candle>, p: SetupParams): SetupScan {
        val n = cs.size
        val atr = SweepEngine.atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 80) return SetupScan(emptyList(), n, last)
        val td = dirs(cs, p)
        val all = ArrayList<Setup>()
        if (p.dirMask and 1 != 0) all.addAll(alchDir(cs, atr, td, p, true))
        if (p.dirMask and 2 != 0) all.addAll(alchDir(cs, atr, td, p, false))
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    private fun alchDir(cs: List<Candle>, a: DoubleArray, td: IntArray, p: SetupParams, short: Boolean): List<Setup> {
        val m = Mir(cs, short)
        val n = m.n
        val want = if (short) -1 else 1
        val levels = ArrayList<AL>()
        fun settle(lv: AL) {
            var k = lv.born + 1
            while (k < n) {
                if (if (lv.resLike) m.h[k] >= lv.mp else m.l[k] <= lv.mp) { lv.dead = k; return }
                k += 1
            }
        }
        // A level: a bullish candle then a bearish one, at the close of the first. V level: the reverse. Marked on closes, not wicks.
        for (j in 1 until n - 1) {
            val bull = cs[j].c > cs[j].o
            val bear = cs[j].c < cs[j].o
            val realRes = if (bull && cs[j + 1].c < cs[j + 1].o) true else if (bear && cs[j + 1].c > cs[j + 1].o) false else continue
            val lv = AL(m.px(cs[j].c), if (short) realRes else !realRes, j + 1)
            settle(lv)
            levels.add(lv)
        }
        // a level that price closes through changes role (RBS / SBR) and is fresh again
        val flips = ArrayList<AL>()
        for (lv in levels) {
            var k = lv.born + 1
            while (k < n) {
                val through = if (lv.resLike) m.c[k] > lv.mp + 0.3 * a[k] else m.c[k] < lv.mp - 0.3 * a[k]
                if (through) {
                    val f = AL(lv.mp, !lv.resLike, k, true)
                    settle(f)
                    flips.add(f)
                    break
                }
                k += 1
            }
        }
        levels.addAll(flips)

        val out = ArrayList<Setup>()
        // The book: a level can be used at most 2 times (each wick touch is one use); a full-body break makes it fresh again (that is the flip, handled above)
        for (lv in levels) {
            if (!lv.resLike) continue
            var uses = 0
            var t = lv.born + 1
            while (t < n && uses < 2) {
                if (m.c[t] > lv.mp + 0.3 * a[t]) break                       // broken through with a body: this level is finished (the flip is its own level)
                if (m.h[t] < lv.mp) { t += 1; continue }                     // not touched yet
                uses += 1
                if (m.c[t] >= lv.mp) { t += 1; continue }                    // the touching candle closed through: no reaction
                var e = t
                var hi = m.h[t]
                var took = false
                while (e <= t + 5 && e < n) {
                    if (m.c[e] >= lv.mp) break
                    if (m.h[e] > hi) hi = m.h[e]
                    // confirming candle (cheat sheet): engulfing, a strong close below the level, or a rejection wick that closes back under it
                    val body = Math.abs(m.o[e] - m.c[e])
                    val rng = Math.max(m.h[e] - m.l[e], 1e-12)
                    val engulf = m.c[e] < m.o[e] && m.o[e] >= Math.max(m.o[e - 1], m.c[e - 1]) && m.c[e] <= Math.min(m.o[e - 1], m.c[e - 1])
                    val strong = m.c[e] < m.o[e] && body >= 0.6 * rng
                    val rejWick = m.h[e] > lv.mp && (m.h[e] - Math.max(m.o[e], m.c[e])) >= 2.0 * body && m.c[e] < lv.mp
                    if ((engulf || strong || rejWick) && td[e] == want) {
                        val at = a[e]
                        if (hi - lv.mp > p.maxPokeAtr * at) break
                        val entry = m.c[e]
                        val stop = hi + 0.1 * at
                        val risk = stop - entry
                        if (risk < 0.2 * at || risk > p.maxRiskAtr * at) break
                        // dynamic target: the nearest fresh support below that still pays the minimum reward to risk
                        var tg = Double.NaN
                        for (o in levels) {
                            if (o.resLike || o.born > e || (o.dead in 0..e)) continue
                            if (o.mp < entry - p.minRR * risk && (tg.isNaN() || o.mp > tg)) tg = o.mp
                        }
                        if (tg.isNaN()) break
                        val rr = (entry - tg) / risk
                        val s = Setup(if (short) 1 else -1, lv.born, cs[lv.born].t)
                        fill(s, m, cs, if (lv.born > 0 && lv.flip) "Alchemist RBS/SBR" else "Alchemist", lv.born, e, e, lv.mp, stop, entry, stop, tg, rr)
                        resolve(s, m, cs, e, entry, stop, tg, p)
                        out.add(s)
                        took = true
                        break
                    }
                    e += 1
                }
                t = if (took) e + 1 else t + 1
            }
        }
        return out
    }

    // ---------------------------------------------------------------- the Alchemist levels indicator (no trades, just the levels)

    class AlchLevel(val price: Double, val label: String, val fresh: Boolean, val uses: Int, val bornIdx: Int)

    /**
     * Levels as the book marks them: on closing prices (a bullish candle then a bearish one = A, the reverse = V). Fresh = never touched by a wick,
     * unfresh = touched (shown with the number of uses, 2 is the most), a full-body close through turns the level into RBS / SBR and fresh again.
     * Gives the levels nearest to the last price.
     */
    fun alchemistLevels(cs: List<Candle>, maxLevels: Int = 24): List<AlchLevel> {
        val n = cs.size
        if (n < 30) return emptyList()
        val a = SweepEngine.atrWilder(cs, 14)
        val last = cs[n - 1].c
        val out = ArrayList<AlchLevel>()
        fun touches(price: Double, isRes: Boolean, from: Int): Int {
            var u = 0
            var k = from
            var inside = false
            while (k < n) {
                val hit = if (isRes) cs[k].h >= price else cs[k].l <= price
                if (hit && !inside) u += 1
                inside = hit
                k += 1
            }
            return u
        }
        for (j in 1 until n - 1) {
            val bull = cs[j].c > cs[j].o
            val bear = cs[j].c < cs[j].o
            val isRes = if (bull && cs[j + 1].c < cs[j + 1].o) true else if (bear && cs[j + 1].c > cs[j + 1].o) false else continue
            val price = cs[j].c
            // a full body through the level?
            var through = -1
            var k = j + 2
            while (k < n) {
                if (if (isRes) cs[k].c > price + 0.3 * a[k] else cs[k].c < price - 0.3 * a[k]) { through = k; break }
                k += 1
            }
            if (through < 0) {
                val u = touches(price, isRes, j + 2)
                if (u <= 2) out.add(AlchLevel(price, if (isRes) "A" else "V", u == 0, u, j))
            } else {
                // flipped: resistance that was closed above is RBS (support now), support closed below is SBR
                val u = touches(price, !isRes, through + 1)
                if (u <= 2) out.add(AlchLevel(price, if (isRes) "RBS" else "SBR", u == 0, u, through))
            }
        }
        out.sortBy { Math.abs(it.price - last) }
        return out.take(maxLevels)
    }

    // ---------------------------------------------------------------- 8: OML 2.9 (original close level)

    private class OBar(val first: Int, var last: Int, val o: Double, var h: Double, var l: Double, var c: Double)

    /**
     * OML 2.9. A bigger-timeframe candle (chart candles x the bias multiple, default 6: 30M -> 3H, 5M -> 30M; use 12 for 5M -> 1H)
     * closes through a swing low (BOS) after opening above it. The OPEN of that candle is the OCL. The first bigger candle after it
     * gives the $ (liquidity) level. Price then has to come back up to the OCL: a limit sell at the OCL (if the zone up to its top is taller than
     * maxZoneAtr ATR, the long wick is split in two and the limit sits at the middle), stop above the top of the
     * zone, target DL = the nearest liquidity below that still pays at least the minimum reward to risk. Buys are the mirror image.
     * Everything drawn (OCL, $, BOS, MS, DL, the zone and the position box) is stored on the setup as marks.
     */
    fun oml(cs: List<Candle>, p: SetupParams): SetupScan {
        val n = cs.size
        val atr = SweepEngine.atrWilder(cs, 14)
        val last = if (n > 0) atr[n - 1] else Double.NaN
        if (n < 150) return SetupScan(emptyList(), n, last)
        val mult = if (p.biasMult >= 2) p.biasMult else 6
        val diffs = ArrayList<Long>()
        for (i in 1 until Math.min(n, 200)) diffs.add(cs[i].t - cs[i - 1].t)
        diffs.sort()
        val step = diffs[diffs.size / 2].coerceAtLeast(1L)
        val span = step * mult
        val all = ArrayList<Setup>()
        if (p.dirMask and 1 != 0) all.addAll(omlDir(cs, atr, span, p, true))
        if (p.dirMask and 2 != 0) all.addAll(omlDir(cs, atr, span, p, false))
        all.sortBy { it.lockIdx }
        return SetupScan(all, n, last)
    }

    private fun omlDir(cs: List<Candle>, a: DoubleArray, span: Long, p: SetupParams, short: Boolean): List<Setup> {
        val m = Mir(cs, short)
        val n = m.n
        val bars = ArrayList<OBar>()
        for (i in 0 until n) {
            val b = Math.floorDiv(cs[i].t, span)
            val lb = bars.lastOrNull()
            if (lb != null && Math.floorDiv(cs[lb.first].t, span) == b) {
                lb.last = i
                lb.h = Math.max(lb.h, m.h[i])
                lb.l = Math.min(lb.l, m.l[i])
                lb.c = m.c[i]
            } else bars.add(OBar(i, i, m.o[i], m.h[i], m.l[i], m.c[i]))
        }
        val out = ArrayList<Setup>()
        // bars[q] is the break candle, bars[q + 1] must be finished too (it gives the $ level)
        for (q in 12 until bars.size - 2) {
            val bk = bars[q]
            if (bk.c >= bk.o) continue
            var rs = 0.0
            for (j in q - 10 until q) rs += bars[j].h - bars[j].l
            if (bk.h - bk.l < 1.2 * (rs / 10.0)) continue                              // the break candle must be strong
            // BOS: the nearest swing low (2 bars each side) that the candle opened above and closed below, never broken before
            var bosPrice = Double.NaN
            var bosBar = -1
            var j = q - 3
            while (j >= Math.max(2, q - 20)) {
                val pl = bars[j].l
                if (pl < bars[j - 1].l && pl < bars[j - 2].l && pl < bars[j + 1].l && pl < bars[j + 2].l && pl < bk.o && pl > bk.c) {
                    var untouched = true
                    for (x in j + 1 until q) if (bars[x].l <= pl) { untouched = false; break }
                    if (untouched) { bosPrice = pl; bosBar = j; break }
                }
                j -= 1
            }
            if (bosBar < 0) continue
            val ocl = bk.o
            var top = bk.h
            for (x in q - 4 until q) top = Math.max(top, bars[x].h)
            if (top <= ocl) continue
            val lock = bars[q + 1].last
            val at = a[lock]
            if (at.isNaN() || at <= 0.0) continue
            val stop = top + p.stopBufAtr * at
            // a long wick (zone taller than maxZoneAtr ATR): split it in two and enter at the middle
            val half = (top - ocl) > p.maxZoneAtr * at
            val entry = if (half) ocl + 0.5 * (top - ocl) else ocl
            val risk = stop - entry
            if (risk < 0.2 * at || risk > 6.0 * at) continue
            val dollar = bars[q + 1].h
            if (dollar >= ocl) continue                                                 // the pullback already reached the level
            var low = Double.MAX_VALUE
            var lowIdx = -1
            for (x in bk.last + 1..lock) if (m.l[x] < low) { low = m.l[x]; lowIdx = x }
            if (ocl - low < p.minLegAtr * at) continue                                  // price has to leave the level first

            // the limit order: first candle after $ that trades up to the OCL
            var fillIdx = -1
            var k = lock + 1
            while (k < n && k - lock <= p.lookback) {
                if (m.h[k] >= entry) { fillIdx = k; break }
                if (m.l[k] < low) { low = m.l[k]; lowIdx = k }
                k += 1
            }
            val upTo = if (fillIdx >= 0) fillIdx - 1 else n - 1
            if (fillIdx < 0 && n - 1 - lock > p.lookback) continue                      // waited too long, not a setup any more

            // DL: the nearest liquidity below that pays the minimum reward to risk
            val need = entry - p.minRR * risk
            var dl = Double.NaN
            if (low <= need) dl = low
            else {
                var q2 = upTo - 6
                val from = Math.max(5, upTo - p.lookback - 60)
                while (q2 >= from) {
                    val v = m.l[q2]
                    if (v <= need && v < low - 0.1 * at) {
                        var ok = true
                        for (x in q2 - 5..q2 + 5) if (x != q2 && m.l[x] <= v) { ok = false; break }
                        if (ok) {
                            var touched = false
                            for (x in q2 + 6..upTo) if (m.l[x] <= v) { touched = true; break }
                            if (!touched && (dl.isNaN() || v > dl)) dl = v
                        }
                    }
                    q2 -= 1
                }
            }
            if (dl.isNaN()) continue
            val rr = (entry - dl) / risk

            val s = Setup(if (short) 1 else -1, bk.first, cs[bk.first].t)
            fill(s, m, cs, if (half) "OML 2.9 (50%)" else "OML 2.9", bk.first, lock, fillIdx, ocl, top, entry, stop, dl, rr)
            // marks: what the trader draws
            val endIdx = if (fillIdx >= 0) fillIdx else -1
            s.marks.add(Mark("OCL", m.px(ocl), bk.first, endIdx))
            if (half) s.marks.add(Mark("50%", m.px(entry), lock, if (fillIdx >= 0) fillIdx else -1))
            s.marks.add(Mark("$", m.px(dollar), bars[q + 1].first, bars[q + 1].last))
            s.marks.add(Mark("BOS", m.px(bosPrice), bars[bosBar].first, Math.min(n - 1, bk.last + 2)))
            // MS: the last lower high (swing high, 3 candles each side) before the lowest low of the first leg
            var ms = -1
            var x = lowIdx - 3
            while (x > lock - 40 && x >= bk.last + 1) {
                if (x + 3 < n && x >= 3 && m.h[x] > m.h[x - 1] && m.h[x] > m.h[x - 2] && m.h[x] > m.h[x - 3] && m.h[x] > m.h[x + 1] && m.h[x] > m.h[x + 2] && m.h[x] > m.h[x + 3] && m.h[x] < ocl) { ms = x; break }
                x -= 1
            }
            if (ms >= 0) s.marks.add(Mark("MS", m.px(m.h[ms]), ms, if (fillIdx >= 0) fillIdx else -1))
            s.marks.add(Mark("DL", m.px(dl), if (fillIdx >= 0) fillIdx else lock, -1))
            if (fillIdx >= 0) {
                if (m.h[fillIdx] >= stop) { s.state = ST_LOSS; s.endIdx = fillIdx; s.endT = cs[fillIdx].t; s.result = -1.0 }
                else resolve(s, m, cs, fillIdx, entry, stop, dl, p)
            } else s.state = ST_WAITING
            out.add(s)
        }
        return out
    }
}
